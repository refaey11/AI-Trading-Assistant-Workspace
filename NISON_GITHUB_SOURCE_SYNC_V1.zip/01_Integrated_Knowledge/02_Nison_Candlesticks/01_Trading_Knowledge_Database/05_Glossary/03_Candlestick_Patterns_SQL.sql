-- =========================================================
-- 05_Glossary
-- 03_Candlestick_Patterns_SQL.sql
--
-- Source:
-- Book Conclusion — Summary (A)
-- Candlesticks and Visual Dictionary
--
-- IMPORTANT:
-- Source-restricted data only.
-- No external definitions, statistics, or interpretations.
-- =========================================================


-- =========================================================
-- MAIN CANDLESTICK GLOSSARY
-- =========================================================

CREATE TABLE candlestick_patterns_glossary (
    id INTEGER PRIMARY KEY,
    name_en VARCHAR(150) NOT NULL,
    name_ar VARCHAR(150) NOT NULL,
    category VARCHAR(100),
    description TEXT NOT NULL
);


INSERT INTO candlestick_patterns_glossary
(id, name_en, name_ar, category, description)
VALUES

(1,
 'Abandoned Baby',
 'الطفل المُشرّد',
 'Major Turning Point',
 'A very rare major turning-point top or bottom signal consisting of a Doji Star separated from the preceding and following candles by gaps.'),

(2,
 'Advance Block',
 'عائق التقدم',
 'Weakening Bullish Movement',
 'One of the forms of the Three Advancing Soldiers pattern in which the last two white candles show weakening upward strength. The weakness may appear through long upper shadows or through each candle becoming smaller than the preceding one.'),

(3,
 'Bullish Belt Hold',
 'حزام فوز الثيران',
 'Bullish',
 'A long white candle whose opening price is the lowest price of the session. It is also called a white opening shaven-bottom candle. At low prices, it is a positive signal.'),

(4,
 'Bearish Belt Hold',
 'حزام فوز الدبية',
 'Bearish',
 'A long black candle whose opening price is the highest price of the session. It is also called a black opening shaven-head candle. At high prices, it is a negative signal.'),

(5,
 'Candlestick Lines and Charts',
 'خطوط وخرائط الشموع',
 'Candlestick Chart',
 'Traditional Japanese charts that resemble candles, which is the source of the name. Candles consist of real bodies and shadows.'),

(6,
 'Counterattack Lines',
 'خطوط الهجوم المضاد',
 'Reversal',
 'During a declining or rising trend, the market opens with a sharp gap downward or upward after a black or white candle respectively. The market then reverses and creates the same closing price as the previous session.'),

(7,
 'Dark-Cloud Cover',
 'السُّحُب الرُّكامية القاتمة',
 'Bearish Major Turning Point',
 'A negative major turning-point signal consisting of two candles during an upward trend. The first is a long white candle and the second is a black candle that opens above the high of the white candle and closes deeply into its range.'),

(8,
 'Dead Cross',
 'التقاطع الميت',
 'Bearish Signal',
 'A negative signal obtained when a short-term moving average falls below a longer-term moving average.'),

(9,
 'Deliberation Pattern',
 'نموذج التأني',
 'Cross Reference',
 'See Stalled Pattern.'),

(10,
 'Doji',
 'دوجي / شمعة المُرْتَجّ',
 'Candle Type',
 'A session in which the opening price and closing price are the same or very close. There are different variations of Doji.'),

(11,
 'Gapping Plays',
 'مناورات الفجوات',
 'Cross Reference',
 'The supplied source references Low-Price Gapping Plays and High-Price Gapping Plays, but does not provide a detailed definition of Gapping Plays.'),

(12,
 'Low-Price Gapping Plays',
 'مناورة فجوة الأسعار المنخفضة',
 'Cross Reference',
 'See Gapping Plays.'),

(13,
 'High-Price Gapping Plays',
 'مناورة فجوة الأسعار العالية',
 'Cross Reference',
 'See Gapping Plays.'),

(14,
 'Hanging Man',
 'الرجل المشنوق',
 'Bearish Major Turning Point',
 'A Hammer-shaped candle appearing in an upward trend, with a small real body near the top of the trading range, a very long lower shadow, and a very small or nonexistent upper shadow. It indicates market weakness and requires confirmation during the following session.'),

(15,
 'Harami',
 'المرأة الحامل',
 'Turning Point',
 'A two-candle pattern in which the second candle has a small real body completely inside the range of the first long session. It indicates the end of the previous trend and a truce between buying and selling forces.'),

(16,
 'Harami Cross',
 'المرأة حاملة النطفة',
 'Major Turning Point',
 'A Harami in which the second candle is a Doji. It is an important major turning-point top or bottom, especially after a long white or black candle. It is also called the Petrifying Pattern.'),

(17,
 'High Wave',
 'الموجة العالية',
 'Turning Point',
 'A candle with a very long upper or lower shadow and a short real body. Groups of these candles signal a possible change in the market.'),

(18,
 'In-Neck Line',
 'التسلل للمضيق',
 'Bearish Continuation',
 'A small white candle appearing during a declining trend whose close is slightly above the low of the preceding black candle. The market continues downward when prices fall below the low of this white candle.'),

(19,
 'Inverted Hammer',
 'المطرقة المقلوبة',
 'Bullish Major Turning Point',
 'After a declining trend, a candle with a long upper shadow and a small real body near the lower part of the trading range, with no lower shadow or a very small lower shadow. It is a positive signal for a major turning-point bottom and requires confirmation during the following session.'),

(20,
 'Inverted Three Buddha Pattern',
 'نموذج تماثيل بوذا الثلاثة المقلوبة',
 'Cross Reference',
 'See Three Buddha Patterns.'),

(21,
 'Long-Legged Doji',
 'الدوجي طويلة السيقان',
 'Major Turning Point',
 'Doji candles with very long shadows. They are an important major turning-point signal. When the opening and closing prices occur at low prices, the candle is a positive signal.'),

(22,
 'Mat Hold Pattern',
 'نموذج حشية الملاكمة',
 'Bullish Continuation',
 'A positive continuation pattern beginning with a white candle followed by a small black candle separated by an upward gap, followed by two black candles and then a long white candle closing above the close of the first candle.'),

(23,
 'Morning Star',
 'نجمة الصباح',
 'Major Turning Point Bottom',
 'A three-candle major turning-point bottom pattern consisting of a long black candle, a small-bodied candle after a downward gap forming a Star, and a long white candle closing deeply into the first candle''s range.'),

(24,
 'Doji Morning Star',
 'نجمة الصباح الدوجي',
 'Major Turning Point Bottom',
 'A Morning Star in which the middle candle is a Doji. The presence of the Doji makes it more positive than the ordinary Morning Star.'),

(25,
 'On-Neck Line',
 'نموذج حصار المضيق',
 'Bearish Continuation',
 'A declining-trend pattern consisting of a long black candle followed by a white candle whose close is near the low of the black candle and below it. The market resumes its decline when prices break below the low of the white candle.'),

(26,
 'Petrifying Pattern',
 'نموذج الإرعاب',
 'Cross Reference',
 'Another name for the Harami pattern according to the supplied source.'),

(27,
 'Piercing Pattern',
 'نموذج ثقب الحُلِيّ',
 'Bullish Major Turning Point',
 'A major turning-point bottom signal in which a long black candle is followed by a downward gap and then a long white candle closing above the midpoint of the preceding black candle.'),

(28,
 'Rain Drop',
 'قطرة المطر',
 'Cross Reference',
 'See Star.'),

(29,
 'Real Body',
 'جسم الشمعة',
 'Candle Component',
 'The thick part of the candle representing the distance between the opening price and the closing price. When the close is higher than the open, the candle is white. When the close is lower than the open, the candle is black.'),

(30,
 'Rickshaw Man',
 'شمعة رَجُل الريكا',
 'Cross Reference',
 'See Long-Legged Doji.'),

(31,
 'Rising Three Methods',
 'نموذج الهاربين الثلاثة الإيجابي',
 'Cross Reference',
 'See Three Methods.'),

(32,
 'Separating Lines',
 'الشموع انفصالية النزعة / المنشقة',
 'Continuation',
 'During an upward or downward trend, the market opens at the same opening price as the previous session of opposite color and then closes higher or lower respectively. The previous trend resumes.'),

(33,
 'Shadows',
 'ظلال الشموع',
 'Candle Component',
 'Thin lines above and below the real body representing the extreme prices of the session.'),

(34,
 'Lower Shadow',
 'الظل السفلي',
 'Candle Component',
 'The line below the real body. The bottom of this shadow represents the low of the session.'),

(35,
 'Upper Shadow',
 'الظل العلوي',
 'Candle Component',
 'The line above the real body. The top of this shadow represents the high of the session.'),

(36,
 'Shaven Bottom',
 'الدَّبْر الحليق',
 'Candle Type',
 'A candle with no lower shadow.'),

(37,
 'Shaven Head',
 'الرأس الحليق',
 'Candle Type',
 'A candle with no upper shadow.'),

(38,
 'Shooting Star',
 'شمعة الشهاب',
 'Bearish',
 'A candle with a long upper shadow, a very small or absent lower shadow, and a small real body near the bottom of the session. It occurs during an upward trend and is a negative signal.'),

(39,
 'Side-by-Side White Lines',
 'الشمعتان البيضاوان المتحاذيتان بعد الفجوة',
 'Continuation',
 'Two consecutive white candles with the same opening price and approximately equal real bodies. They are positive for continuation in an upward trend and negative for continuation in a downward trend after a downward gap. These patterns are very rare.'),

(40,
 'Spinning Tops',
 'بلايل اللعب الدوَّارة',
 'Candle Type',
 'Candles with small real bodies.'),

(41,
 'Stalled Pattern',
 'النموذج المُعطَّل',
 'Bearish / Trend Stalling',
 'A pattern in which a small white candle appears after a long white candle, either above it or at its high. Sometimes a small white candle also appears before the long white candle. The upward trend becomes stalled. It is also called the Deliberation Pattern.'),

(42,
 'Star',
 'النجمة',
 'Candle Pattern',
 'A candle with a small real body that comes after a gap away from the preceding long candle. The Star reflects a decrease in the previous trend. Stars appearing after long black candles during a declining trend are sometimes called Rain Drops.'),

(43,
 'Tasuki Gaps',
 'فجوات تاسوكي',
 'Continuation',
 'There are two types: Downside Tasuki Gap and Upside Tasuki Gap. Tasuki Gaps are rare.'),

(44,
 'Downside Tasuki Gap',
 'فجوة تاسوكي الهابطة',
 'Bearish Continuation',
 'A black candle appears after a downward gap and is followed by a white candle approximately equal in size. The white candle opens within the black candle''s range and closes above the black candle''s body, above its opening price.'),

(45,
 'Upside Tasuki Gap',
 'فجوة تاسوكي الصاعدة',
 'Bullish Continuation',
 'A white candle appears after an upward gap and is followed by a black candle approximately equal in size. The black candle opens within the white candle''s range and closes below the white candle''s body, below its opening price.'),

(46,
 'Three Buddha Patterns',
 'نموذج تماثيل بوذا الثلاثة',
 'Major Reversal',
 'The Three Buddha Top corresponds to the Western Head and Shoulders pattern. The Inverted Three Buddha corresponds to the Western Inverted Head and Shoulders pattern.'),

(47,
 'Three Buddha Top',
 'قمة تماثيل بوذا الثلاثة',
 'Major Top',
 'The Three Buddha Top corresponds to the Western Head and Shoulders pattern. In Japanese terminology, it is the Three Mountain Tops pattern, where the middle peak is the highest of the three.'),

(48,
 'Inverted Three Buddha',
 'نموذج تماثيل بوذا الثلاثة المقلوبة',
 'Major Bottom',
 'The Inverted Three Buddha corresponds to the Western Inverted Head and Shoulders pattern. In Japanese terminology, it is the Three River Bottoms pattern, where the middle valley is the deepest.'),

(49,
 'Three Crows',
 'الغربان الثلاثة',
 'Major Turning Point Top',
 'Three consecutive long black candles closing at or near their lowest prices. It is a major turning-point top, especially at high prices or after a long upward trend.'),

(50,
 'Three Gaps',
 'الفجوات الثلاثة',
 'Exhaustion',
 'After three upward gaps, a poor candlestick signal indicates that buying forces are nearing exhaustion. After three downward gaps, a positive candlestick signal indicates that selling forces are nearing exhaustion.'),

(51,
 'Three Methods',
 'الهاربين الثلاثة',
 'Continuation',
 'There are two forms: Bearish Three Methods and Bullish Three Methods.'),

(52,
 'Bearish Three Methods',
 'الهاربين الثلاثة السلبي',
 'Bearish Continuation',
 'A five-candle continuation pattern consisting of a long black candle, three small candles, often white, remaining within the range of the first black candle, followed by a black candle closing at a new low for the downward movement.'),

(53,
 'Bullish Three Methods',
 'الهاربين الثلاثة الإيجابي',
 'Bullish Continuation',
 'A five-candle continuation pattern consisting of a long white candle, three small candles, often black, remaining within the range of the first white candle, followed by a long white candle closing at a new high for the upward movement.'),

(54,
 'Three Mountain Top',
 'قمة الجبال الثلاثة',
 'Long-Term Top',
 'A long-term top pattern in which the upward movement stops at the same highs or near the same highs. It is sometimes described as the Three Rising Waves.'),

(55,
 'Three River Bottom',
 'قاع الأنهار الثلاثة',
 'Bottom',
 'The market reaches a bottom area three times and then exceeds the highest peak between the valleys through a white candle or an upward gap, confirming that the bottom has formed.'),

(56,
 'Three White / Three Advancing Soldiers',
 'الفدائيين الثلاثة',
 'Bullish',
 'Three white candles with progressively higher closes. Each close is higher than the previous one. They indicate increasing strength when they appear after a period of price stability, particularly when prices are low.'),

(57,
 'Thrusting Line',
 'نموذج اقتحام المضيق',
 'Continuation',
 'A white candle that closes inside the range of the preceding black candle without exceeding its midpoint upward. It is stronger than the In-Neck Line but weaker than the Piercing Pattern according to the supplied source.'),

(58,
 'Tower Top',
 'القمة ذات الأبراج',
 'Major Turning Point Top',
 'A long white candle followed by a congestion or sideways trading area and then a long black candle or group of long black candles.'),

(59,
 'Tower Bottom',
 'القاع ذات الأبراج',
 'Major Turning Point Bottom',
 'A long black candle followed by sideways movement and then an upward breakout through a number of long white candles.'),

(60,
 'Tri-Star',
 'النموذج ثلاثي النجوم',
 'Major Turning Point',
 'A very rare pattern consisting of three Doji candles whose formation resembles a Morning Star or Evening Star.'),

(61,
 'Tweezers Top',
 'القمة الملاقط',
 'Minor Turning Point',
 'Forms when the same high price level is tested twice consecutively or within a few days.'),

(62,
 'Tweezers Bottom',
 'القاع الملاقط',
 'Minor Turning Point',
 'Forms when the same low price level is tested twice consecutively or within a few days.'),

(63,
 'Unique Three River Bottom',
 'القاع الفريد للأنهار الثلاثة',
 'Rare Bottom',
 'A rare three-candle bottom pattern consisting of a long black candle, a black candle similar to a Hammer reaching a new low, and a small-bodied third candle.'),

(64,
 'Upside Gap Tasuki',
 'فجوة تاسوكي الصاعدة',
 'Cross Reference',
 'See Tasuki Gaps.'),

(65,
 'Upside Gap Two Crows',
 'الغربان فوق الفجوة الصاعدة',
 'Major Turning Point Top',
 'A three-candle pattern consisting of a long white candle, a black candle separated from it by an upward gap, and another black candle opening above the second candle''s opening and closing below its close.'),

(66,
 'Windows',
 'النوافذ',
 'Continuation',
 'The Japanese term for gaps in Western analysis. During an advance, a Window can become support after an orderly pullback. During a sharp decline, a Window can become resistance when the market rises toward it.'),

(67,
 'Yin and Yang',
 'ين ويانج',
 'Candle Terminology',
 'Chinese names used for candle colors: Yin is the black candle and Yang is the white candle.');


-- =========================================================
-- MARKET TERMS
-- =========================================================

CREATE TABLE candlestick_market_terms (
    id INTEGER PRIMARY KEY,
    name_en VARCHAR(100) NOT NULL,
    name_ar VARCHAR(150) NOT NULL,
    description TEXT NOT NULL
);


INSERT INTO candlestick_market_terms
(id, name_en, name_ar, description)
VALUES

(1,
 'Morning Attack',
 'هجمة الصباح',
 'A Japanese term used to describe large buying or selling operations at the opening, mainly used to move the market.'),

(2,
 'Evening Attack',
 'هجمة المساء',
 'A Japanese term used to describe large buying or selling operations at the close, used in an attempt to influence the market close and reactions on the following day.'),

(3,
 'Yin and Yang',
 'ين ويانج',
 'Chinese names used for candle colors: Yin is the black candle and Yang is the white candle.');


-- =========================================================
-- CROSS REFERENCES
-- =========================================================

CREATE TABLE candlestick_cross_references (
    id INTEGER PRIMARY KEY,
    term VARCHAR(150) NOT NULL,
    reference_term VARCHAR(150) NOT NULL
);


INSERT INTO candlestick_cross_references
(id, term, reference_term)
VALUES

(1,
 'Deliberation Pattern',
 'Stalled Pattern'),

(2,
 'Low-Price Gapping Plays',
 'Gapping Plays'),

(3,
 'High-Price Gapping Plays',
 'Gapping Plays'),

(4,
 'Rain Drop',
 'Star'),

(5,
 'Rickshaw Man',
 'Long-Legged Doji'),

(6,
 'Rising Three Methods',
 'Three Methods'),

(7,
 'Inverted Three Buddha Pattern',
 'Three Buddha Patterns'),

(8,
 'Upper Shadow',
 'Shadows'),

(9,
 'Lower Shadow',
 'Shadows'),

(10,
 'Upside Gap Tasuki',
 'Tasuki Gaps');


-- =========================================================
-- SOURCE LIMITATION
-- =========================================================

CREATE TABLE candlestick_glossary_source_rules (
    id INTEGER PRIMARY KEY,
    rule_name VARCHAR(100) NOT NULL,
    rule_description TEXT NOT NULL
);


INSERT INTO candlestick_glossary_source_rules
(id, rule_name, rule_description)
VALUES

(1,
 'Source Restriction',
 'Use only the supplied Book Summary (A) — Candlesticks and Visual Dictionary.'),

(2,
 'No External Information',
 'Do not add definitions, classifications, statistics, probabilities, trading rules, or interpretations from outside the supplied source.'),

(3,
 'Cross Reference Preservation',
 'When the supplied source says see or refer to another term, preserve the cross-reference rather than inventing missing information.'),

(4,
 'Ideal Pattern Rule',
 'The ideal forms described by the source are reference points because ideal patterns rarely occur exactly in actual markets.'),

(5,
 'Missing Information',
 'If a requested definition is not provided in the supplied source, state that the information is not provided in the supplied source.');