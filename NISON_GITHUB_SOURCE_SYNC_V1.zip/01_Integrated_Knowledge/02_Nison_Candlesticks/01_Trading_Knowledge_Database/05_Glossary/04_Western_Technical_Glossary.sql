-- =========================================================
-- 05_Glossary
-- 04_Western_Technical_Glossary.sql
--
-- Source:
-- Book Summary (B) — American Technical Terminology
--
-- IMPORTANT:
-- Source-restricted data only.
-- No external definitions, statistics, or interpretations.
-- =========================================================


-- =========================================================
-- WESTERN TECHNICAL GLOSSARY
-- =========================================================

CREATE TABLE western_technical_glossary (
    id INTEGER PRIMARY KEY,
    name_en VARCHAR(150) NOT NULL,
    name_ar VARCHAR(200) NOT NULL,
    category VARCHAR(100),
    description TEXT NOT NULL
);


-- =========================================================
-- TERMS
-- =========================================================

INSERT INTO western_technical_glossary
(id, name_en, name_ar, category, description)
VALUES

(1,
 'Bar Chart',
 'خرائط المزالج (البارات)',
 'Chart',
 'A graphical representation of price movement during trading sessions. The high and low of the session form the top and bottom of the vertical line. The close is represented by a horizontal line on the right side of the vertical line, while the open is represented by a horizontal line on the left side. Prices are shown on the vertical axis and time on the horizontal axis.'),

(2,
 'Blow-offs',
 'التسرّبات',
 'Reversal / Extremes',
 'Major turning-point tops or bottoms that occur after a long trend. Prices move sharply and rapidly during blow-offs, often with very high trading volume, in the same direction as the preceding trend. If prices reverse afterward, the formation is called a blow-off.'),

(3,
 'Breakaway Gap',
 'فجوة الاستقلال (الانفصال)',
 'Gap',
 'A gap that moves prices away from an important technical area, such as a trendline or a sideways trading area.'),

(4,
 'Breakout',
 'الاختراق',
 'Price Structure',
 'Overcoming a resistance or support level.'),

(5,
 'Change of Polarity',
 'تغيّر القطبية',
 'Support / Resistance',
 'The principle that old support becomes new resistance and old resistance becomes new support.'),

(6,
 'Confirmation',
 'إشارة التأكيد',
 'Technical Analysis',
 'The combination of technical indicators to confirm their technical implications.'),

(7,
 'Congestion Zone or Band',
 'نطاق الازدحام (التعريض)',
 'Price Structure',
 'A period during which the market trades sideways within a narrow price range.'),

(8,
 'Consolidation',
 'منطقة التداول (التعريض)',
 'Price Structure',
 'Similar to a congestion zone, but it indicates that the preceding trend will resume its movement.'),

(9,
 'Continuation Patterns',
 'نماذج الاستمرار',
 'Pattern',
 'Patterns that indicate continuation of the preceding trend. The Flag is an example of a continuation pattern.'),

(10,
 'Crossover',
 'التقاطع',
 'Indicator',
 'When a faster indicator crosses a slower indicator upward, the crossover is positive. When it crosses downward, the crossover is negative. For example, when a five-day moving average falls below a thirteen-day moving average, the crossover is negative.'),

(11,
 'Divergence',
 'الانفراج',
 'Indicator',
 'When related technical indicators fail to confirm price movement. For example, if prices reach new highs but the Stochastics indicator does not, this is negative divergence and indicates a decline. If prices reach new lows but the indicator does not, this is positive divergence and indicates an upward movement.'),

(12,
 'Downgap',
 'الفجوة الهابطة',
 'Gap',
 'A gap that moves prices downward.'),

(13,
 'Downtrend',
 'المسار الهابط',
 'Trend',
 'A trend in which the market moves downward, characterized by lower highs and lower lows.'),

(14,
 'Double Bottom',
 'القاع المزدوج',
 'Price Pattern',
 'A price movement resembling the letter W, where prices decline and stop twice at the same lows or near the same lows.'),

(15,
 'Double Top',
 'القمة المزدوجة',
 'Price Pattern',
 'A price movement resembling the letter M, where prices rise and stop twice at the same highs or near the same highs.'),

(16,
 'Elliott Wave',
 'موجات إليوت',
 'Market Theory',
 'A system for analyzing and forecasting price movements founded by Ralph Nelson Elliott. The theory states that prices move in five waves in the direction of the general market trend followed by three corrective waves.'),

(17,
 'Exponential Moving Average',
 'المتوسط المتحرك أُسّياً',
 'Moving Average',
 'A moving average in which the component data are weighted exponentially.'),

(18,
 'Fibonacci',
 'فيبوناتشي',
 'Technical Analysis',
 'An Italian mathematician who formulated a sequence of numbers based on adding each two preceding numbers together. The Fibonacci ratios commonly used by technical analysts are approximately 38%, 50%, and 62%.'),

(19,
 'Flag or Pennant',
 'العلم أو علم السفينة',
 'Continuation Pattern',
 'A continuation pattern consisting of a sharp advance followed by a short trading area. Both the Flag and Pennant are continuation patterns.'),

(20,
 'Filling in the Gap',
 'ملء الفجوة',
 'Gap',
 'A market movement inside the empty range created by a gap.'),

(21,
 'Gaps',
 'الفجوات',
 'Gap',
 'Areas of price space in which no trading occurs between one price area and another.'),

(22,
 'Historical Volatility',
 'تقلبات الأسعار التاريخية',
 'Volatility',
 'Calculations that provide a specified range of prices over a specified period of time. The calculations are based on changes in option prices according to the supplied source.'),

(23,
 'Implied Volatility',
 'تقلبات الأسعار المُتضمّنة',
 'Volatility',
 'The market expectations for future levels of price volatility.'),

(24,
 'Inside Session',
 'الجلسة الداخلية',
 'Session',
 'A session in which the range between the high and low is contained within the range of the previous session.'),

(25,
 'Intra-day',
 'تداول داخل الجلسة',
 'Timeframe',
 'Any chart representing a period shorter than a daily chart. For example, a 60-minute intraday chart uses the high, low, open, and close of each hour.'),

(26,
 'Islands',
 'المناطق المنعزلة (الجزر)',
 'Price Pattern',
 'Formations that appear at market extremes when prices gap in the direction of the general trend, remain in that range for one or more days, and then gap in the opposite direction, leaving prices isolated between two gaps.'),

(27,
 'Locals',
 'المضاربون لحسابهم الشخصي',
 'Market Participants',
 'Traders in the futures market who trade for their own account.'),

(28,
 'Market Profile',
 'شاكلة السوق',
 'Market Analysis',
 'A statistical distribution of prices over specified periods of time, often 30 minutes.'),

(29,
 'Momentum',
 'الزَّخْم',
 'Market Movement',
 'The speed of price movement, comparing the latest close with a close from several periods earlier.'),

(30,
 'Moving Average Convergence-Divergence (MACD) Oscillator',
 'مؤشر تذبذب الانفراج والتقارب للمتوسط المتحرك',
 'Indicator',
 'A combination of three smoothed exponential moving averages.'),

(31,
 'Neck Line',
 'خط العنق',
 'Price Pattern',
 'The line connecting the two lowest points in a Head and Shoulders pattern and the two highest points in an Inverted Head and Shoulders pattern. Movement below the Neck Line of the Head and Shoulders pattern is negative, while movement above the Neck Line of the Inverted Head and Shoulders pattern is positive.'),

(32,
 'Negative Crossover',
 'التقاطع السلبي',
 'Indicator',
 'See Crossover.'),

(33,
 'Negative Divergence',
 'الانفراج السلبي',
 'Indicator',
 'See Divergence.'),

(34,
 'Offset',
 'إغلاق العمليات',
 'Trading',
 'Exiting an existing position. For buyers, the operation is called liquidation; for short sellers, it is called covering.'),

(35,
 'On-Balance Volume (OBV)',
 'إجمالي الحجم',
 'Volume Indicator',
 'A cumulative number representing total trading volume. If a session closes higher than the previous session, its volume is added to the cumulative total. If it closes below the previous close, its volume is subtracted. Days with no price change are ignored.'),

(36,
 'Open Interest',
 'العقود المفتوحة',
 'Futures Market',
 'Contracts in the futures market that have not yet been executed and remain pending. Open interest equals the total number of long positions or the total number of short positions, not their sum.'),

(37,
 'Oscillator',
 'مؤشر التذبذب',
 'Indicator',
 'A momentum line that oscillates around a zero line or between zero and 100%. Oscillators help measure overbought and oversold conditions, identify positive and negative divergence, and measure the speed of price movement.'),

(38,
 'Overbought',
 'فرط الشراء',
 'Market Condition',
 'When the market moves upward for a very long distance and at very high speed, it becomes vulnerable to a downward correction.'),

(39,
 'Oversold',
 'فرط البيع',
 'Market Condition',
 'When the market falls very rapidly, it becomes capable of an upward rebound.'),

(40,
 'Paper Trading',
 'التجارة الافتراضية',
 'Trading Practice',
 'Trading without money. Positions are taken only on paper or in imagination without committing money, while profits and losses are monitored and recorded for learning.'),

(41,
 'Pennant',
 'علم السفينة',
 'Continuation Pattern',
 'See Flag or Pennant.'),

(42,
 'Positive Crossover',
 'التقاطع الإيجابي',
 'Indicator',
 'See Crossover.'),

(43,
 'Positive Divergence',
 'الانفراج الإيجابي',
 'Indicator',
 'See Divergence.'),

(44,
 'Protective Stop',
 'التوقف الوقائي',
 'Risk Management',
 'A method for stopping losses if the market moves against a recently profitable position. When prices reach the predetermined stop-loss level, the position is closed at the prevailing prices.'),

(45,
 'Rally',
 'صعود سريع',
 'Market Movement',
 'An upward movement in prices.'),

(46,
 'Reaction',
 'رد الفعل',
 'Market Movement',
 'A price movement in the direction opposite to the prevailing general trend.'),

(47,
 'Relative Strength Index (RSI)',
 'مؤشر القوة النسبية',
 'Indicator',
 'An oscillator developed by Welles Wilder that compares the ratio of rising closes to falling closes over a specified period.'),

(48,
 'Resistance Level',
 'مستوى المقاومة',
 'Support / Resistance',
 'A level at which an increase in sellers entering the market is expected.'),

(49,
 'Retracement',
 'الارتداد',
 'Price Movement',
 'A decline in prices from their previous movement by a specified percentage of that movement. The most common retracements are 38%, 50%, and 62%.'),

(50,
 'Reversal Indicator',
 'المؤشر المفصلي',
 'Indicator',
 'See Trend Reversals.'),

(51,
 'Selling Climax',
 'أوج البيع',
 'Market Reversal',
 'When prices collapse sharply and rapidly with high trading volume after a prolonged decline, and then reverse direction, the collapse is called a Selling Climax.'),

(52,
 'Selloff',
 'هبوط حاد',
 'Market Movement',
 'A downward movement in prices.'),

(53,
 'Simple Moving Average',
 'المتوسط المتحرك البسيط',
 'Moving Average',
 'A method for smoothing price data by adding the data and calculating their arithmetic average. It is called moving because the average changes as newer data enter and older data are removed from the calculation.'),

(54,
 'Spring',
 'نبضة الزنبرك',
 'Price Pattern',
 'When prices break below the support level of a sideways trading range and then recover back above the support level, this is considered a positive market movement.'),

(55,
 'Stochastics',
 'المؤشرات الإحصائية الحدسية',
 'Indicator',
 'An oscillator that measures the relative position of a close compared with the selected period in which it occurs. It consists of the faster moving-average line K% and the slower moving-average line D%.'),

(56,
 'Support Level',
 'مستوى الدعم',
 'Support / Resistance',
 'An area where buyers are expected to appear in greater numbers.'),

(57,
 'Tick Volume',
 'حجم التداول اللحظي',
 'Volume',
 'The number of transactions for each period in intraday trading.'),

(58,
 'Time Filter',
 'المرشح الزمني',
 'Confirmation',
 'Prices should remain above or below certain price levels for a period of time to confirm that an important technical area has been broken. For example, the market should close above broken resistance for at least two days before buy-and-hold orders begin entering the market.'),

(59,
 'Trading Range',
 'نطاق التداول',
 'Price Structure',
 'A range formed when prices are confined between a horizontal resistance level and a horizontal support level.'),

(60,
 'Trend',
 'اتجاه المسار',
 'Trend',
 'The general direction of prices in the market.'),

(61,
 'Trend Reversals',
 'النقاط المفصلية للمسار',
 'Trend',
 'Also called Reversal Indicators. They mean that the preceding trend should change direction, but they do not necessarily mean that it will reverse direction.'),

(62,
 'Trendline',
 'خط المسار',
 'Trend',
 'A line on a chart connecting the higher points of the market or the lower points of the market. At least two points are required to draw a trendline. The more times the trendline is tested, and the greater the trading volume during those tests, the more important the trendline becomes.'),

(63,
 'Upgap',
 'فجوة لأعلى',
 'Gap',
 'A gap that pushes prices upward.'),

(64,
 'Upthrust',
 'التوغل الخادع',
 'Bearish Price Pattern',
 'When prices move above a resistance level that formed the ceiling of a sideways trading area, but fail to maintain the new high levels and then fall below the resistance level, the formation is called an Upthrust and is a negative signal.'),

(65,
 'Uptrend',
 'مسار صاعد',
 'Trend',
 'A market trend in which prices move upward.'),

(66,
 'V Bottom or Top',
 'قمة أو قاع على شكل حرف V',
 'Reversal Pattern',
 'A pattern formed when prices reverse direction and create a V shape at the bottom or an inverted V shape at the top.'),

(67,
 'Volume',
 'حجم التداول',
 'Volume',
 'The total number of contracts executed during a period.'),

(68,
 'Weighted Moving Average',
 'المتوسط المتحرك المُرَجَّح',
 'Moving Average',
 'A moving average in which previous prices are given relative weights. More recent prices are usually given greater weight.');