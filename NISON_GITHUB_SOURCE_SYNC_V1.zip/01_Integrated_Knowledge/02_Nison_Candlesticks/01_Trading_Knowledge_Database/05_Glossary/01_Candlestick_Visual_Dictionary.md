# 01 — Candlestick Visual Dictionary

## Source

Book Summary (A) — Candlesticks and Visual Dictionary

---

## Purpose

This file documents the candlestick terminology and pattern descriptions contained in the supplied book summary.

The descriptions represent the ideal forms presented by the source.

The source explicitly notes that these ideal forms rarely occur exactly in actual markets. Therefore, they should be treated as reference points, while the trader uses personal judgment when interpreting actual market conditions.

---

# A

## Abandoned Baby — الطفل المُشرّد

A very rare major turning-point top or bottom signal.

It consists of a Doji Star, including its shadows, separated from the preceding and following candles by gaps.

The pattern resembles an Island Top or Island Bottom in Western analysis, where the isolated session is a Doji and is preceded and followed by gaps.

---

## Advance Block — عائق التقدم

One of the forms of the Three Advancing Soldiers pattern.

In this form, the last two white candles show weakening upward strength.

The weakness may appear through:

- Long upper shadows.
- Each candle becoming smaller than the preceding one.

This indicates decreasing buying power or increasing selling power.

---

# B

## Belt-Hold Lines — حزام الفوز

There are two types:

- Bullish Belt Hold.
- Bearish Belt Hold.

### Bullish Belt Hold

A long white candle in which the opening price is the lowest price of the session.

It is also called a white opening shaven-bottom candle.

At low prices, this candle is a positive signal.

### Bearish Belt Hold

A long black candle in which the opening price is the highest price of the session.

It is also called a black opening shaven-head candle.

At high prices, this candle is a negative signal.

---

# C

## Candlestick Lines and Charts — خطوط وخرائط الشموع

Traditional Japanese charts that resemble candles, which is the source of the name.

Candles consist of:

- Real Bodies.
- Shadows.

---

## Counterattack Lines — خطوط الهجوم المضاد

During a declining or rising trend, the market opens with a sharp gap downward or upward after a black or white candle respectively.

The market then reverses and creates the same closing price as the previous session.

This reflects the intensity of the battle between bulls and bears.

---

# D

## Dark-Cloud Cover — السُّحُب الرُّكامية القاتمة

A negative major turning-point signal.

It consists of two candles during an upward trend:

1. A long white candle.
2. A black candle that opens above the high of the white candle and then closes deeply into the range of the white candle.

---

## Deliberation Pattern — نموذج التأني

See **Stalled Pattern**.

---

## Doji — دوجي / شمعة المُرْتَجّ

A session in which the opening price and closing price are the same or very close.

There are different variations of Doji.

A Doji located in the middle of the session's trading range is referred to as a **Rickshaw Man**.

---

# G

## Gapping Plays — مناورات الفجوات

The supplied source references:

- Low-Price Gapping Plays.
- High-Price Gapping Plays.

The detailed definition of Gapping Plays is not provided in the supplied text.

---

## High-Price Gapping Plays — مناورة فجوة الأسعار العالية

See **Gapping Plays**.

---

# H

## Hanging Man — الرجل المشنوق

An important major turning-point candle.

It has the same shape as a Hammer:

- Small real body near the top of the trading range.
- Very long lower shadow.
- Very small or nonexistent upper shadow.

When this shape appears during an upward trend, it becomes the bearish Hanging Man.

It indicates that the market has become weak.

The Hanging Man requires confirmation during the following session.

The confirmation should be a black candle with a lower close or weaker opening.

In principle, the lower shadow should be approximately two or three times the height of the real body.

---

## Harami — المرأة الحامل

A two-candle pattern in which the second candle has a small real body completely inside the range of the first long session.

The Harami indicates the end of the previous trend and that a truce has occurred between buying and selling forces.

The second candle may be white or black.

The second candle is often opposite in color to the first candle.

---

## Harami Cross — المرأة حاملة النطفة

When the second candle of a Harami is a Doji, the pattern is called a Harami Cross.

It is an important major turning-point top or bottom, especially when it appears after a long white or black candle.

The pattern is also called the **Petrifying Pattern**.

---

## High Wave — الموجة العالية

A candle with a very long upper shadow or lower shadow and a short real body.

When this candle appears in groups, it signals a possible change in the market.

---

# I

## In-Neck Line — التسلل للمضيق

A small white candle appearing during a declining trend.

Its close is slightly above the low of the preceding black candle.

The market continues downward when prices fall below the low of this white candle.

The source compares this pattern with:

- On-Neck Line.
- Thrusting Line.
- Piercing Pattern.

---

## Inverted Hammer — المطرقة المقلوبة

After a declining trend, this candle has:

- A long upper shadow.
- A small real body located near the lower part of the trading range.
- No lower shadow or a very small lower shadow.

It has the same shape as the Shooting Star but appears at the end of a declining trend.

It is a positive signal for a major turning-point bottom.

It should be confirmed during the following session by a white candle with a higher close or higher opening price.

---

## Inverted Three Buddha Pattern — نموذج تماثيل بوذا الثلاثة المقلوبة

See **Three Buddha Patterns**.

---

# L

## Long-Legged Doji — الدوجي طويلة السيقان

Doji candles with very long shadows.

They are an important major turning-point signal.

When the opening and closing prices occur at low prices, the candle is a positive signal.

---

## Low-Price Gapping Plays — مناورة فجوة الأسعار المنخفضة

See **Gapping Plays**.

---

## Lower Shadows — الظلال السفلية

See **Shadows**.

---

# M

## Mat Hold Pattern — نموذج حشية الملاكمة

A positive continuation pattern.

The pattern begins with a white candle followed by a small black candle separated from it by an upward gap.

Two black candles then appear.

A long white candle follows them, or a white candle appears above the last black candle with a gap.

The final white candle closes above the close of the first candle in the pattern.

---

## Morning Star — نجمة الصباح

A major turning-point bottom pattern consisting of three candles:

1. A long black candle.
2. A small-bodied candle, white or black, appearing after a downward gap and forming a Star.
3. A long white candle that closes deeply into the range of the first session.

---

## Doji Morning Star — نجمة الصباح الدوجي

The same as the Morning Star, except that the middle candle is a Doji instead of a small candle.

Because of the presence of the Doji, it is more positive than the ordinary Morning Star.

---

## Morning Attack — هجمة الصباح

A Japanese term used to describe large buying or selling operations at the opening.

These operations are mainly used to move the market.

---

# O

## On-Neck Line — نموذج حصار المضيق

A pattern occurring during a declining trend.

It consists of:

1. A long black candle.
2. A white candle whose close is near the low of the black candle and below it.

This is a negative continuation pattern.

The market resumes its decline when prices break below the low of the white candle.

The source compares this pattern with:

- In-Neck Line.
- Thrusting Line.
- Piercing Pattern.

---

# P

## Petrifying Pattern — نموذج الإرعاب

Another name for the Harami pattern according to the supplied source.

---

## Piercing Pattern — نموذج ثقب الحُلِيّ

A major turning-point bottom signal.

During a declining trend:

1. A long black candle appears.
2. The following session gaps downward.
3. The session then ends as a long white candle.
4. The white candle closes above the midpoint of the previous black candle.

The source compares this pattern with:

- On-Neck Line.
- In-Neck Line.
- Thrusting Line.

---

# R

## Rain Drop — قطرة المطر

See **Star**.

---

## Real Body — جسم الشمعة

The thick part of the candle.

It represents the distance between the opening price and the closing price.

When the close is higher than the open, the candle is white or empty.

When the candle is black or filled, the close is lower than the open.

---

## Rickshaw Man — شمعة رَجُل الريكا

See **Long-Legged Doji**.

---

## Rising Three Methods — نموذج الهاربين الثلاثة الإيجابي

See **Three Methods**.

---

# S

## Separating Lines — الشموع انفصالية النزعة / المنشقة

During an upward or downward trend, the market opens at the same opening price as the previous session, whose color is opposite to the current session.

The market then closes higher or lower respectively.

The previous trend resumes after the candle.

---

## Shadows — ظلال الشموع

The thin lines above and below the real body.

They represent the extreme prices of the session.

### Lower Shadow

The line below the real body.

The bottom of this shadow is the low of the session.

### Upper Shadow

The line above the real body.

The top of this shadow is the high of the session.

---

## Shaven Bottom — الدَّبْر الحليق

A candle with no lower shadow.

---

## Shaven Head — الرأس الحليق

A candle with no upper shadow.

---

## Shooting Star — شمعة الشهاب

A candle with:

- A long upper shadow.
- A very small lower shadow or no lower shadow.
- A small real body near the bottom of the session.

It occurs during an upward trend.

The candle is considered a negative signal when it appears during an upward trend.

---

## Side-by-Side White Lines — الشمعتان البيضاوان المتحاذيتان بعد الفجوة

Two consecutive white candles with:

- The same opening price.
- Approximately equal real bodies.

When the pattern appears during an upward trend, it is positive for continuation.

When it appears during a downward trend after a downward gap, it becomes a negative continuation pattern.

In that case, the two candles represent two days in which short covering occurs.

These patterns are very rare.

---

## Spinning Tops — بلايل اللعب الدوَّارة

Candles with small real bodies.

---

## Stalled Pattern — النموذج المُعطَّل

A pattern in which a small white candle appears after a long white candle, either above it or at its high.

Sometimes a small white candle also appears before the long white candle.

When the pattern appears, the upward trend of the market becomes stalled.

The pattern is also called the **Deliberation Pattern**.

---

## Star — النجمة

A candle with a small real body that comes after a gap away from the preceding long candle.

The Star reflects a decrease in the previous trend.

Stars that appear after long black candles during a declining trend are sometimes called **Rain Drops**.

---

## Tasuki Gaps — فجوات تاسوكي

There are two types:

- Downside Tasuki Gap.
- Upside Tasuki Gap.

### Downside Tasuki Gap

It occurs during a declining market.

A black candle appears after a downward gap.

It is followed by a white candle approximately equal in size.

The white candle opens within the range of the black candle and closes above the black candle's body, above its opening price.

The Downside Tasuki Gap is a bearish continuation pattern.

### Upside Tasuki Gap

It is a bullish continuation pattern.

A white candle appears after an upward gap.

It is followed by a black candle approximately equal in size.

The black candle opens within the range of the white candle and closes below the white candle's body, below its opening price.

Tasuki Gaps are rare.

---

# T

## Three Buddha Patterns — نموذج تماثيل بوذا الثلاثة

### Three Buddha Top

The Three Buddha Top corresponds to the Western Head and Shoulders pattern.

In Japanese terminology, it is the Three Mountain Tops pattern, where the middle peak is the highest of the three.

### Inverted Three Buddha

The Inverted Three Buddha corresponds to the Western Inverted Head and Shoulders pattern.

In Japanese terminology, it is the Three River Bottoms pattern, where the middle valley is the deepest.

---

## Three Crows — الغربان الثلاثة

Three consecutive long black candles.

They close at or near their lowest prices.

The pattern is a major turning-point top, especially when it appears at high price levels or after a long upward trend.

---

## Three Gaps — الفجوات الثلاثة

If a poor candlestick signal appears after three upward gaps, buying forces are considered to be nearing exhaustion.

If a positive candlestick signal appears after three downward gaps, selling forces are considered to be nearing exhaustion.

---

## Three Methods — الهاربين الثلاثة

There are two forms.

### Bearish Three Methods

A bearish continuation pattern consisting of five candles:

1. A long black candle.
2. Three small candles, often white, remaining within the range of the first black candle.
3. A black candle closing at a new low for the downward movement.

### Bullish Three Methods

A bullish continuation pattern consisting of:

1. A long white candle.
2. Three small candles, often black, remaining within the range of the first white candle.
3. A long white fifth candle closing at a new high for the upward movement.

---

## Three Mountain Top — قمة الجبال الثلاثة

A long-term top pattern in which the upward movement stops at the same highs or near the same highs.

The pattern is sometimes described as the **Three Rising Waves**.

---

## Three River Bottom — قاع الأنهار الثلاثة

A pattern in which the market reaches a bottom area three times.

The market then exceeds the highest peak between those valleys through a white candle or an upward gap.

This provides confirmation that the bottom has formed.

---

## Three White / Three Advancing Soldiers — الفدائيين الثلاثة

A group consisting of three white candles with progressively higher closes.

Each close is higher than the previous one.

These three candles indicate increasing strength when they appear after a period of price stability, particularly when prices are low.

---

## Thrusting Line — نموذج اقتحام المضيق

A white candle that closes inside the range of the preceding black candle but does not move above the midpoint of that range.

The Thrusting Line is stronger than the In-Neck Line but does not reach the strength of the Piercing Pattern.

According to the supplied source:

- It is a negative pattern during declining trends.
- An exception is when two such patterns appear within a short number of days.
- It is a positive pattern in rising markets.

---

## Towers — الأبراج

There are:

- Tower Tops.
- Tower Bottoms.

### Tower Top

A major turning-point top pattern.

It consists of:

1. A long white candle.
2. A congestion or sideways trading area.
3. A long black candle or group of long black candles.

The pattern appears as though there are towers on both sides of the congestion area.

### Tower Bottom

A major turning-point bottom pattern.

It consists of:

1. A long black candle.
2. A sideways market movement.
3. An upward breakout through a number of long white candles.

---

## Tri-Star — النموذج ثلاثي النجوم

A pattern consisting of three Doji candles.

Their formation resembles a Morning Star or Evening Star.

The pattern is very rare and is a major turning-point signal.

---

## Tweezers Top and Bottom — القمم والقيعان الملاقيط

These patterns form when the same price level is tested twice consecutively or within a few days.

The tested level may be:

- A high, forming a Tweezers Top.
- A low, forming a Tweezers Bottom.

They represent a minor turning-point signal.

Their importance increases when the two candles also form another candlestick pattern.

For example, if the two highs of a Harami Cross are equal, this indicates an important turning-point top because the pattern becomes both a Tweezers Top and a bearish Harami Cross.

---

## Unique Three River Bottom — القاع الفريد للأنهار الثلاثة

A rare bottom pattern consisting of three candles:

1. A long black candle.
2. A black candle similar to a Hammer that reaches a new low.
3. A small-bodied candle.

---

# U

## Upper Shadow — الظل العلوي

See **Shadows**.

---

## Upside Gap Tasuki — فجوة تاسوكي الصاعدة

See **Tasuki Gaps**.

---

## Upside Gap Two Crows — الغربان فوق الفجوة الصاعدة

A three-candle pattern:

1. A long white candle.
2. A black candle separated from it by an upward gap.
3. Another black candle that opens above the opening of the second candle and closes below the close of the second candle.

The pattern is a major turning-point top signal.

---

# W

## Windows — النوافذ

Windows are the same as gaps in Western analysis.

They are continuation patterns.

When the market rises and opens a Window, the market should make an orderly pullback toward the Window, and the Window becomes support.

When the Window opens during a sharp decline, the market rises toward the Window again, and the Window becomes resistance.

The Japanese expression states:

> "The market goes toward the Window."

---

# Y

## Yin and Yang — ين ويانج

Chinese names used for candle colors:

- Yin = Black candle.
- Yang = White candle.

---

# Cross-References

The supplied source contains the following cross-references:

| Term | Reference |
|---|---|
| Deliberation Pattern | Stalled Pattern |
| Low-Price Gapping Plays | Gapping Plays |
| High-Price Gapping Plays | Gapping Plays |
| Lower Shadows | Shadows |
| Rain Drop | Star |
| Rickshaw Man | Long-Legged Doji |
| Rising Three Methods | Three Methods |
| Inverted Three Buddha Pattern | Three Buddha Patterns |
| Upper Shadow | Shadows |
| Upside Gap Tasuki | Tasuki Gaps |

---

# Source Limitation

This glossary is based only on the supplied **Book Summary (A) — Candlesticks and Visual Dictionary**.

No external definitions, classifications, statistics, or trading interpretations have been added.

Where the source says "see" or "راجع", the cross-reference is preserved rather than inventing a missing definition.

The Western technical terminology contained in **Summary (B)** is documented separately.