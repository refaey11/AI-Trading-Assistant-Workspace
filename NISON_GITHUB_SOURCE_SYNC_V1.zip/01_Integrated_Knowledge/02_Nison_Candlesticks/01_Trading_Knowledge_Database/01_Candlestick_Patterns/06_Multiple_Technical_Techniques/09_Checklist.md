# Checklist

□ Trend identified

□ Candlestick confirmation

□ Support / Resistance confirmed

□ Fibonacci alignment

□ Trendline alignment

□ Volume confirmation

□ Risk / Reward acceptable

□ Stop Loss defined

□ Market agrees with analysis

□ Multiple techniques aligned