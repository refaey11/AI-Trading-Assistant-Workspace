# Gold Example

Source:
Book – Part II

## Scenario

Gold broke above a major two-year downtrend line.

At the same time,
strong support had already formed near 357.

The expected resistance zone became:

425–433

---

## Why?

Four independent technical methods pointed to exactly the same area.

### 1. Fibonacci Retracement

50% retracement projected resistance near:

430

---

### 2. Double Bottom

Price target projected:

425

---

### 3. Previous High

Historical resistance existed near:

433

---

### 4. Elliott Wave Analysis

Wave Four projection also suggested:

425

---

## Conclusion

Multiple independent techniques confirmed the same resistance zone.

The market reversed almost exactly there.

This demonstrates the Rule of Multiple Technical Techniques.

## Lesson

The stronger the confluence,

the stronger the support or resistance.