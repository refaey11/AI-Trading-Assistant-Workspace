# Core Principles

Source:
Book – Part II

## Principle 1

Never rely on a single technical indicator.

---

## Principle 2

Japanese Candlesticks become much stronger when confirmed by Western Technical Analysis.

---

## Principle 3

Important support and resistance levels usually attract several technical confirmations.

---

## Principle 4

Market context is more important than individual candlestick patterns.

---

## Principle 5

Always search for confluence.

Confluence = Multiple independent signals supporting the same trading decision.