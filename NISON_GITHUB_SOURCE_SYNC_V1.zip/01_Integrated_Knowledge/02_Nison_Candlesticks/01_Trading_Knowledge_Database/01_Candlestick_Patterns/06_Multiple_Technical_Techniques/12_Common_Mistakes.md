# Common Mistakes

- Trading based on one signal.
- Ignoring market context.
- Fighting the trend.
- Ignoring support and resistance.
- Refusing to change opinion.
- Trading without Stop Loss.
- Ignoring price reaction after major news.
- Believing the market is wrong.