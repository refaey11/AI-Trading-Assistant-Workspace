# Confidence Model

Low

- Breakout only

Medium

- False breakout confirmed

High

- False breakout + Candlestick confirmation

Very High

- False breakout + Multiple confirmations + Strong support/resistance + Trend agreement