# Trading Rules

## Rule 1

Never trade a breakout immediately.

Wait to see whether price can remain outside the broken level.

---

## Rule 2

An Upthrust becomes a valid bearish signal only after price closes back below the previous resistance.

---

## Rule 3

A Spring becomes a valid bullish signal only after price closes back above the previous support.

---

## Rule 4

Always wait for candlestick confirmation.

Bearish confirmation for Upthrust:

- Shooting Star
- Bearish Engulfing
- Hanging Man

Bullish confirmation for Spring:

- Hammer
- Bullish Engulfing
- Morning Star

---

## Rule 5

The farther price penetrates the level before failing, the more powerful the reversal may become.

---

## Rule 6

False breakouts occurring after prolonged trading ranges deserve greater attention.

---

## Rule 7

Use the extreme high (Upthrust) or extreme low (Spring) as the protective stop.

---

## Rule 8

Never analyze a false breakout without considering support, resistance and trend.