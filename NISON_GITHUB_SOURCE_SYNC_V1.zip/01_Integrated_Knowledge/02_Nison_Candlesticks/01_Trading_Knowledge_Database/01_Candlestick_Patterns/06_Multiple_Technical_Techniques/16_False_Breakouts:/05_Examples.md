# Examples

---

# Example 1 — Figure 11.12

## Context

Price temporarily broke above resistance.

## Pattern

Upthrust

## Candlestick Confirmation

Bearish reversal

## Result

Price quickly returned inside the trading range.

## Lesson

Failed breakouts above resistance frequently become strong bearish signals.

---

# Example 2 — Figure 11.13

## Context

Price temporarily broke below support.

## Pattern

Spring

## Candlestick Confirmation

Bullish reversal

## Result

Price recovered above support.

## Lesson

False breakdowns frequently become strong bullish opportunities.

---

# Example 3 — Figure 11.14

## Context

Price exceeded resistance.

## Candlestick Confirmation

- Shooting Star
- Hanging Man

## Result

The breakout failed.

## Lesson

Multiple bearish candlestick signals confirmed the Upthrust.

---

# Example 4 — Figure 11.15

## Context

CRB Index exceeded resistance.

## Pattern

Shooting Star

## Result

The breakout failed immediately.

## Lesson

A Shooting Star directly after a breakout strengthens the bearish case.

---

# Example 5 — Figure 11.16

## Context

Price exceeded previous highs.

## Pattern

Hanging Man

## Result

False breakout.

## Lesson

Not every new high represents strength.

---

# Example 6 — Figure 11.17

## Context

Price briefly broke below support.

## Pattern

Spring

## Candlestick Confirmation

Hammer

## Result

Strong rally followed.

## Lesson

Spring + Hammer forms a high-quality bullish setup.

---

# Example 7 — Figure 11.18

## Context

Support failed temporarily.

## Pattern

Spring

## Candlestick Confirmation

Hammer

## Result

Bullish reversal until Evening Star appeared.

---

# Example 8 — Figure 11.19

## Context

Price moved below previous lows.

## Pattern

Spring

## Candlestick Confirmation

Hammer

## Result

Strong upward reversal.

---

# Example 9 — Figure 11.20

## Context

Soybean prices briefly broke support.

## Pattern

Spring

## Candlestick Confirmation

Bullish Engulfing

## Result

Bullish continuation.

## Lesson

Spring combined with Bullish Engulfing provides excellent confirmation.