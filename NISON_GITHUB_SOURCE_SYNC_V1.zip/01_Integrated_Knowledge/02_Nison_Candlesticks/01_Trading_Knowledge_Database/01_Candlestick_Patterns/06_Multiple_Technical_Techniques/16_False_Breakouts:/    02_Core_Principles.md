# Core Principles

## Principle 1

A false breakout occurs when price breaks an important level but quickly returns inside the previous range.

---

## Principle 2

An Upthrust is a false breakout above resistance.

---

## Principle 3

A Spring is a false breakdown below support.

---

## Principle 4

False breakouts trap traders who entered the breakout prematurely.

---

## Principle 5

Candlestick confirmation greatly increases the reliability of false breakout signals.

---

## Principle 6

Bearish candlestick patterns strengthen Upthrust signals.

---

## Principle 7

Bullish candlestick patterns strengthen Spring signals.

---

## Principle 8

False breakouts frequently lead to strong moves in the opposite direction.

---

## Principle 9

The larger the failed breakout, the stronger the potential reversal.

---

## Principle 10

False breakouts should always be evaluated within overall market context.