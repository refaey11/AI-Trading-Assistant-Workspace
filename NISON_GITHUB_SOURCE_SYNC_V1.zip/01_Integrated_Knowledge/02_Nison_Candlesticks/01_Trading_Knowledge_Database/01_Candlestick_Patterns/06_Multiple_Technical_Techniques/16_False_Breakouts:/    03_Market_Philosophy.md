# Market Philosophy

Markets constantly test support and resistance.

Not every breakout succeeds.

Professional traders often use false breakouts to identify whether genuine buying or selling pressure exists.

An Upthrust shows that buyers temporarily pushed prices above resistance but failed to maintain control.

A Spring shows that sellers temporarily pushed prices below support but failed to continue the decline.

These failures reveal that the opposite side has regained control.

Candlestick patterns help distinguish genuine breakouts from false ones by displaying the behavior of buyers and sellers immediately after the breakout attempt.

False breakouts represent moments where market psychology changes rapidly, creating attractive reversal opportunities.