# Common Mistakes

## Mistake 1

Buying every breakout.

---

## Mistake 2

Selling every breakdown.

---

## Mistake 3

Ignoring candlestick confirmation.

---

## Mistake 4

Ignoring trend direction.

---

## Mistake 5

Placing stop-loss inside the breakout zone.

---

## Mistake 6

Confusing genuine breakouts with Upthrusts or Springs.

---

## Mistake 7

Ignoring market context.

---

## Mistake 8

Entering before the breakout failure is confirmed.