# Backtesting

Record:

Market

Date

Pattern

Spring / Upthrust

Support / Resistance

Candlestick Confirmation

Entry

Stop

Target

Result

Questions:

Did price remain outside?

Was the breakout false?

Did candlestick confirmation improve accuracy?

Was stop placement correct?