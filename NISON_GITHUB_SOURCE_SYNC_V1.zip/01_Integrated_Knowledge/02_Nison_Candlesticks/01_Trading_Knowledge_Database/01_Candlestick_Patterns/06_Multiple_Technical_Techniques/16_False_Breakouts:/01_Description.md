# Description

## False Breakouts

False breakouts occur when price temporarily breaks through a significant support or resistance level but fails to continue in the breakout direction.

Instead, price quickly reverses back into the previous trading range.

These events often trap traders who entered the breakout too early.

Steve Nison combines classical Western chart analysis with Japanese candlestick techniques to identify these situations more accurately.

Two of the most important false breakout concepts are:

- Upthrust
- Spring

Candlestick confirmation greatly improves the reliability of these signals by revealing whether buyers or sellers have actually lost control after the breakout attempt.

False breakouts often produce high-probability reversal opportunities because they expose trapped market participants.