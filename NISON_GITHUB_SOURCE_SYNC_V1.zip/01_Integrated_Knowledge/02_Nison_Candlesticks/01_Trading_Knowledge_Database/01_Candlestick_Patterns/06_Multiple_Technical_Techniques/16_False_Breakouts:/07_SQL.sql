CREATE TABLE false_breakouts (

id INTEGER PRIMARY KEY,

code TEXT,

pattern TEXT,

direction TEXT,

confirmation TEXT,

figure TEXT,

message TEXT

);

INSERT INTO false_breakouts VALUES
(1,'FB001','Upthrust','Bearish',
'Shooting Star','11.12',
'False breakout above resistance');

INSERT INTO false_breakouts VALUES
(2,'FB002','Spring','Bullish',
'Hammer','11.13',
'False breakdown below support');

INSERT INTO false_breakouts VALUES
(3,'FB003','Upthrust','Bearish',
'Hanging Man','11.14',
'Bearish reversal');

INSERT INTO false_breakouts VALUES
(4,'FB004','Spring','Bullish',
'Bullish Engulfing','11.20',
'Bullish continuation');