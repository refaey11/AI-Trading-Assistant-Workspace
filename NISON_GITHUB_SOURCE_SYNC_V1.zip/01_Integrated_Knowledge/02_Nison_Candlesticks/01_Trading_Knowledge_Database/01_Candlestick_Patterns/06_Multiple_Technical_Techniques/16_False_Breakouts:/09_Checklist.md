# Checklist

☐ Breakout identified

☐ Price returned inside range

☐ Candlestick confirmation exists

☐ Trend analyzed

☐ Support/Resistance confirmed

☐ Entry defined

☐ Stop Loss defined

☐ Risk/Reward acceptable