# Confidence Model

1 confirmation
⭐⭐☆☆☆

2 confirmations
⭐⭐⭐☆☆

3 confirmations
⭐⭐⭐⭐☆

4 or more confirmations
⭐⭐⭐⭐⭐

Never assign maximum confidence without confluence.