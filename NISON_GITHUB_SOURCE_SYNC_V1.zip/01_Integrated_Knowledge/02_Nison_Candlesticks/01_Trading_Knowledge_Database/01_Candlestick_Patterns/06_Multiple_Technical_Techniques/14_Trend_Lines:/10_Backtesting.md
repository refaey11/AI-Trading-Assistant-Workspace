# Backtesting Guide

For every historical trade record:

Record:

- Market
- Timeframe
- Date

Trend Line Type:

- Up
- Down

Interaction:

- Test
- Break
- False Break

Candlestick Pattern:

Entry Price

Stop Loss

Target

Result

Maximum Favorable Excursion (MFE)

Maximum Adverse Excursion (MAE)

Notes

Questions:

1. Was the trend line respected?

2. Was candlestick confirmation present?

3. Did market context support the trade?

4. Was the stop-loss placed correctly?

5. Could the trade have been improved?