# Market Philosophy

Trend lines describe the direction of price.

Candlesticks describe the behavior of buyers and sellers.

Neither tool is complete without the other.

A trend line only tells where the market is moving.

Candlestick patterns explain how the market reacts when it reaches that trend line.

When price reaches an important trend line, traders should not immediately assume continuation or reversal.

Instead, they should observe the candlestick behavior around that level.

Bullish candlestick patterns appearing at rising trend lines suggest buyers are defending the trend.

Bearish candlestick patterns appearing at falling trend lines suggest sellers remain in control.

The strongest trading opportunities occur when trend lines and candlestick signals agree.