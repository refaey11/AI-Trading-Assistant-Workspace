# Trend Line Checklist

Before taking a trade, verify:

☐ At least two swing points define the trend line.

☐ Trend line has already been tested.

☐ Current trend is identified.

☐ Price is interacting with the trend line.

☐ Candlestick confirmation exists.

☐ Market structure agrees.

☐ Stop-loss location is defined.

☐ Risk-to-reward ratio is acceptable.

☐ No contradictory major resistance/support nearby.

☐ Trade follows the primary trend whenever possible.