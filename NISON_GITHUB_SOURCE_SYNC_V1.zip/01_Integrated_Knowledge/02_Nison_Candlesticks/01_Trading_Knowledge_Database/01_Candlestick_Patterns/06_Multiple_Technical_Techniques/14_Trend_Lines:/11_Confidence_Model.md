# Confidence Model

## Low Confidence

- New trend line
- No candlestick confirmation

---

## Medium Confidence

- Trend line tested twice
- One confirming candlestick

---

## High Confidence

- Multiple successful tests
- Strong reversal candlestick
- Trend direction agrees
- Clear market structure

---

## Very High Confidence

- Long-established trend line
- Multiple candlestick confirmations
- Strong trend
- Confluence with support or resistance