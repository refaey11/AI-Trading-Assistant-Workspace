CREATE TABLE trend_lines (

    id INTEGER PRIMARY KEY,

    code TEXT,

    concept TEXT,

    trend_type TEXT,

    candlestick_confirmation TEXT,

    market_bias TEXT,

    figure TEXT,

    trading_message TEXT

);

INSERT INTO trend_lines VALUES
(1,'TL001','Up Trend Line','Bullish',
'Hammer, Morning Star, Bullish Engulfing',
'Bullish','11.4',
'Support confirmed');

INSERT INTO trend_lines VALUES
(2,'TL002','Down Trend Line','Bearish',
'Shooting Star, Evening Star, Bearish Engulfing',
'Bearish','11.7',
'Resistance confirmed');

INSERT INTO trend_lines VALUES
(3,'TL003','Trend Line Test','Neutral',
'Hammer',
'Bullish','11.5',
'Trend line respected');

INSERT INTO trend_lines VALUES
(4,'TL004','Trend Line Break','Neutral',
'Confirmation Required',
'Neutral','11.11',
'Possible trend change');

INSERT INTO trend_lines VALUES
(5,'TL005','Candlestick Confirmation','Neutral',
'Multiple Patterns',
'Context Dependent','11.3-11.11',
'Combine trend lines with candlestick signals');