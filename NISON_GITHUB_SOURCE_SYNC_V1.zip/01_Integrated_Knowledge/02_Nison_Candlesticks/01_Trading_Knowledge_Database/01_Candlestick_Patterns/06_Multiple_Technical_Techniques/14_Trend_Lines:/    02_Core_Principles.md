# Core Principles

## Principle 1

Trend lines require at least two important swing points.

---

## Principle 2

An upward trend line is drawn by connecting higher lows.

---

## Principle 3

A downward trend line is drawn by connecting lower highs.

---

## Principle 4

The more times a trend line is successfully tested, the stronger it becomes.

---

## Principle 5

Candlestick patterns increase the reliability of trend-line tests.

---

## Principle 6

A bullish candlestick pattern appearing at an upward trend line strengthens the probability that support will hold.

---

## Principle 7

A bearish candlestick pattern appearing at a downward trend line strengthens the probability that resistance will hold.

---

## Principle 8

Trend lines should never be analyzed independently.

Always combine them with candlestick analysis.

---

## Principle 9

A successful trend-line test is more significant when confirmed by reversal candlestick patterns.

---

## Principle 10

A broken trend line represents a warning.

Candlestick confirmation determines whether the break is genuine or false.