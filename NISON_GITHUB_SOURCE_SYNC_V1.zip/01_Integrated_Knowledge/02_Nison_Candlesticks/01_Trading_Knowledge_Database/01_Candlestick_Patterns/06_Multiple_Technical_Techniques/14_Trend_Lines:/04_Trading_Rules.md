# Trading Rules

## Rule 1

Always draw a trend line using at least two significant swing points.

A third successful test increases its reliability.

---

## Rule 2

Never trade solely because price touches a trend line.

Wait for candlestick confirmation.

---

## Rule 3

Bullish candlestick patterns appearing at an upward trend line strengthen buying opportunities.

Examples include:

- Hammer
- Morning Star
- Bullish Engulfing

---

## Rule 4

Bearish candlestick patterns appearing at a downward trend line strengthen selling opportunities.

Examples include:

- Shooting Star
- Evening Star
- Bearish Engulfing

---

## Rule 5

The longer a trend line remains valid...

the more significant it becomes.

---

## Rule 6

The more successful tests a trend line survives...

the stronger the market considers it.

---

## Rule 7

A broken trend line is only an early warning.

Always seek candlestick confirmation before assuming a trend reversal.

---

## Rule 8

Use nearby candlestick highs or lows to position stop-loss orders after confirmed trend-line reactions.

---

## Rule 9

Trend lines identify market direction.

Candlesticks determine whether buyers or sellers are actually defending that trend.

---

## Rule 10

Never analyze trend lines without considering overall market context.