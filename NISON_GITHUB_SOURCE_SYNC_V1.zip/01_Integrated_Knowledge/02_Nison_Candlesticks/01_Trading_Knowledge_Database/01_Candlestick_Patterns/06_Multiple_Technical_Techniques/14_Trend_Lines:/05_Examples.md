# Examples

---

# Example 1 — Figure 11.3

## Context

Candlestick charts can be used with classical chart analysis exactly as bar charts.

## Observation

A neckline for a Head and Shoulders pattern can be drawn normally on a candlestick chart.

## Lesson

Candlestick charts enhance—not replace—traditional trend-line analysis.

---

# Example 2 — Figure 11.4

## Context

Price successfully retested an important support area.

## Candlestick Confirmation

Morning Star

## Result

Support held and the market rallied strongly.

## Lesson

A Morning Star occurring during a successful support test greatly strengthens the support.

---

# Example 3 — Figure 11.5

## Context

An upward trend line was tested repeatedly.

## Candlestick Confirmation

Bullish Hammer

## Result

The trend line held and the uptrend continued.

## Lesson

A Hammer appearing on an established trend line provides a high-quality buying opportunity.

---

# Example 4 — Figure 11.6

## Context

Dark Cloud Cover patterns formed near resistance.

## Result

Resistance became stronger.

## Lesson

Bearish candlestick patterns reinforce trend-line resistance.

---

# Example 5 — Figure 11.7

## Context

Price repeatedly failed to break resistance.

## Candlestick Confirmation

- Long-legged Doji
- Shooting Star
- Bearish Engulfing

## Lesson

Multiple bearish candlestick signals at resistance significantly increase reversal probability.

---

# Example 6 — Figure 11.8

## Context

Bearish Engulfing formed beneath resistance.

## Result

Price failed to continue upward.

## Lesson

Trend-line resistance becomes more reliable when confirmed by bearish engulfing patterns.

---

# Example 7 — Figure 11.9

## Context

Price approached an upward-sloping resistance trend line.

## Observation

Long positions required defensive action.

## Lesson

Failure to break rising resistance may signal an approaching correction.

---

# Example 8 — Figure 11.10

## Context

Price approached a downward-sloping support trend line.

## Observation

Short sellers should prepare for temporary rebounds.

## Lesson

Trend-line support can remain important even within a larger downtrend.

---

# Example 9 — Figure 11.11

## Context

Price tested an upward-sloping resistance line.

## Candlestick Confirmation

- Shooting Star
- Hanging Man

## Result

The market entered a correction.

## Lesson

Trend-line failure combined with bearish candlestick patterns provides an early warning of trend weakness.