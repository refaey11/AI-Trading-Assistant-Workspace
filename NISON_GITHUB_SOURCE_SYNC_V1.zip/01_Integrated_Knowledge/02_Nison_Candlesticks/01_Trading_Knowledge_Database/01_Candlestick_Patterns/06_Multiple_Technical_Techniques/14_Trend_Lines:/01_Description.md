# Description

## Trend Lines

Trend lines are one of the oldest and most fundamental tools in technical analysis.

A trend line is created by connecting at least two significant price points.

- In an uptrend, the trend line connects rising lows.
- In a downtrend, the trend line connects falling highs.

Japanese candlestick charts do not replace trend lines.

Instead, candlestick patterns greatly improve the interpretation of trend-line behavior.

Candlestick signals help determine whether a trend line is likely to:

- Hold as support or resistance.
- Break.
- Produce a false breakout.
- Begin a market reversal.

Because of this, candlestick analysis adds depth and timing to traditional trend-line analysis.

---

## Key Concept

Trend lines identify market direction.

Candlestick patterns identify the strength or weakness of the market when price interacts with those trend lines.

The combination provides stronger trading decisions than using either tool alone.