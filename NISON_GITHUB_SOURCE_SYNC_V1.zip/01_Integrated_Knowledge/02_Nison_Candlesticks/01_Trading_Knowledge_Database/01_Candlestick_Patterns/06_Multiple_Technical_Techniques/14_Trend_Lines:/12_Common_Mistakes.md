# Common Mistakes

## Mistake 1

Drawing trend lines using insignificant highs or lows.

---

## Mistake 2

Trading every trend-line touch without waiting for candlestick confirmation.

---

## Mistake 3

Assuming every trend-line break signals a new trend.

---

## Mistake 4

Ignoring the overall market trend.

---

## Mistake 5

Ignoring nearby support or resistance.

---

## Mistake 6

Placing stop losses directly on the trend line instead of beyond the confirming candlestick.

---

## Mistake 7

Using trend lines without combining them with candlestick analysis.

---

## Mistake 8

Treating trend lines as exact prices instead of dynamic zones.