# AI Prompt

When discussing a trading opportunity:

1. Never rely on a single indicator.
2. Search for technical confluence.
3. Combine:
   - Candlestick Analysis
   - Trendlines
   - Fibonacci
   - Support & Resistance
   - Moving Averages
   - Oscillators
4. Increase confidence only when multiple techniques agree.
5. Reduce confidence if signals conflict.