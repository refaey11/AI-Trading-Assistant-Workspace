# Examples

---

# Example 1 — Figure 11.24

## Context

Previous resistance was broken.

## Result

Price later returned and found support.

## Lesson

Broken resistance became new support.

---

# Example 2 — Figure 11.25

## Context

Major resistance near 27,000 was broken.

## Result

The same level later acted as support.

## Lesson

Important historical levels often reverse their role.

---

# Example 3 — Figure 11.27

## Context

Intraday resistance levels at 0.72 and 0.7290 were broken.

## Result

Both levels later acted as support.

## Lesson

Polarity applies on every timeframe.

---

# Example 4 — Figure 11.28

## Context

Support near 1.85 failed.

## Result

Price later rallied back into that level.

## Lesson

Former support became new resistance.

---

# Example 5 — Figure 11.29

## Context

Price retested previous support.

## Candlestick Confirmation

Doji

## Result

Resistance held.

## Lesson

Candlestick confirmation strengthens polarity.

---

# Example 6 — Figure 11.30

## Context

Support around 1230 failed.

## Candlestick Confirmation

Dark Cloud Cover

## Result

The old support became resistance.

## Lesson

Multiple confirmations increase confidence.