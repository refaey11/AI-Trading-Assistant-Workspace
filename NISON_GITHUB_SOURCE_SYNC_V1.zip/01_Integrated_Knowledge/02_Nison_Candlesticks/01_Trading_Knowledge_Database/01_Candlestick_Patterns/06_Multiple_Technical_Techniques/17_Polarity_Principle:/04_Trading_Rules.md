# Trading Rules

## Rule 1

Do not assume polarity has changed immediately after a breakout.

Wait for a successful retest.

---

## Rule 2

Old resistance becomes support only after buyers successfully defend the retest.

---

## Rule 3

Old support becomes resistance only after sellers successfully reject the retest.

---

## Rule 4

Always require candlestick confirmation.

Bullish:

- Hammer
- Morning Star
- Bullish Engulfing

Bearish:

- Shooting Star
- Evening Star
- Bearish Engulfing
- Dark Cloud Cover

---

## Rule 5

The more important the original support or resistance level...

the more reliable the polarity change.

---

## Rule 6

Multiple historical reactions increase confidence.

---

## Rule 7

Treat polarity as a zone rather than an exact price.

---

## Rule 8

Always combine polarity with overall trend analysis.