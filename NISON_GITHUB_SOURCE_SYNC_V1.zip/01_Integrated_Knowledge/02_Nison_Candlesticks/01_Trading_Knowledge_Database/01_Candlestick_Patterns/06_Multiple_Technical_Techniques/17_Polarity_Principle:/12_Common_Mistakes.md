# Common Mistakes

## Mistake 1

Assuming every breakout creates polarity.

---

## Mistake 2

Ignoring the retest.

---

## Mistake 3

Ignoring candlestick confirmation.

---

## Mistake 4

Ignoring trend direction.

---

## Mistake 5

Treating polarity as an exact price.

---

## Mistake 6

Entering before confirmation.

---

## Mistake 7

Ignoring higher timeframe levels.

---

## Mistake 8

Using polarity without market context.