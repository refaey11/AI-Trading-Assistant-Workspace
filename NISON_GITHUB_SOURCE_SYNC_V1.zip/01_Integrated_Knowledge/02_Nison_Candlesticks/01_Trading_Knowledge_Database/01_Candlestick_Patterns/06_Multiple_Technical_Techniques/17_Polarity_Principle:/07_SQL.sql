CREATE TABLE polarity_principle (

id INTEGER PRIMARY KEY,

code TEXT,

concept TEXT,

confirmation TEXT,

market_bias TEXT,

figure TEXT,

message TEXT

);

INSERT INTO polarity_principle VALUES
(1,'PP001',
'Resistance becomes Support',
'Hammer',
'Bullish',
'11.24',
'Successful polarity');

INSERT INTO polarity_principle VALUES
(2,'PP002',
'Support becomes Resistance',
'Dark Cloud Cover',
'Bearish',
'11.30',
'Successful polarity');

INSERT INTO polarity_principle VALUES
(3,'PP003',
'Intraday Polarity',
'Bullish Confirmation',
'Bullish',
'11.27',
'Support confirmed');

INSERT INTO polarity_principle VALUES
(4,'PP004',
'Major Historical Level',
'Multiple Tests',
'Neutral',
'11.25',
'High significance');