# Backtesting

Record

Market

Date

Historical Level

Support → Resistance

Resistance → Support

Candlestick Pattern

Entry

Stop

Target

Result

Questions

Did polarity succeed?

Did candlestick confirmation improve accuracy?

Was trend aligned?

Could stop placement improve?