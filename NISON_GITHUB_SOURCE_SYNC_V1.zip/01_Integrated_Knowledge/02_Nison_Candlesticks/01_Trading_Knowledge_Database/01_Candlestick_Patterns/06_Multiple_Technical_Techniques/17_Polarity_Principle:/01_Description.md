# Description

## The Polarity Principle

The Polarity Principle states that once an important support level is broken, it often becomes future resistance.

Likewise, once an important resistance level is broken, it often becomes future support.

This concept reflects changing market psychology.

Buyers trapped above broken support often become future sellers.

Sellers trapped below broken resistance often become future buyers.

Japanese candlestick patterns provide valuable confirmation that the change of polarity is actually taking place.

Instead of assuming polarity has changed, traders should wait for candlestick confirmation at the retest.

The strongest polarity signals occur when the retest is accompanied by a clear reversal candlestick pattern.