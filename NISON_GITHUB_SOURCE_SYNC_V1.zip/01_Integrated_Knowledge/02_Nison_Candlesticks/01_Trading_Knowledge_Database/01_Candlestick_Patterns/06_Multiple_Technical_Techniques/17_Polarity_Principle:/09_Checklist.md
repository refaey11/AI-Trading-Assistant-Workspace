# Checklist

☐ Historical level identified.

☐ Breakout confirmed.

☐ Retest occurred.

☐ Candlestick confirmation exists.

☐ Trend agrees.

☐ Entry defined.

☐ Stop Loss defined.

☐ Risk/Reward acceptable.

☐ No nearby conflicting level.