# Market Philosophy

Markets remember important prices.

When an important support level breaks...

many buyers become trapped.

If price later returns to that level...

those trapped buyers often sell to exit their losing positions.

The former support therefore becomes resistance.

The opposite process occurs when resistance is broken.

Previous sellers become trapped.

When price later revisits the level...

those traders often buy back their positions.

Former resistance therefore becomes support.

Candlestick patterns reveal whether buyers or sellers successfully defend these new polarity zones.

Polarity is therefore a psychological phenomenon confirmed through price behavior.