# Confidence Model

Low

- No retest.

Medium

- Retest only.

High

- Retest + Candlestick confirmation.

Very High

- Major historical level + Multiple tests + Trend agreement + Strong candlestick confirmation.