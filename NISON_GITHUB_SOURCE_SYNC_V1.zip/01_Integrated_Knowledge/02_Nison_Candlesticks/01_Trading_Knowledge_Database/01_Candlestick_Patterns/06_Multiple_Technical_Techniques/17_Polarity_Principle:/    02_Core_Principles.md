# Core Principles

## Principle 1

Broken resistance frequently becomes future support.

---

## Principle 2

Broken support frequently becomes future resistance.

---

## Principle 3

The more important the original level...

the stronger the polarity effect.

---

## Principle 4

Multiple previous tests increase the significance of polarity.

---

## Principle 5

Candlestick confirmation increases confidence.

---

## Principle 6

Bullish candlesticks confirm new support.

---

## Principle 7

Bearish candlesticks confirm new resistance.

---

## Principle 8

Polarity should always be analyzed together with trend.

---

## Principle 9

Price rarely reverses exactly at one price.

Polarity creates zones rather than exact levels.

---

## Principle 10

Successful retests strengthen the validity of polarity.