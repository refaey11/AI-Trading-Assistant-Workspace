# Trading Rules

Source:
Book – Part II

## The Discipline Rules

### Rule 1
Do not forget old support and resistance levels.

Old resistance often becomes new support.
Old support often becomes new resistance.

---

### Rule 2
Use the "If... Then..." approach.

If the market confirms your analysis,
then stay in the trade.

If not,
exit immediately.

---

### Rule 3
Always use Stop Loss orders.

Never trade without predefined risk.

---

### Rule 4
Consider Options together with Futures.

Different markets provide additional confirmation.

---

### Rule 5
Intraday technical analysis matters.

Short-term price action often reveals market sentiment before larger moves.

---

### Rule 6
Adapt your trading style to market conditions.

Trending markets require different strategies than ranging markets.

---

### Rule 7
Never ignore Local Traders.

Professional floor traders often reveal important market behavior.

---

### Rule 8
Never trade believing the market is wrong.

Adapt to price.
Do not argue with it.

---

### Rule 9
Use Multiple Technical Techniques.

The greater the confluence,
the greater the probability.

---

### Rule 10
Study how price reacts to fundamental news.

Price reaction is often more important than the news itself.