# Backtesting

Evaluate:

- Number of confirming indicators.
- Win rate with 1 indicator.
- Win rate with 2 indicators.
- Win rate with 3 indicators.
- Win rate with 4+ indicators.

Objective:

Measure how technical confluence affects trade performance.