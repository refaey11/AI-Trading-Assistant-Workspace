# Candlestick Clusters Checklist

Before taking any trade, verify the following:

☐ Is there more than one candlestick signal?

☐ Are the signals independent?

☐ Did they form around the same price level?

☐ Is the cluster located at Support or Resistance?

☐ Does the trend support the trade?

☐ Has the level been tested previously?

☐ Is there confirmation from price action?

☐ Is the stop loss clearly defined?

☐ Is the reward greater than the risk?

Only enter the trade if most items are satisfied.