# Candlestick Clusters

## Chapter

Chapter 10 – A Confluence of Candles

---

## Definition

A Candlestick Cluster is the appearance of two or more bullish or bearish candlestick signals in the same price area.

Instead of relying on one candlestick pattern, several candlestick signals appear together, increasing the probability that the price level is important.

The market is not reacting to one pattern only.

It is reacting to a confluence of multiple candlestick signals.

---

## Core Idea

The more candlestick signals that appear around one price level...

The stronger that level becomes.

Clusters can identify:

- Major Tops
- Major Bottoms
- Strong Support
- Strong Resistance
- Trend Reversals
- Confirmation Zones

---

## Purpose

Candlestick Clusters help traders distinguish between:

- Weak reversal signals

and

- High-probability reversal zones.

Instead of asking:

"Is this Hammer important?"

The trader asks:

"How many signals agree at this level?"

---

## Principle

One signal gives attention.

Several signals give confidence.

---

## Examples Mentioned in Chapter

Examples include combinations of:

- Hammer
- Bullish Engulfing
- Piercing Pattern
- Tower Bottom
- Shooting Star
- Hanging Man
- Doji
- Dark Cloud Cover
- Bearish Engulfing
- Evening Star

appearing around the same support or resistance level.

---

## Trading Philosophy

A cluster does not predict the future.

It identifies an area where market participants repeatedly reacted.

That area deserves attention.