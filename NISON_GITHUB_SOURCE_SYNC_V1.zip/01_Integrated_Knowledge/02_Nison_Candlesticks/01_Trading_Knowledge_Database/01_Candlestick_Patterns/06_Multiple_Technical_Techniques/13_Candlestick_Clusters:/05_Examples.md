# Examples

---

# Example 1 — Crude Oil (1989)

### Signals

- Hanging Man
- Doji
- Hammer
- Bullish Engulfing

### Observation

The market produced several candlestick signals around the same price area.

Instead of treating every pattern separately...

the combination identified one important support zone.

The subsequent bullish engulfing confirmed the strength of that support.

### Lesson

Multiple bullish and bearish candlestick patterns appearing around one price level create a more meaningful trading area than isolated signals.

---

# Example 2 — Bonds

### Signals

- Hammer
- Hanging Man
- Doji
- Shooting Star

### Observation

Three bearish reversal candles appeared after a prolonged advance.

The combination produced a much stronger warning than any single pattern.

### Lesson

Clusters increase the probability of reversal.

---

# Example 3 — Fujitsu

### Signals

- Resistance
- Shooting Star
- Harami

### Observation

The bearish candlestick cluster developed exactly at resistance.

Price respected the resistance level and reversed lower.

### Lesson

Candlestick clusters become much stronger when they appear at important support or resistance.

---

# Example 4 — Exxon

### Signals

- Tweezers Bottom
- Hammer
- Bullish Engulfing

### Observation

Several bullish candlestick patterns appeared during repeated support testing.

The market eventually reversed upward.

### Lesson

Repeated bullish clusters reinforce support.

---

# Example 5 — Sugar

### Signals

- Doji Star
- Shooting Star
- Three Hanging Men

### Observation

Several bearish candlestick signals appeared around the same high.

Each signal reinforced the previous one.

### Lesson

Multiple bearish signals clustered together dramatically increase reversal probability.

---

# Example 6 — Wheat

### Signals

- Hanging Man
- Evening Star
- Harami
- Shooting Star

### Observation

Four bearish patterns developed around one resistance level.

Price failed to continue higher and declined.

### Lesson

The more independent bearish signals appear together...

the stronger the resistance becomes.

---

# Example 7 — Copper

### Signals

- Hanging Man
- Shooting Star
- Doji Star

### Observation

The market repeatedly failed near the same resistance zone.

The previous resistance later became support.

### Lesson

Clusters help identify important price zones instead of exact prices.

---

# Example 8 — British Pound

### Signals

- Hanging Man
- Doji
- Dark Cloud Cover
- Window
- Tweezers Bottom
- Bullish Belt Hold

### Observation

Support and resistance shifted during the trend.

Each new candlestick cluster confirmed the importance of these levels.

### Lesson

Candlestick clusters continuously redefine market support and resistance.