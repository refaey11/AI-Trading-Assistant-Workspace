# Core Principles

## Principle 1

A single candlestick pattern can identify a reversal.

A cluster of candlestick patterns identifies an important price zone.

---

## Principle 2

The more independent candlestick signals that appear around the same price level...

the stronger the support or resistance becomes.

---

## Principle 3

Clusters are created when different candlestick patterns point to the same market conclusion.

Examples include:

- Hammer + Bullish Engulfing
- Doji + Shooting Star
- Hanging Man + Evening Star
- Hammer + Tweezer Bottom

---

## Principle 4

A single candlestick may generate more than one signal.

Example:

A candle may simultaneously be:

- Shooting Star
- Harami
- Resistance Rejection

This strengthens its importance.

---

## Principle 5

Clusters are stronger when they occur:

- At previous support
- At previous resistance
- Near important highs
- Near important lows

---

## Principle 6

The market often tests an important support level more than once.

If multiple bullish candlestick patterns appear during these tests...

support becomes much stronger.

---

## Principle 7

Likewise,

if multiple bearish candlestick patterns appear near resistance...

that resistance becomes much stronger.

---

## Principle 8

Clusters should never be evaluated using one candle only.

Always evaluate:

- Previous candles
- Current pattern
- Nearby support
- Nearby resistance

---

## Principle 9

A failed breakout that is accompanied by bearish candlestick clusters greatly increases reversal probability.

---

## Principle 10

Likewise,

a failed breakdown that is accompanied by bullish candlestick clusters greatly increases reversal probability.

---

## Principle 11

Support and resistance become stronger when candlestick clusters repeatedly appear at the same price level.

---

## Principle 12

Clusters provide confirmation.

They do not replace trend analysis.

Always combine clusters with:

- Trend
- Support & Resistance
- Volume
- Market Context