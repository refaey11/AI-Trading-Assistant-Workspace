-- =====================================================
-- Chapter 13 : Candlestick Clusters
-- Source : Steve Nison
-- =====================================================

CREATE TABLE candlestick_clusters (

    id INT PRIMARY KEY,

    market VARCHAR(100),

    timeframe VARCHAR(30),

    bias VARCHAR(30),

    location VARCHAR(50),

    patterns TEXT,

    lesson TEXT

);

---------------------------------------------------------

INSERT INTO candlestick_clusters VALUES
(
1,
'Crude Oil',
'Daily',
'Mixed -> Bullish',
'Support',
'Hanging Man, Doji, Hammer, Bullish Engulfing',
'Multiple candlestick signals appearing around the same support level create a much stronger support zone than any single candlestick.'
);

---------------------------------------------------------

INSERT INTO candlestick_clusters VALUES
(
2,
'Bonds',
'Weekly',
'Bearish',
'Resistance',
'Hammer, Hanging Man, Doji, Shooting Star',
'Several bearish reversal candles appearing together provide a stronger reversal warning.'
);

---------------------------------------------------------

INSERT INTO candlestick_clusters VALUES
(
3,
'Fujitsu',
'Daily',
'Bearish',
'Resistance',
'Shooting Star, Harami',
'Candlestick clusters become significantly more reliable when they develop at resistance.'
);

---------------------------------------------------------

INSERT INTO candlestick_clusters VALUES
(
4,
'Exxon',
'Weekly',
'Bullish',
'Support',
'Tweezers Bottom, Hammer, Bullish Engulfing',
'Repeated bullish candlestick clusters reinforce important support.'
);

---------------------------------------------------------

INSERT INTO candlestick_clusters VALUES
(
5,
'Sugar',
'Daily',
'Bearish',
'Resistance',
'Doji Star, Shooting Star, Hanging Man',
'Several bearish candlestick signals reinforcing each other greatly increase reversal probability.'
);

---------------------------------------------------------

INSERT INTO candlestick_clusters VALUES
(
6,
'Wheat',
'Daily',
'Bearish',
'Resistance',
'Hanging Man, Evening Star, Harami, Shooting Star',
'The greater the number of independent bearish signals appearing together, the stronger the resistance.'
);

---------------------------------------------------------

INSERT INTO candlestick_clusters VALUES
(
7,
'Copper',
'Daily',
'Bearish',
'Resistance',
'Hanging Man, Shooting Star, Doji',
'Candlestick clusters identify important price zones rather than precise prices.'
);

---------------------------------------------------------

INSERT INTO candlestick_clusters VALUES
(
8,
'British Pound',
'Weekly',
'Mixed',
'Support & Resistance',
'Hanging Man, Doji, Dark Cloud Cover, Window, Tweezers Bottom, Bullish Belt Hold',
'Support and resistance evolve over time while candlestick clusters confirm each new significant level.'
);