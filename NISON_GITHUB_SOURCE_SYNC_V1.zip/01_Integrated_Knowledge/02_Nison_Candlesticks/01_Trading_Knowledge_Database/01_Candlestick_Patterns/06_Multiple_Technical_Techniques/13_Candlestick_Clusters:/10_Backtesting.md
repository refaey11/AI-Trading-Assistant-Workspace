# Backtesting

## Objective

Measure the effectiveness of Candlestick Clusters.

---

## Required Data

- Market
- Timeframe
- Date
- Support / Resistance
- Candlestick Patterns
- Trade Direction
- Entry
- Stop Loss
- Target
- Result

---

## Rules

1. Ignore isolated candlestick patterns.

2. Trade only confirmed clusters.

3. Record every setup.

4. Measure:

- Win Rate
- Average R:R
- Maximum Drawdown
- Expectancy

---

## Notes

Compare:

- Single Pattern
vs

- Candlestick Cluster

to determine whether clusters improve performance.