# Confidence Model

| Signals | Confidence |
|---------|-----------|
| 1 Signal | Low |
| 2 Signals | Moderate |
| 3 Signals | High |
| 4 Signals | Very High |
| 5+ Signals | Extreme |

---

## Confidence Increases When

- Cluster at Support
- Cluster at Resistance
- Trend agrees
- Previous tests exist
- Multiple independent patterns agree

---

## Confidence Decreases When

- Isolated candle
- No support/resistance
- Counter-trend trade
- Weak confirmation