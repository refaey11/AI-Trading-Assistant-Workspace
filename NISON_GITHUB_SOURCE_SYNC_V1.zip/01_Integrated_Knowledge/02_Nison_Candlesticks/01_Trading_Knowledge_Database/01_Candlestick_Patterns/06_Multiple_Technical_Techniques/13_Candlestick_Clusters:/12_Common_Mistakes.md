# Common Mistakes

## Mistake 1

Trading a single candlestick as if it were a cluster.

---

## Mistake 2

Ignoring Support and Resistance.

---

## Mistake 3

Counting similar candlestick patterns as independent confirmation.

---

## Mistake 4

Ignoring the overall market trend.

---

## Mistake 5

Treating support or resistance as an exact price instead of a zone.

---

## Mistake 6

Entering before confirmation.

---

## Mistake 7

Ignoring risk management because several signals appear together.

---

## Mistake 8

Believing every cluster must produce a reversal.

Clusters increase probability.

They never guarantee outcome.