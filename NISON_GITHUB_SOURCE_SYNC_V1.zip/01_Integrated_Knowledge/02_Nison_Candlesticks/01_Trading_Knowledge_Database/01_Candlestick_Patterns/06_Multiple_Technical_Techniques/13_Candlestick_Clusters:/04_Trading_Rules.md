# Trading Rules

## Rule 1

Never rely on a single candlestick pattern when multiple candlestick signals appear at the same price level.

A cluster is more reliable than an isolated pattern.

---

## Rule 2

The greater the number of independent candlestick signals within the same price area, the stronger the support or resistance.

---

## Rule 3

Always evaluate candlestick clusters together with nearby support and resistance.

Clusters occurring at important price levels deserve greater attention.

---

## Rule 4

Repeated successful tests of support accompanied by bullish candlestick patterns increase the probability that support will hold.

---

## Rule 5

Repeated failures near resistance accompanied by bearish candlestick patterns increase the probability that resistance will hold.

---

## Rule 6

One candlestick may produce multiple technical signals simultaneously.

When several signals agree, the probability of reversal increases.

---

## Rule 7

Never analyze a candlestick cluster without considering:

- Trend
- Previous price action
- Support and Resistance
- Overall market context

---

## Rule 8

Candlestick clusters identify important price **zones**, not exact prices.

Treat support and resistance as areas rather than single price levels.