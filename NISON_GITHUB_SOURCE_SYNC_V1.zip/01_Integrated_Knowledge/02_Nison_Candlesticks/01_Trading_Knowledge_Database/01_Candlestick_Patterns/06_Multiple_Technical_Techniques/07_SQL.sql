CREATE TABLE multiple_technical_techniques (
    id INTEGER PRIMARY KEY,
    concept TEXT,
    category TEXT,
    purpose TEXT,
    key_principle TEXT,
    reliability INTEGER,
    notes TEXT
);