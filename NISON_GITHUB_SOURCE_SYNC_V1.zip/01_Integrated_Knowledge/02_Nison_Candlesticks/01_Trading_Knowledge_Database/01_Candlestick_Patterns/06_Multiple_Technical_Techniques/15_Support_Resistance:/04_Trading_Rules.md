# Trading Rules

## Rule 1

Always identify major support and resistance before searching for candlestick patterns.

---

## Rule 2

A bullish candlestick pattern occurring at support carries greater significance than the same pattern appearing in the middle of a trend.

---

## Rule 3

A bearish candlestick pattern occurring at resistance carries greater significance than the same pattern appearing in the middle of a trend.

---

## Rule 4

Multiple successful tests strengthen support.

---

## Rule 5

Multiple successful failures strengthen resistance.

---

## Rule 6

Support and resistance should always be treated as price zones rather than exact prices.

---

## Rule 7

When several bullish candlestick patterns appear during repeated support tests, buying probability increases.

---

## Rule 8

When several bearish candlestick patterns appear during repeated resistance tests, selling probability increases.

---

## Rule 9

Always combine support/resistance analysis with overall trend direction.

---

## Rule 10

Use the extreme of the confirming candlestick pattern when positioning stop-loss orders.