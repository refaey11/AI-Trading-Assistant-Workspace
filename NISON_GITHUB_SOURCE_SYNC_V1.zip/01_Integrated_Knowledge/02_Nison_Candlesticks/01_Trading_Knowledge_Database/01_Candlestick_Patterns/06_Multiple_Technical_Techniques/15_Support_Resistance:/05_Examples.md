# Examples

---

# Example 1 — Figure 11.4

## Context

Price revisited a previous support area near $173.

## Candlestick Confirmation

Morning Star

## Result

Support held and price advanced sharply.

## Lesson

Bullish reversal patterns significantly strengthen support.

---

# Example 2 — Figure 11.5

## Context

Price tested support multiple times.

## Candlestick Confirmation

Bullish Hammer

## Result

Support remained intact.

## Lesson

Repeated successful tests increase support reliability.

---

# Example 3 — Figure 11.6

## Context

Dark Cloud Cover patterns formed near resistance.

## Result

Resistance remained effective.

## Lesson

Bearish reversal patterns reinforce resistance.

---

# Example 4 — Figure 11.7

## Context

Price repeatedly failed near resistance.

## Candlestick Confirmation

- Long-legged Doji
- Shooting Star
- Bearish Engulfing

## Lesson

Multiple bearish signals around resistance increase reversal probability.

---

# Example 5 — Figure 11.8

## Context

Bearish Engulfing appeared beneath resistance.

## Result

The attempted breakout failed.

## Lesson

Resistance confirmed by bearish candlesticks is more reliable.

---

# Example 6 — Figure 11.11

## Context

Price reached an important resistance trend line.

## Candlestick Confirmation

- Shooting Star
- Hanging Man

## Result

Market entered a correction.

## Lesson

Resistance becomes more significant when supported by multiple bearish reversal patterns.