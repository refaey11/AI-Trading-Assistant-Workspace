# Support & Resistance Checklist

Before entering a trade:

☐ Major support/resistance identified.

☐ Level previously tested.

☐ Current trend identified.

☐ Candlestick confirmation exists.

☐ No conflicting nearby level.

☐ Entry occurs near the level.

☐ Stop-loss placed beyond confirmation candle.

☐ Risk/Reward acceptable.

☐ Market structure agrees.

☐ Trade follows higher timeframe trend.