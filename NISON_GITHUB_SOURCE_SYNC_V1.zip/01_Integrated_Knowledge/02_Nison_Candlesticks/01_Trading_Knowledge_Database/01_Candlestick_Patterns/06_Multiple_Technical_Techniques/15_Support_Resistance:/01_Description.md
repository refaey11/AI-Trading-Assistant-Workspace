# Description

## Support and Resistance

Support and resistance are among the most important concepts in technical analysis.

Support is a price area where buying pressure becomes strong enough to stop or reverse a decline.

Resistance is a price area where selling pressure becomes strong enough to stop or reverse an advance.

Japanese candlestick charts greatly improve the analysis of these levels.

Instead of simply identifying support and resistance, candlestick patterns reveal whether buyers or sellers are successfully defending these price areas.

Bullish reversal patterns near support increase the probability that support will hold.

Bearish reversal patterns near resistance increase the probability that resistance will hold.

The strongest trading opportunities occur when important support or resistance levels coincide with clear candlestick reversal patterns.