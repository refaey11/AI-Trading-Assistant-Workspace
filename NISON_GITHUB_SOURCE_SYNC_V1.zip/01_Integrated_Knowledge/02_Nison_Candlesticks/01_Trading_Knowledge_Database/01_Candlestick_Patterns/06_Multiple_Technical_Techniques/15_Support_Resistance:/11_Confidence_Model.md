# Confidence Model

## Low Confidence

- First interaction.
- No candlestick confirmation.

---

## Medium Confidence

- Previous test exists.
- One confirming candlestick.

---

## High Confidence

- Multiple successful tests.
- Strong reversal pattern.
- Trend agrees.

---

## Very High Confidence

- Major historical level.
- Multiple confirmations.
- Strong market trend.
- Confluence with trend line or polarity level.