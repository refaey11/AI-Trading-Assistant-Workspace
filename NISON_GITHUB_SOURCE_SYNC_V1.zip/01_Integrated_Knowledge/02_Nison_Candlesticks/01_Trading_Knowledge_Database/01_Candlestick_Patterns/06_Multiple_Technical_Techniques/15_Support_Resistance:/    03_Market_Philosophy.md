# Market Philosophy

Support and resistance represent areas where buyers and sellers repeatedly disagree about value.

Every test of support asks:

"Are buyers still willing to defend this level?"

Every test of resistance asks:

"Are sellers still willing to defend this level?"

Candlestick patterns answer these questions.

A Hammer near support suggests buyers are regaining control.

A Shooting Star near resistance suggests sellers are regaining control.

Markets often remember important price levels.

Repeated reactions create stronger psychological barriers, making future reactions more likely.

Candlestick analysis transforms support and resistance from static price levels into dynamic decision zones.