# Backtesting Guide

Record every historical setup.

Market:

Timeframe:

Date:

Support / Resistance Type:

- Support
- Resistance

Interaction:

- Test
- Retest
- Break
- Rejection

Candlestick Pattern:

Entry

Stop Loss

Target

Result

Maximum Favorable Excursion (MFE)

Maximum Adverse Excursion (MAE)

Notes

Questions

1. Was the level respected?

2. Was candlestick confirmation present?

3. Did trend support the trade?

4. Was stop-loss correctly placed?

5. Could entry have been improved?