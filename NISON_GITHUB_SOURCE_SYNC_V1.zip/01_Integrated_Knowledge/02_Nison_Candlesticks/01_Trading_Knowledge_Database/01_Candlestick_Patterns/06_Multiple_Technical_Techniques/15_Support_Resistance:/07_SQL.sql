CREATE TABLE support_resistance (

    id INTEGER PRIMARY KEY,

    code TEXT,

    level_type TEXT,

    candlestick_confirmation TEXT,

    market_bias TEXT,

    figure TEXT,

    trading_message TEXT

);

INSERT INTO support_resistance VALUES
(1,'SR001','Support',
'Hammer, Morning Star, Bullish Engulfing',
'Bullish',
'11.4',
'Support confirmed');

INSERT INTO support_resistance VALUES
(2,'SR002','Support',
'Hammer',
'Bullish',
'11.5',
'Repeated support test');

INSERT INTO support_resistance VALUES
(3,'SR003','Resistance',
'Dark Cloud Cover',
'Bearish',
'11.6',
'Resistance confirmed');

INSERT INTO support_resistance VALUES
(4,'SR004','Resistance',
'Doji, Shooting Star, Bearish Engulfing',
'Bearish',
'11.7',
'Multiple bearish confirmations');

INSERT INTO support_resistance VALUES
(5,'SR005','Resistance',
'Bearish Engulfing',
'Bearish',
'11.8',
'Failed breakout');