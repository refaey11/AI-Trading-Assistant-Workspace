# Core Principles

## Principle 1

Support forms where buying pressure overcomes selling pressure.

---

## Principle 2

Resistance forms where selling pressure overcomes buying pressure.

---

## Principle 3

Support becomes more important after multiple successful tests.

---

## Principle 4

Resistance becomes more important after multiple successful tests.

---

## Principle 5

Bullish candlestick patterns strengthen support.

---

## Principle 6

Bearish candlestick patterns strengthen resistance.

---

## Principle 7

The more times price reacts at the same level, the more important that level becomes.

---

## Principle 8

Candlestick confirmation is more valuable than price alone.

---

## Principle 9

Support and resistance should always be analyzed together with market trend.

---

## Principle 10

Support and resistance represent zones rather than exact prices.