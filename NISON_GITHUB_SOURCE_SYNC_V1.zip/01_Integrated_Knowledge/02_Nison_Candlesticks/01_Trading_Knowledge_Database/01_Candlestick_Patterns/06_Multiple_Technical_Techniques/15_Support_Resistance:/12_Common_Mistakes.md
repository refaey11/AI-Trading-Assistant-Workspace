# Common Mistakes

## Mistake 1

Trading every support or resistance level without confirmation.

---

## Mistake 2

Ignoring the overall trend.

---

## Mistake 3

Treating support and resistance as exact prices instead of zones.

---

## Mistake 4

Ignoring repeated tests.

---

## Mistake 5

Entering before the candlestick closes.

---

## Mistake 6

Placing stop-loss exactly on the support or resistance level.

---

## Mistake 7

Ignoring nearby opposing levels.

---

## Mistake 8

Using support and resistance without candlestick confirmation.