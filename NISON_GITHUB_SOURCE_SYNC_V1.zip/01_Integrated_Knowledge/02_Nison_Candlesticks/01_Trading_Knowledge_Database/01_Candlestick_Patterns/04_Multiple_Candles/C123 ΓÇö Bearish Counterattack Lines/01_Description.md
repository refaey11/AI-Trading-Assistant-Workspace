# Bearish Counterattack Lines

## Classification

- Type: Bearish Reversal
- Candles: 2

## Definition

The Bearish Counterattack Lines pattern appears during an uptrend.

The first candle is a long white candle.

The second candle opens with an upside gap, then sellers force prices lower until the session closes at approximately the same closing price as the previous candle.

According to the book, the optimism at the opening of the second session changes into concern by the close.