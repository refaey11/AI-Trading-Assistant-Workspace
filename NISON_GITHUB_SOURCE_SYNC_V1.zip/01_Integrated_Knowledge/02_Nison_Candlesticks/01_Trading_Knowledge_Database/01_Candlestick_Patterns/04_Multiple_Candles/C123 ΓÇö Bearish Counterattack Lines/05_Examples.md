Figures mentioned in the book:

6.39

6.40

6.41