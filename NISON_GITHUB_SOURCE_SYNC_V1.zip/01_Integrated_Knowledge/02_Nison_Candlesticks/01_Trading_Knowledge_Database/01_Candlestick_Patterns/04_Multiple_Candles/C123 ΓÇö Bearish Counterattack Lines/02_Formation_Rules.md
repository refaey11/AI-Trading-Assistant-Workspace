# Formation Rules

- Existing uptrend.
- First candle: long white candle.
- Second candle opens with an upside gap.
- Sellers push prices lower.
- Second candle closes approximately equal to the previous close.