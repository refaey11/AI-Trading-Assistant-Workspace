# Market Psychology

The first candle reflects strong buying pressure.

The second session opens with a bullish gap, increasing buyers' optimism.

Sellers then regain control and drive prices lower until the market closes near the previous closing price.

The market shifts from optimism to uncertainty.