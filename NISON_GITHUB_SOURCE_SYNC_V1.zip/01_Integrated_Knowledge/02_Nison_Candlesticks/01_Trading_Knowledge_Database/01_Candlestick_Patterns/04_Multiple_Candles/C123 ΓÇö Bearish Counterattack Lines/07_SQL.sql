CREATE TABLE BearishCounterattackLines (

id INTEGER PRIMARY KEY,

trend TEXT,

candles INTEGER,

type TEXT

);