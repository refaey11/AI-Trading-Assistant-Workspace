# Backtesting

Not mentioned in the book.