# Trading Rules

According to the book:

The Bearish Counterattack Lines pattern is a bearish reversal signal.

Its bearish implication is weaker than the Dark Cloud Cover pattern.