☐ Existing uptrend

☐ Long white candle

☐ Gap up

☐ Close approximately equals previous close