# Confirmation

Not mentioned in the book.