# Checklist

☐ Existing Trend

☐ Long First Candle

☐ Small Second Candle

☐ Second Body Inside First Body

☐ Confirmation Present

☐ Risk Reward ≥ 1:2