# Backtesting

Record

Date

Market

Trend

ATR

Volume

Pattern Direction

Confirmation

Entry

Stop

Target

Win / Loss

RR

Notes