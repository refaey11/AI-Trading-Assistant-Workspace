# Market Psychology

Day 1

The current trend remains very strong.

Buyers (or sellers) dominate the market.

Momentum is high.

---

Day 2

Momentum suddenly weakens.

The market trades within the body of the previous candle.

Neither buyers nor sellers are able to continue the previous move.

The market enters a temporary balance.

This loss of momentum increases the probability of a reversal after confirmation.