# Harami Pattern

## Classification

- Type: Reversal Pattern
- Candles: 2
- Trend: Uptrend or Downtrend
- Reliability: Medium
- Confirmation: Recommended

---

## Definition

The Harami Pattern is a two-candle reversal pattern.

The first candle is a long real body that represents strong momentum.

The second candle has a much smaller real body that is completely contained within the real body of the first candle.

Unlike the Engulfing Pattern, the second candle is inside the previous candle.

The pattern suggests that the previous trend is losing momentum and the market is entering a period of indecision.

Harami does not necessarily indicate an immediate reversal, but rather that the existing trend has paused and confirmation should be awaited.