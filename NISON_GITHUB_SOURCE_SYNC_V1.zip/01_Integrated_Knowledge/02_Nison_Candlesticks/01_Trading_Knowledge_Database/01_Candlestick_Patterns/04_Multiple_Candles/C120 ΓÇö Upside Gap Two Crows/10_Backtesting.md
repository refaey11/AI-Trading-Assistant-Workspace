# Backtesting

Record

Date

Market

Trend

Gap Size

ATR

Volume

Confirmation

Entry

Stop

Target

Win / Loss

RR

Notes