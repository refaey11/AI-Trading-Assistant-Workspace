# Checklist

☐ Existing Uptrend

☐ Long Bullish Candle

☐ Gap Up

☐ Two Bearish Candles

☐ Gap Failure

☐ Confirmation

☐ Good Risk Reward