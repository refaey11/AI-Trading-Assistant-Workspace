# Upside Gap Two Crows

## Classification

- Type: Bearish Reversal Pattern
- Candles: 3
- Trend: Existing Uptrend
- Reliability: High
- Confirmation: Recommended

---

## Definition

The Upside Gap Two Crows is a rare bearish reversal pattern.

It appears after an existing uptrend.

The pattern begins with a strong bullish candle.

A gap upward follows, producing two consecutive bearish candles.

The inability of buyers to maintain the gap signals weakening bullish momentum.

According to the book, the pattern often marks the end of a sustained advance.