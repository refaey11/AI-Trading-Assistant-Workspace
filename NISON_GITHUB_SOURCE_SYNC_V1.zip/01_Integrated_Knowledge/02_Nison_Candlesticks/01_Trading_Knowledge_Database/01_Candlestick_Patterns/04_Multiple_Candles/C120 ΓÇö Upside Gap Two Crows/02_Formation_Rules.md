# Formation Rules

## Required Conditions

1. Existing uptrend.

2. First candle:
   - Long bullish candle.

3. Second candle:
   - Bearish candle.
   - Opens above the first candle (gap up).

4. Third candle:
   - Bearish candle.
   - Continues selling pressure.
   - Closes inside the gap area.

---

## Invalid Pattern

- No existing uptrend.
- No upside gap.
- Bullish third candle.