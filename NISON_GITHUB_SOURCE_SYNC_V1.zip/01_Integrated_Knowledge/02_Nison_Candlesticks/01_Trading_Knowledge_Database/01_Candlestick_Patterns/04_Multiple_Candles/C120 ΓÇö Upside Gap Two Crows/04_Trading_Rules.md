# Trading Rules

## Pattern Meaning

Bearish Reversal

Confirmation is recommended.

---

## Entry

Sell after bearish confirmation.

---

## Stop Loss

Above the highest high of the pattern.

---

## Targets

Nearest support.

Risk Reward ≥ 1:2