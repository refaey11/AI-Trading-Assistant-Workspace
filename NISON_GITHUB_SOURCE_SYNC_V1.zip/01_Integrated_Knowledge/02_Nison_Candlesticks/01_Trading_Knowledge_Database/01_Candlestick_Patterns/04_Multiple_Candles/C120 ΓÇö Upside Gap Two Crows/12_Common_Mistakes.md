# Common Mistakes

❌ Ignoring the required gap.

❌ Trading without confirmation.

❌ Confusing it with Three Black Crows.

❌ Ignoring trend direction.

❌ Entering before the third candle closes.

❌ Ignoring nearby resistance.