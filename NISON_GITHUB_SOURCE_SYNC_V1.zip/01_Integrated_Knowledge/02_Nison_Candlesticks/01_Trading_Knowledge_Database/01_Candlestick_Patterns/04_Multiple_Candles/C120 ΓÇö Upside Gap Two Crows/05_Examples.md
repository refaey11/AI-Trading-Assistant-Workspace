# Examples

Book References

Figures:

- 6.30
- 6.32
- 6.33
- 6.34

Related Patterns

- Two Crows
- Advance Block
- Three Black Crows

The book describes this as a rare but important bearish reversal pattern after strong advances.