# Confirmation

Strong confirmations include:

- Break below the third candle low.
- Increasing selling volume.
- Failure to recover the upside gap.

The pattern becomes stronger after an extended uptrend.