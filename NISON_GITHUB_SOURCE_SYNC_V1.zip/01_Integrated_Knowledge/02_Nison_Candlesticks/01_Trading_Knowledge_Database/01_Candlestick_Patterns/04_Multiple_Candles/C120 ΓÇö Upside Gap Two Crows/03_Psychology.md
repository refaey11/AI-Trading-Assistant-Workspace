# Market Psychology

Buyers remain confident after a strong advance.

The market opens with a bullish gap, reinforcing optimism.

However, sellers immediately appear.

The first bearish candle warns of weakening demand.

The second bearish candle confirms that buyers failed to defend the higher prices.

Control shifts from buyers to sellers.