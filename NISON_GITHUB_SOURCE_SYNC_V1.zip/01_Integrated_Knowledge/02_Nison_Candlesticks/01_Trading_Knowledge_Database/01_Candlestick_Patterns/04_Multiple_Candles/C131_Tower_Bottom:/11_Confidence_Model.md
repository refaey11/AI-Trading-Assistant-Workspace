# Confirmation

According to the book:

The appearance of one or more long bullish candles after the hesitation completes and confirms the Tower Bottom.