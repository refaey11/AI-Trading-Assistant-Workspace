# Market Psychology

The market is dominated by strong selling pressure.

Selling momentum gradually slows and the market enters a short period of balance.

Buyers begin to take control, producing one or more long bullish candles.

The transition from strong selling to strong buying signals a major market bottom.