# Formation Rules

## Structure

- Existing downtrend.
- One or more long bearish candles.
- Short consolidation or hesitation.
- One or more long bullish candles.

## Notes

According to the book:

- The long bearish candles form the left tower.
- The long bullish candles form the right tower.
- The hesitation represents the transfer of control from sellers to buyers.