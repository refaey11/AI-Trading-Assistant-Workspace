# Checklist

☐ Existing downtrend

☐ Long bearish candles

☐ Short consolidation

☐ Long bullish candles

☐ Major bullish reversal