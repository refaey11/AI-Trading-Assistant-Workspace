# Tower Bottom

## Classification

- Pattern ID: C131
- Pattern Name: Tower Bottom
- Japanese Name: Tower Bottom
- Pattern Type: Major Bullish Reversal
- Number of Candles: Multiple

## Definition

The Tower Bottom is a major bullish reversal pattern.

According to the book, it forms after a downtrend when the market declines with one or more long black candles, followed by a brief period of hesitation, and then one or more long white candles.

The long candles on both sides resemble two towers, giving the pattern its name.