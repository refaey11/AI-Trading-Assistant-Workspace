CREATE TABLE C131_TowerBottom (

id INTEGER PRIMARY KEY,

trend TEXT,

left_tower TEXT,

right_tower TEXT,

pattern_type TEXT

);