# Examples

## Figures Mentioned in the Book

- Figure 6.59
- Figure 6.61

## Notes

Figure 6.59

Illustrates the ideal Tower Bottom structure.

Figure 6.61

Shows a long black candle on August 28, followed by several small candles, then a long white candle on September 7 completing the Tower Bottom.