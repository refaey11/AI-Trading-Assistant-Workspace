# Trading Rules

## Market Meaning

According to the book:

- Tower Bottom is a major bullish reversal pattern.
- It signals that sellers have lost control.
- The appearance of long bullish candles after the consolidation confirms the reversal.