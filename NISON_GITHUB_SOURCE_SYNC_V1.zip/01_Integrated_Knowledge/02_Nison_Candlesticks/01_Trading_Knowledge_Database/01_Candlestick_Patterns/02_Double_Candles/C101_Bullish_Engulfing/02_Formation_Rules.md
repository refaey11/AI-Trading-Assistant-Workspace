# Pattern ID

C101

# Pattern Name

Bullish Engulfing

# Formation Rules

## Rule 1

Must appear after a downtrend.

---

## Rule 2

Two candles.

---

## Rule 3

First candle is bearish.

---

## Rule 4

Second candle is bullish.

---

## Rule 5

Second real body completely engulfs first real body.

---

## Rule 6

Shadows do NOT need to be engulfed.

---

## Rule 7

Larger second candle = stronger signal.

---

## Rule 8

Small first candle = stronger reversal.