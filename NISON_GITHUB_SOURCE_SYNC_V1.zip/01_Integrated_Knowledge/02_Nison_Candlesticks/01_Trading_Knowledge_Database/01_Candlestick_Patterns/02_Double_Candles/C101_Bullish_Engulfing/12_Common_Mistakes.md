# Common Mistakes

❌ Trading without confirmation.

❌ Ignoring the trend.

❌ Trading inside consolidation.

❌ Ignoring nearby resistance.

❌ Small engulfing candle.

❌ Low volume.

❌ Poor Risk Reward.

❌ Entering before candle closes.