# Confidence Model

Downtrend .............. 20%

Complete Engulfing ..... 25%

Support ................ 20%

Confirmation ........... 20%

Volume ................. 10%

Market Structure ....... 5%

Total = 100%