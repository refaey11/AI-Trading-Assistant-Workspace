□ Downtrend

□ Two Candles

□ First Bearish

□ Second Bullish

□ Body Completely Engulfed

□ Near Support

□ Good Volume

□ Confirmation

□ Risk Reward ≥ 1:2

□ Valid Trade