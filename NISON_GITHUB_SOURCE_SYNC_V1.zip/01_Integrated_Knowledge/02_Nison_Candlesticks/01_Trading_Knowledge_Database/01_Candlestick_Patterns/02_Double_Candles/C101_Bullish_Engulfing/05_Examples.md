# Pattern Examples

Example 1

Downtrend

↓

Bearish Candle

↓

Large Bullish Candle

↓

Bullish Engulfing

↓

Trend Reversal

---

Book Examples

- Swiss Franc
- Crude Oil
- Platinum
- Soybeans