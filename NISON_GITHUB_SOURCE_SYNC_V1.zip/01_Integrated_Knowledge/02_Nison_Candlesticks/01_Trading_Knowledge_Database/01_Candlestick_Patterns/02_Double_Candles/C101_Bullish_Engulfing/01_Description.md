# Pattern ID

C101

# Pattern Name

Bullish Engulfing

# Category

Double Candlestick

# Pattern Type

Bullish Reversal

# Description

The Bullish Engulfing Pattern is a two-candle bullish reversal pattern.

It appears after a downtrend.

The first candle is bearish.

The second candle is bullish.

The real body of the second candle completely engulfs the real body of the first candle.

Only the real body must be engulfed.

The shadows are not important.

The pattern shows buyers have completely overwhelmed sellers.

Confirmation is required before entering a trade.

# Key Idea

Strong Bullish Reversal

# Strength

Medium without confirmation.

High with confirmation.

Very High near major support.