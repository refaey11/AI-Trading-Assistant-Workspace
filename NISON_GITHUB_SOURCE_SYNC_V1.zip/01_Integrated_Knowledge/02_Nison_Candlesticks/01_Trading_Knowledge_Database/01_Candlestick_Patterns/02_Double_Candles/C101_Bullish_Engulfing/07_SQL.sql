INSERT INTO candlestick_patterns
(
pattern_id,
pattern_name,
category,
pattern_type,
trend,
confirmation
)

VALUES

(
'C101',
'Bullish Engulfing',
'Double Candlestick',
'Bullish Reversal',
'Downtrend',
TRUE
);