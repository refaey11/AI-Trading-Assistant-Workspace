# Pattern ID

C101

# Pattern Name

Bullish Engulfing

# Market Psychology

Sellers are in control.

Price continues lower.

Buyers suddenly enter aggressively.

The second candle completely absorbs previous selling pressure.

Market sentiment shifts from bearish to bullish.

Buyers now dominate.

Potential trend reversal begins.