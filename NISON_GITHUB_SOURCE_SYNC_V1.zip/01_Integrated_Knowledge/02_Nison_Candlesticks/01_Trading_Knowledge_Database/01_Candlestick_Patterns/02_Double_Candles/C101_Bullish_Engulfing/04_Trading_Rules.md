# Pattern ID

C101

# Pattern Name

Bullish Engulfing

# Trading Rules

## Rule 1

Never buy immediately.

Wait for confirmation.

---

## Rule 2

Bullish confirmation:

Strong bullish candle

OR

Break above engulfing high.

---

## Rule 3

Best Location

Support

Demand Zone

End of Downtrend

Moving Average Support

---

## Rule 4

High Volume

=

Higher probability.

---

## Rule 5

Avoid

Sideways markets

Weak volume

No trend

---

## Entry

BUY after confirmation.

---

## Stop Loss

Below engulfing low.

---

## Take Profit

Next resistance.

Risk Reward ≥ 1:2

---

## AI Decision

Bullish Engulfing

+

Confirmation

+

Support

=

BUY Candidate