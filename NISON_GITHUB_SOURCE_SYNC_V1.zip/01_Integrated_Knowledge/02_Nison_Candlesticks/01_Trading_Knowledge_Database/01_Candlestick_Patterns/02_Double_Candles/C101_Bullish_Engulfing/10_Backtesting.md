# Backtesting

Asset:

Timeframe:

Trend:

Support:

Volume:

Entry:

Stop Loss:

Take Profit:

RR:

Win/Loss:

Notes: