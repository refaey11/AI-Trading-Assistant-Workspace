# Examples

Book References

- Exhibit 4.32

Comparison with:

- On Neck Pattern
- In Neck Pattern
- Piercing Pattern

The examples demonstrate that buyers recover farther into the previous candle than the On Neck or In Neck patterns but still fail to create a bullish reversal.