# Thrusting Pattern

## Classification

- Type: Bearish Continuation Pattern
- Candles: 2
- Trend: Existing Downtrend
- Reliability: Medium to High
- Confirmation: Recommended

---

## Definition

The Thrusting Pattern is a bearish continuation pattern that develops during an existing downtrend.

The first candle is a long bearish candle.

The second candle opens below the previous low and rallies strongly into the previous bearish body.

However, the close remains below the midpoint of the first candle.

Although buyers show more strength than in the On Neck or In Neck patterns, they still fail to reverse the bearish trend.

The prevailing downtrend is expected to continue.