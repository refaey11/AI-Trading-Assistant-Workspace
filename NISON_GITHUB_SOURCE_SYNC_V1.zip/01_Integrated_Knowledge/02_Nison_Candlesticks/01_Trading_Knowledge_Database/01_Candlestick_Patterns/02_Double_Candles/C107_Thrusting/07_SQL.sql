CREATE TABLE ThrustingPattern (

id INTEGER PRIMARY KEY,

trend TEXT,

confirmation BOOLEAN,

entry TEXT,

stop_loss TEXT,

take_profit TEXT,

confidence TEXT

);