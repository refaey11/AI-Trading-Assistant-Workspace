# Market Psychology

Day 1

Sellers remain firmly in control.

Strong bearish momentum continues.

---

Day 2

Price gaps lower.

Buyers launch a strong recovery.

However...

The rally stalls before reaching the midpoint of the previous bearish candle.

Sellers successfully defend resistance.

The bearish trend remains dominant.