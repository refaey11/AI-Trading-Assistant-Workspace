# Common Mistakes

❌ Trading it as a bullish reversal.

❌ Ignoring the midpoint rule.

❌ Confusing it with the Piercing Pattern.

❌ Buying because the second candle is large and bullish.

❌ Ignoring bearish confirmation.

❌ Entering before the next candle confirms continuation.