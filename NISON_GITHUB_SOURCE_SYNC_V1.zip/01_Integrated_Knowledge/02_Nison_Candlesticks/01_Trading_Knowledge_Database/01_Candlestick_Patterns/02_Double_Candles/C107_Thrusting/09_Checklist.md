# Checklist

☐ Existing Downtrend

☐ Long Bearish Candle

☐ Gap Down

☐ Strong Bullish Recovery

☐ Close Below Midpoint

☐ Confirmation Present

☐ Good Risk Reward