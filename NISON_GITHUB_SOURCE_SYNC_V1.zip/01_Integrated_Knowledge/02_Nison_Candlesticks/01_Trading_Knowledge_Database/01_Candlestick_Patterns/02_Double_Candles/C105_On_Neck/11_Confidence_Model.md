# Confidence Model

Base Score

60

+

Strong Downtrend

+10

Gap Down

+10

High Volume

+10

Resistance Nearby

+5

Bearish Confirmation

+5

Maximum Score

100