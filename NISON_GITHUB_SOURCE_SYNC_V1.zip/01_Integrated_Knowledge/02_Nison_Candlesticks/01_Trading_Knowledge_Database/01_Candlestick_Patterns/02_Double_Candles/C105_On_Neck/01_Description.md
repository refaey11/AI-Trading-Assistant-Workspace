# On Neck Pattern

## Classification

- Pattern Type: Bearish Continuation
- Candles: 2
- Trend Required: Downtrend
- Reliability: Medium
- Confirmation: Recommended

---

## Definition

The On Neck Pattern is a two-candle bearish continuation pattern.

It appears during an established downtrend.

The first candle is a long bearish candle.

The second candle opens below the previous low, then rallies slightly, but closes near the previous candle's close.

Although buyers manage a small recovery, they fail to regain meaningful control.

This failure suggests that the dominant bearish trend is likely to continue.

---

## Purpose

The pattern signals that the recent buying attempt is weak and that sellers still control the market.

Unlike the Piercing Pattern, the bullish candle does not penetrate deeply into the previous bearish candle.

Therefore, the market shows only temporary buying interest rather than a true reversal.

---

## Key Characteristics

- Appears after a decline.
- First candle is a long bearish candle.
- Second candle opens with a downside gap.
- Second candle closes near the previous close.
- Buyers fail to push above resistance.
- Usually followed by continuation of the downtrend.