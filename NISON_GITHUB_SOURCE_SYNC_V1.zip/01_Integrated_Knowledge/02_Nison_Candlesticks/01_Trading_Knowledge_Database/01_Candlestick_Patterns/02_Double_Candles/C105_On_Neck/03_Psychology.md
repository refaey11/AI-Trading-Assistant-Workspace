# Market Psychology

Day 1

Sellers dominate.

Price closes near the low.

---

Day 2

Market opens lower.

Buyers attempt a recovery.

However...

They only recover enough to reach the previous close.

Sellers defend resistance.

The buying pressure is weak.

The downtrend remains intact.