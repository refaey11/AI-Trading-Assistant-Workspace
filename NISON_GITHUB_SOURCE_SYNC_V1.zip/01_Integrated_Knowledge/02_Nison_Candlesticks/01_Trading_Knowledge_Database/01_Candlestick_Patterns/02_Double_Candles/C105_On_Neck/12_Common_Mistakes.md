# Common Mistakes

❌ Trading it as a reversal.

❌ Ignoring trend direction.

❌ Confusing it with Piercing Pattern.

❌ Buying because the second candle is bullish.

❌ Ignoring confirmation.

❌ Entering before the next bearish candle.