# Backtesting

Record

Date

Market

Trend Strength

ATR

Volume

Confirmation

Entry

Stop

Target

Win / Loss

RR

Notes