# Checklist

☐ Existing Downtrend

☐ Long Bearish Candle

☐ Gap Down

☐ Small Bullish Candle

☐ Close Near Previous Close

☐ Below Midpoint

☐ Confirmation Present

☐ Good Risk Reward