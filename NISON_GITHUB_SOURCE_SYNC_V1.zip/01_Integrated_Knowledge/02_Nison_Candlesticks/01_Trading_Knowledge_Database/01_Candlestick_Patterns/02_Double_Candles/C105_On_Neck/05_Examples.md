# Examples

Book References

- Exhibit 4.30

Comparison with:

- Piercing Pattern
- In Neck
- Thrusting

The examples demonstrate that buyers fail to regain control despite a small bullish recovery.