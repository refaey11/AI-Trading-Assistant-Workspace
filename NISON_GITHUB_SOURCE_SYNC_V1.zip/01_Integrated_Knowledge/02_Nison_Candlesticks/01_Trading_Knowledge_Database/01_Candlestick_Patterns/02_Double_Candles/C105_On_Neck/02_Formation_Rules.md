# Formation Rules

## Required Conditions

1. Existing downtrend.

2. First candle:
   - Long bearish body.

3. Second candle:
   - Opens below previous low.
   - Bullish candle.
   - Closes near previous close.
   - Must NOT close above the midpoint of the previous body.

---

## Invalid Pattern

- Appears after an uptrend.
- Second candle closes above midpoint.
- Second candle engulfs previous candle.