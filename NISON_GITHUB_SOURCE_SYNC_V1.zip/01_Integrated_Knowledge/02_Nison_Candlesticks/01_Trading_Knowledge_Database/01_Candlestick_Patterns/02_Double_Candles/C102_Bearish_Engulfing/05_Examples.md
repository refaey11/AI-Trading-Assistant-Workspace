# Pattern Examples

Example 1

Uptrend

↓

Bullish Candle

↓

Large Bearish Candle

↓

Bearish Engulfing

↓

Trend Reversal

---

Book Examples

- Swiss Franc
- Crude Oil
- Platinum
- Soybeans