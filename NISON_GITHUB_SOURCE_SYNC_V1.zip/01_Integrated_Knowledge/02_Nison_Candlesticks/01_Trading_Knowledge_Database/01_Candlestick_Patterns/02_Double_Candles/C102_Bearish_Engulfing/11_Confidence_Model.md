# Confidence Model

Uptrend ................ 20%

Complete Engulfing ..... 25%

Resistance ............. 20%

Confirmation ........... 20%

Volume ................. 10%

Market Structure ....... 5%

Total = 100%