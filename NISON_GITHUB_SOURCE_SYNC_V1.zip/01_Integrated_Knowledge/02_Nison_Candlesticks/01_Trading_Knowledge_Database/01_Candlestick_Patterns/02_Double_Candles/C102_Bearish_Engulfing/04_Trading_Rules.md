# Pattern ID

C102

# Pattern Name

Bearish Engulfing

# Trading Rules

## Rule 1

Never sell immediately.

Wait for confirmation.

---

## Rule 2

Bearish confirmation:

Strong bearish candle

OR

Break below engulfing low.

---

## Rule 3

Best Location

Resistance

Supply Zone

End of Uptrend

Moving Average Resistance

---

## Rule 4

High Volume

=

Higher probability.

---

## Rule 5

Avoid

Sideways markets

Weak volume

No trend

---

## Entry

SELL after confirmation.

---

## Stop Loss

Above engulfing high.

---

## Take Profit

Next support.

Risk Reward ≥ 1:2

---

## AI Decision

Bearish Engulfing

+

Confirmation

+

Resistance

=

SELL Candidate