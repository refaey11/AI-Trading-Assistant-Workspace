INSERT INTO candlestick_patterns
(
pattern_id,
pattern_name,
category,
pattern_type,
trend,
confirmation
)

VALUES

(
'C102',
'Bearish Engulfing',
'Double Candlestick',
'Bearish Reversal',
'Uptrend',
TRUE
);