□ Uptrend

□ Two Candles

□ First Bullish

□ Second Bearish

□ Body Completely Engulfed

□ Near Resistance

□ Good Volume

□ Confirmation

□ Risk Reward ≥ 1:2

□ Valid Trade