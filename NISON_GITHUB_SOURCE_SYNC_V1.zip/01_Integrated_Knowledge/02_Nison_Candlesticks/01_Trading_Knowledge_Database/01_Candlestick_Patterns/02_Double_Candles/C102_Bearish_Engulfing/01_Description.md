# Pattern ID

C102

# Pattern Name

Bearish Engulfing

# Category

Double Candlestick

# Pattern Type

Bearish Reversal

# Description

The Bearish Engulfing Pattern is a two-candle bearish reversal pattern.

It usually appears after an uptrend.

The first candle is bullish.

The second candle is bearish.

The real body of the second candle completely engulfs the real body of the first candle.

Only the real body must be engulfed.

The shadows are not important.

The pattern shows sellers have completely overwhelmed buyers.

Confirmation is required before entering a trade.

# Key Idea

Strong Bearish Reversal

# Strength

Medium without confirmation.

High with confirmation.

Very High near major resistance.