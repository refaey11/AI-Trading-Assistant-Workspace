# Pattern ID

C102

# Pattern Name

Bearish Engulfing

# Market Psychology

Buyers are in control.

Price continues higher.

Sellers suddenly enter aggressively.

The second candle completely absorbs previous buying pressure.

Market sentiment shifts from bullish to bearish.

Sellers now dominate.

Potential trend reversal begins.