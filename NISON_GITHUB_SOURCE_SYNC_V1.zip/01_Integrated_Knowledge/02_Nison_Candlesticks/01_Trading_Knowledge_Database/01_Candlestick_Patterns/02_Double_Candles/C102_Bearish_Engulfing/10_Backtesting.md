# Backtesting

Asset:

Timeframe:

Trend:

Resistance:

Volume:

Entry:

Stop Loss:

Take Profit:

RR:

Win/Loss:

Notes: