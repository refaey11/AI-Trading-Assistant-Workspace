□ Uptrend

□ Long Bullish Candle

□ Gap Up

□ Close Below Midpoint

□ Near Resistance

□ High Volume

□ Confirmation

□ RR ≥ 1:2

□ Valid Trade