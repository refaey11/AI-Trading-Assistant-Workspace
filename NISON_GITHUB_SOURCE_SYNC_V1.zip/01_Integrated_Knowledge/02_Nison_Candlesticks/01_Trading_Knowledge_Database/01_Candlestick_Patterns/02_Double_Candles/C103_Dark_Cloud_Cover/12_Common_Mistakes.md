# Common Mistakes

❌ Selling before confirmation.

❌ Ignoring resistance.

❌ Confusing it with Bearish Engulfing.

❌ Weak penetration.

❌ Low volume.

❌ Sideways market.

❌ Poor Risk Reward.