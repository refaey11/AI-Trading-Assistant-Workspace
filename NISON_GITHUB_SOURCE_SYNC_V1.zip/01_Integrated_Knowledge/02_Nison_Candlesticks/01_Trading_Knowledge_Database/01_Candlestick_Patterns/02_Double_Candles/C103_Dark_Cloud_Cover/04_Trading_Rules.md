# Pattern ID

C103

# Pattern Name

Dark Cloud Cover

# Trading Rules

## Rule 1

Never sell immediately.

Wait for confirmation.

---

## Rule 2

Bearish confirmation

Strong bearish candle

OR

Break below Dark Cloud Cover low.

---

## Rule 3

Best Location

Resistance

Supply Zone

End of Uptrend

---

## Rule 4

High Volume

=

Higher probability.

---

## Rule 5

Avoid

Sideways markets

Weak volume

No trend

---

## Entry

SELL after confirmation.

---

## Stop Loss

Above pattern high.

---

## Take Profit

Next support.

Risk Reward ≥ 1:2

---

## AI Decision

Dark Cloud Cover

+

Confirmation

+

Resistance

=

SELL Candidate