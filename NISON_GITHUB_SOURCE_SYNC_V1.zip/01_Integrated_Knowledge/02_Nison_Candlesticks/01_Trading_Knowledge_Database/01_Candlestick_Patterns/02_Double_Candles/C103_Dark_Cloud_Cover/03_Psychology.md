# Pattern ID

C103

# Pattern Name

Dark Cloud Cover

# Market Psychology

Buyers are confident after the strong bullish candle.

The next session opens even higher.

Suddenly sellers enter aggressively.

The market reverses during the session.

Price closes deep inside the previous bullish candle.

Buyers lose confidence.

Sellers begin taking control.

Potential bearish reversal begins.