INSERT INTO candlestick_patterns
(
pattern_id,
pattern_name,
category,
pattern_type,
trend,
confirmation
)

VALUES

(
'C103',
'Dark Cloud Cover',
'Double Candlestick',
'Bearish Reversal',
'Uptrend',
TRUE
);