# Pattern ID

C103

# Pattern Name

Dark Cloud Cover

# Category

Double Candlestick

# Pattern Type

Bearish Reversal

# Description

The Dark Cloud Cover is a two-candle bearish reversal pattern.

It usually appears after an uptrend.

The first candle is a strong bullish candle.

The second candle opens above the previous high (or above the previous upper shadow) and then closes deeply into the body of the first candle.

The second candle should ideally close below the midpoint of the first candle's real body.

The deeper the penetration, the stronger the bearish signal.

Unlike the Bearish Engulfing Pattern, the second candle does NOT completely engulf the first body.

# Key Idea

Potential Bearish Reversal

# Strength

Medium without confirmation.

High with confirmation.

Very High near major resistance.