# Confidence Model

Uptrend .............. 20%

Gap Up ............... 15%

Deep Penetration ..... 25%

Resistance ........... 20%

Confirmation ......... 15%

Volume ............... 5%

Total = 100%