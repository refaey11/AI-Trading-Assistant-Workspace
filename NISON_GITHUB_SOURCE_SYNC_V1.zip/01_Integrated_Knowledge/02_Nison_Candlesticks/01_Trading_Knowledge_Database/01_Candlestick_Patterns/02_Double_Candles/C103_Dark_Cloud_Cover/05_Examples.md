# Pattern Examples

Example

Strong Uptrend

↓

Bullish Candle

↓

Gap Up

↓

Strong Bearish Close

↓

Dark Cloud Cover

↓

Possible Reversal

---

Book Examples

- Municipal Bonds