# Backtesting

Asset:

Timeframe:

Trend:

Resistance:

Volume:

Gap:

Entry:

Stop Loss:

Take Profit:

RR:

Win/Loss:

Notes: