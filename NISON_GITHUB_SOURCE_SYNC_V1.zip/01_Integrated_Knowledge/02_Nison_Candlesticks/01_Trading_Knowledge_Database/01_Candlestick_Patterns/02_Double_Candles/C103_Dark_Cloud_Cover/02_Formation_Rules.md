# Pattern ID

C103

# Pattern Name

Dark Cloud Cover

# Formation Rules

## Rule 1

Must appear after an uptrend.

---

## Rule 2

Two candles.

---

## Rule 3

First candle is a long bullish candle.

---

## Rule 4

Second candle opens above previous high.

---

## Rule 5

Second candle closes below the midpoint of the previous bullish body.

---

## Rule 6

Second candle does NOT completely engulf the first body.

---

## Rule 7

Deeper penetration = stronger signal.