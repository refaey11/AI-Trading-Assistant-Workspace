# Backtesting

Asset:

Timeframe:

Trend:

Support:

Volume:

Gap:

Entry:

Stop Loss:

Take Profit:

RR:

Win/Loss:

Notes: