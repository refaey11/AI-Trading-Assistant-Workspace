# Pattern ID

C104

# Pattern Name

Piercing Pattern

# Trading Rules

## Rule 1

Never buy immediately.

Wait for confirmation.

---

## Rule 2

Bullish confirmation

Strong bullish candle

OR

Break above Piercing Pattern high.

---

## Rule 3

Best Location

Support

Demand Zone

End of Downtrend

---

## Rule 4

High Volume

=

Higher probability.

---

## Rule 5

Avoid

Sideways Market

Weak Volume

No Trend

---

## Entry

BUY after confirmation.

---

## Stop Loss

Below pattern low.

---

## Take Profit

Next resistance.

Risk Reward ≥ 1:2

---

## AI Decision

Piercing Pattern

+

Confirmation

+

Support

=

BUY Candidate