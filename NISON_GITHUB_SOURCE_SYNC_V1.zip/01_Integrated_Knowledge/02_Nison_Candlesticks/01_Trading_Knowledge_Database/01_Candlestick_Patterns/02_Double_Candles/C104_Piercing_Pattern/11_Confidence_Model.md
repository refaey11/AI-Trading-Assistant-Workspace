# Confidence Model

Downtrend .............. 20%

Gap Down ............... 15%

Deep Penetration ....... 25%

Support ................ 20%

Confirmation ........... 15%

Volume ................. 5%

Total = 100%