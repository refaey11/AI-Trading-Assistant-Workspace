# Pattern Examples

Example

Downtrend

↓

Long Bearish Candle

↓

Gap Down

↓

Strong Bullish Close

↓

Piercing Pattern

↓

Possible Reversal

---

Book Examples

- Boeing
- Wheat
- Oats
- Cash Yen