# Pattern ID

C104

# Pattern Name

Piercing Pattern

# Category

Double Candlestick

# Pattern Type

Bullish Reversal

# Description

The Piercing Pattern is a two-candle bullish reversal pattern.

It usually appears after a downtrend.

The first candle is a long bearish candle.

The second candle opens below the previous low and then closes above the midpoint of the previous bearish candle.

Unlike the Bullish Engulfing Pattern, the second candle does NOT completely engulf the first body.

The deeper the penetration into the first candle's body, the stronger the bullish signal.

# Key Idea

Potential Bullish Reversal

# Strength

Medium without confirmation.

High with confirmation.

Very High near major support.