INSERT INTO candlestick_patterns
(
pattern_id,
pattern_name,
category,
pattern_type,
trend,
confirmation
)

VALUES

(
'C104',
'Piercing Pattern',
'Double Candlestick',
'Bullish Reversal',
'Downtrend',
TRUE
);