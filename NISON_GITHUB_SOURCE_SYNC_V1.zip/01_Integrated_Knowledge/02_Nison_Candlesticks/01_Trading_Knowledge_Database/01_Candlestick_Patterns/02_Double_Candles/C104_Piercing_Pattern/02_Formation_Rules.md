# Pattern ID

C104

# Pattern Name

Piercing Pattern

# Formation Rules

## Rule 1

Must appear after a downtrend.

---

## Rule 2

Two candles.

---

## Rule 3

First candle is a long bearish candle.

---

## Rule 4

Second candle opens below previous low.

---

## Rule 5

Second candle closes above the midpoint of the previous bearish body.

---

## Rule 6

Second candle does NOT engulf the first body.

---

## Rule 7

Deeper penetration = stronger signal.