□ Downtrend

□ Long Bearish Candle

□ Gap Down

□ Close Above Midpoint

□ Near Support

□ High Volume

□ Confirmation

□ RR ≥ 1:2

□ Valid Trade