# Pattern ID

C104

# Pattern Name

Piercing Pattern

# Market Psychology

Sellers are fully in control.

The next session opens even lower.

Buyers suddenly become aggressive.

Price recovers sharply.

The session closes above the midpoint of the previous bearish candle.

Selling pressure weakens.

Buying pressure increases.

Potential bullish reversal begins.