# In Neck Pattern

## Classification

- Type: Bearish Continuation Pattern
- Candles: 2
- Trend: Existing Downtrend
- Reliability: Medium
- Confirmation: Recommended

---

## Definition

The In Neck Pattern is a bearish continuation pattern that appears during a downtrend.

The first candle is a long bearish candle.

The second candle opens below the previous low and rallies, but closes slightly above the previous candle's closing price.

Although buyers recover more than in the On Neck Pattern, they still fail to push price above the midpoint of the previous bearish body.

The prevailing downtrend is expected to continue.