# Formation Rules

## Required Conditions

1. Existing downtrend.

2. First candle:
   - Long bearish body.

3. Second candle:
   - Opens below previous low.
   - Bullish candle.
   - Closes slightly above the previous close.
   - Must remain below the midpoint of the previous body.

---

## Invalid Pattern

- Appears after an uptrend.
- Second candle closes above midpoint.
- Forms a Piercing Pattern.
- Second candle engulfs the previous candle.