# Trading Rules

## Pattern Meaning

Bearish Continuation

NOT a reversal.

---

## Entry

Sell after bearish confirmation.

---

## Stop Loss

Above the high of the second candle.

---

## Targets

Previous swing low.

Risk Reward ≥ 1:2

Trail stop while bearish momentum continues.