# Checklist

☐ Existing Downtrend

☐ Long Bearish Candle

☐ Gap Down

☐ Bullish Second Candle

☐ Close Slightly Above Previous Close

☐ Below Midpoint

☐ Confirmation Present

☐ Good Risk Reward