# Examples

Book References

- Exhibit 4.31

Comparison with:

- On Neck Pattern
- Piercing Pattern
- Thrusting Pattern

The examples show buyers producing a slightly stronger rebound than the On Neck Pattern, but still failing to reverse the bearish trend.