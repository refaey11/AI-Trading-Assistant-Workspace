# Market Psychology

Day 1

Strong selling pressure dominates.

The market closes near the session low.

---

Day 2

Price gaps lower.

Buyers attempt a stronger recovery than in the On Neck Pattern.

However...

The recovery is still too weak.

Price remains below the midpoint of the previous bearish candle.

Sellers continue to control the market.