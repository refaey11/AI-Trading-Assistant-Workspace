# Common Mistakes

❌ Trading it as a reversal.

❌ Ignoring the existing downtrend.

❌ Confusing it with the Piercing Pattern.

❌ Ignoring the midpoint rule.

❌ Entering before bearish confirmation.

❌ Buying because the second candle is bullish.