# Case Study 01 — Figure 15.1

## Title
Bonds — Volume with Candlesticks

## Figure
Exhibit 15.1 — Bonds, June 1990, Daily (Volume with Candlesticks)

## Market
Bonds

## Timeframe
Daily

## Main Concept
Using trading volume to confirm price movement and candlestick signals.

## Market Situation

The market moved toward the high around $94.

Trading volume was approximately 504,000 contracts, representing the total volume of all contracts traded during the month.

The market attempted to move above $94 but failed.

## Candlestick Evidence

A small white candlestick appeared during the period of weak trading volume.

The loss of momentum was followed by a decline in the market.

## Volume Evidence

Trading volume weakened while the market was attempting to move higher.

This provided evidence that the upward movement was losing strength.

## Interpretation

The combination of:

- Price approaching a significant level
- Weak trading volume
- Candlestick evidence

provided a warning that the advance was losing strength.

The market subsequently declined.

## Trading Lesson

A price advance should be examined together with its volume.

If price reaches an important level while volume weakens, the trader should become more cautious.

## Key Takeaway

Weak volume during an attempted advance can provide an early warning of weakening buying pressure.

Volume should be combined with candlestick evidence rather than used alone.