# TC014 - Common Mistakes

## Mistake 1

Selling automatically when an oscillator becomes overbought.

---

## Mistake 2

Buying automatically when an oscillator becomes oversold.

---

## Mistake 3

Ignoring the dominant market trend.

---

## Mistake 4

Trading divergence without price-action confirmation.

---

## Mistake 5

Ignoring Candlestick patterns.

---

## Mistake 6

Using oscillators as standalone signals.

---

## Mistake 7

Ignoring the timeframe.

---

## Mistake 8

Treating every divergence as equally important.

Divergence near major support, resistance, or oscillator extremes is generally more meaningful.

---

## Mistake 9

Using oscillators aggressively when a new major trend is beginning.

An oscillator may remain overbought during a strong new uptrend or oversold during a strong new downtrend.

---

## Mistake 10

Ignoring momentum deterioration.

A sideways oscillator during a continued price trend can be an early warning that price velocity is declining.

---

## Professional Rule

Oscillator

+

Trend

+

Candlestick

+

Market Structure

+

Risk Management

is stronger than any single indicator.