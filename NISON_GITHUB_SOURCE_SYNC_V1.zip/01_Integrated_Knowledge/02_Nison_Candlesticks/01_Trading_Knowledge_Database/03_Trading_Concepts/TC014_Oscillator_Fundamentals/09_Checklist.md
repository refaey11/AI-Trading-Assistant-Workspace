# TC014 - Oscillator Checklist

□ Dominant trend identified.

□ Oscillator identified.

□ Current oscillator reading checked.

□ Divergence checked.

□ Overbought / Oversold condition checked.

□ Momentum direction checked.

□ Candlestick confirmation checked.

□ Support / Resistance checked.

□ Higher timeframe context checked.

□ Entry defined.

□ Stop Loss defined.

□ Target defined.

□ Risk / Reward acceptable.

□ Trade documented.