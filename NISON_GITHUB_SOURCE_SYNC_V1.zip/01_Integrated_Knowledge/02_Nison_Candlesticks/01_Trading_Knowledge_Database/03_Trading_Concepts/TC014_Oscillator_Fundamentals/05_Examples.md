# TC014 - Examples

## Example 1 - Bullish Divergence

Price forms a lower low.

Oscillator forms a higher low.

Interpretation:

Selling pressure is weakening.

Action:

Wait for bullish Candlestick confirmation.

---

## Example 2 - Bearish Divergence

Price forms a higher high.

Oscillator forms a lower high.

Interpretation:

Buying momentum is weakening.

Action:

Look for bearish Candlestick confirmation.

---

## Example 3 - Overbought During Uptrend

Oscillator reaches an overbought level.

Price continues making higher highs.

Interpretation:

Do not automatically short.

The oscillator may remain overbought during a strong trend.

---

## Example 4 - Oversold During Downtrend

Oscillator reaches an oversold level.

Price continues making lower lows.

Interpretation:

Do not automatically buy.

Wait for evidence that selling pressure is weakening.

---

## Example 5 - Momentum Weakening

Price continues rising.

Oscillator begins moving sideways.

Interpretation:

The speed of the price advance is declining.

Action:

Monitor for divergence or bearish Candlestick confirmation.