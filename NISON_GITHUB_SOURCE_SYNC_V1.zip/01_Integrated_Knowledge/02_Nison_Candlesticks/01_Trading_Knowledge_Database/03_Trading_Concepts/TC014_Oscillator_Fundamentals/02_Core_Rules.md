# TC014 - Core Rules

## Rule 1 - Divergence

Bearish divergence occurs when:

Price makes a new high

while

The oscillator fails to make a new high.

This indicates weakening upward momentum.

---

## Rule 2 - Bullish Divergence

Bullish divergence occurs when:

Price makes a new low

while

The oscillator fails to make a new low.

This indicates weakening selling pressure.

---

## Rule 3 - Overbought

An oscillator reaching an extreme upper reading may indicate that the market is stretched and vulnerable to consolidation or correction.

---

## Rule 4 - Oversold

An oscillator reaching an extreme lower reading may indicate that selling pressure is becoming exhausted.

---

## Rule 5 - Trend Context

Oscillator signals should be traded in the direction of the dominant market trend.

---

## Rule 6 - Strong Trends

Do not automatically sell simply because an oscillator reaches an overbought level during a strong uptrend.

The market may remain overbought while continuing higher.

---

## Rule 7 - Weak Trends

Do not automatically buy simply because an oscillator reaches an oversold level during a strong downtrend.

---

## Rule 8 - Candlestick Confirmation

Oscillator signals become more useful when confirmed by Japanese Candlestick patterns.

---

## Rule 9 - Momentum

A flattening oscillator during a continuing price trend can warn that price momentum is weakening.

---

## Rule 10 - Multiple Confirmation

The strongest signals occur when:

Trend

+

Oscillator

+

Candlestick

+

Support / Resistance

agree.