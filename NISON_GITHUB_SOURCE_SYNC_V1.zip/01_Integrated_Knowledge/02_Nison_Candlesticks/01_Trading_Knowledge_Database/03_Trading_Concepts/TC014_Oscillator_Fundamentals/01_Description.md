# TC014 - Oscillator Fundamentals

## Name

Oscillator Fundamentals

## Category

Technical Indicators

Momentum Analysis

Overbought / Oversold

Divergence

## Source

Steve Nison

Beyond Candlesticks

Chapter 14

## Definition

Oscillators are mathematically derived technical indicators used to provide a more objective way of analyzing market behavior.

They are widely used in technical analysis and form the foundation of many computer-based trading systems.

## Main Oscillators Covered

- Relative Strength Index (RSI)
- Stochastics
- Momentum

## Primary Functions

Oscillators provide three major analytical functions:

1. Divergence Detection
2. Overbought / Oversold Analysis
3. Momentum and Trend Strength Confirmation

## Important Principle

Oscillators should complement price action and Japanese Candlestick analysis rather than replace them.