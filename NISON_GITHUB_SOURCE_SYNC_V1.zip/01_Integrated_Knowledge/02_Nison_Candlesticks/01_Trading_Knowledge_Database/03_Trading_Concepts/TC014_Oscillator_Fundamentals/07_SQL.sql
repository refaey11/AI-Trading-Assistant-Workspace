CREATE TABLE oscillator_fundamentals (

    id INTEGER PRIMARY KEY,

    concept_code TEXT NOT NULL,

    oscillator_type TEXT,

    function_type TEXT,

    trend_direction TEXT,

    divergence_type TEXT,

    overbought_condition TEXT,

    oversold_condition TEXT,

    momentum_condition TEXT,

    candlestick_confirmation TEXT,

    support_resistance TEXT,

    entry_rule TEXT,

    exit_rule TEXT,

    confidence_level TEXT,

    source_reference TEXT,

    notes TEXT
);