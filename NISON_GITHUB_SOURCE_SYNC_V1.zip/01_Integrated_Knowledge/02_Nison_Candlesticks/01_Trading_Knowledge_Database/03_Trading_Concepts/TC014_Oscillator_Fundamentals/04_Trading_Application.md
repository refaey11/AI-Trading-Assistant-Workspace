# TC014 - Trading Application

## Application 1 - Bullish Divergence

Price:

New Low

↓

Oscillator:

Higher Low

↓

Bullish Divergence

↓

Look for Candlestick Confirmation

↓

Potential Long Setup

---

## Application 2 - Bearish Divergence

Price:

New High

↓

Oscillator:

Lower High

↓

Bearish Divergence

↓

Look for Bearish Candlestick Confirmation

↓

Potential Short / Long Exit Setup

---

## Application 3 - Overbought

Oscillator reaches extreme upper zone.

↓

Check market trend.

↓

Check Candlestick Confirmation.

↓

If bearish confirmation appears:

Potential correction / exit.

---

## Application 4 - Oversold

Oscillator reaches extreme lower zone.

↓

Check market trend.

↓

Check Candlestick Confirmation.

↓

If bullish confirmation appears:

Potential rebound / short covering.

---

## Application 5 - Momentum

Price continues moving in one direction.

↓

Oscillator begins moving sideways.

↓

Momentum is weakening.

↓

Increase attention to reversal signals.

---

## Professional Workflow

1. Identify dominant trend.
2. Select appropriate oscillator.
3. Check divergence.
4. Check overbought / oversold condition.
5. Check oscillator momentum.
6. Identify Candlestick confirmation.
7. Check support / resistance.
8. Define entry.
9. Define Stop Loss.
10. Define Target.
11. Calculate Risk / Reward.
12. Record the trade.