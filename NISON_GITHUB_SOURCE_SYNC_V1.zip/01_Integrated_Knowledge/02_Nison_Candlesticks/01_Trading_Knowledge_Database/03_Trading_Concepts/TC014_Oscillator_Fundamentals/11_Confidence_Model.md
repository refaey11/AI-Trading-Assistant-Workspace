# TC014 - Confidence Model

## Scoring

Dominant Trend Alignment

+20

Valid Oscillator Signal

+15

Bullish / Bearish Divergence

+20

Overbought / Oversold Context

+10

Candlestick Confirmation

+15

Support / Resistance Confirmation

+10

Risk / Reward

+10

## Total

100 Points

---

## Interpretation

90–100

Very High Confidence

70–89

High Confidence

50–69

Moderate Confidence

Below 50

Avoid Trade

---

## Important

The confidence score is a decision-support framework.

It is not a guarantee of trade outcome.