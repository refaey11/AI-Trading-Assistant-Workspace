# TC014 - Market Psychology

## Why Oscillators Matter

Price tells us where the market is moving.

Oscillators help measure the internal strength behind that movement.

---

## Bullish Psychology

When price reaches a new low but the oscillator does not:

Selling pressure may be weakening.

This creates Bullish Divergence.

---

## Bearish Psychology

When price reaches a new high but the oscillator does not:

Buying momentum may be weakening.

This creates Bearish Divergence.

---

## Overbought Psychology

An overbought reading means the market has experienced strong recent buying pressure.

It does not automatically mean that price must fall.

The market may remain overbought while a strong trend continues.

---

## Oversold Psychology

An oversold reading means the market has experienced strong recent selling pressure.

It does not automatically mean that price must rise.

---

## Momentum Psychology

Momentum measures the speed of price movement.

When price continues rising but momentum begins moving sideways:

The speed of the advance is declining.

This can provide an early warning of a potential trend change.

---

## Professional Mindset

Oscillators are confirmation tools.

They should answer:

"Is the current price movement supported by sufficient momentum?"

rather than:

"Should I buy or sell immediately?"