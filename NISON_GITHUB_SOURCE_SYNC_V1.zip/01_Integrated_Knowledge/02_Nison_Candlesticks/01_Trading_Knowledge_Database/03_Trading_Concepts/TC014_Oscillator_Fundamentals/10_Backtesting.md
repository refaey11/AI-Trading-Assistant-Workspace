# TC014 - Backtesting

## Objective

Evaluate whether oscillator signals provide a measurable trading advantage when combined with trend and Candlestick confirmation.

## Data

Trade Number

Date

Asset

Timeframe

Oscillator

Oscillator Period

Trend

Oscillator Reading

Divergence

Overbought / Oversold

Momentum Direction

Candlestick Pattern

Support / Resistance

Entry

Stop Loss

Target

Exit

Result

R-Multiple

Maximum Favorable Excursion

Maximum Adverse Excursion

Notes

## Metrics

Win Rate

Loss Rate

Profit Factor

Expectancy

Average R

Maximum Drawdown

Average Holding Time

False Signal Rate

Divergence Success Rate

Candlestick Confirmation Success Rate

## Testing Groups

Test separately:

1. Oscillator only.
2. Oscillator + Trend.
3. Oscillator + Candlestick.
4. Oscillator + Trend + Candlestick.
5. Oscillator + Trend + Candlestick + Support/Resistance.

The purpose is to determine whether additional confirmation actually improves performance.