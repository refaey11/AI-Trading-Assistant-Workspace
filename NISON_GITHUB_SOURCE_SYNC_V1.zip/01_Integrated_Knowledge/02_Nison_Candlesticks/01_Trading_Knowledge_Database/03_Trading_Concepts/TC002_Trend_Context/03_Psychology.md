# TC002 — Trend Context

## Psychology

The market trend represents the overall control between buyers and sellers.

A candlestick pattern only shows a specific market situation, but the larger trend provides the environment in which that pattern appears.

A signal that appears against the main trend may not have enough strength to change market direction.

Traders should understand the market battle before relying on a candlestick signal.

## Source

Steve Nison — Chapter 7: Continuation Patterns