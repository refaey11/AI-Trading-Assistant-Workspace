# TC002 — Trend Context

## Checklist

Before using a candlestick signal:

- [ ] Identify the overall market trend.
- [ ] Determine if the pattern appears with or against the trend.
- [ ] Avoid decisions based only on one candlestick pattern.
- [ ] Consider the surrounding market environment.
- [ ] Confirm before taking action.

## Source

Steve Nison — Chapter 7