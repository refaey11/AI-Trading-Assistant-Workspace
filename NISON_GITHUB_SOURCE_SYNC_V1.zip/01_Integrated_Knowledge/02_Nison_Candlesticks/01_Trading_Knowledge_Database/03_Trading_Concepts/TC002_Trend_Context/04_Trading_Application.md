# TC002 — Trend Context

## Trading Application

Before using any candlestick signal:

1. Identify the overall market trend.
2. Evaluate the candlestick pattern within that trend.
3. Avoid taking positions only because a single pattern appears.

Example:

A bullish pattern during a downtrend should not immediately lead to buying.

The market needs to show enough evidence that buyers are gaining control.

## Source

Steve Nison — Chapter 7: Continuation Patterns