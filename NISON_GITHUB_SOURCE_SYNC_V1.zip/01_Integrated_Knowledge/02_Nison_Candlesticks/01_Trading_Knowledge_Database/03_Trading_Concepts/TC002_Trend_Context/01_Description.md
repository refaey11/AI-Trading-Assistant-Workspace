# TC002 — Trend Context

## Source
Steve Nison — Japanese Candlestick Charting Techniques

## Chapter
Chapter 7 — Continuation Patterns

## Category
Trading Concept

## Description

Japanese candlestick analysis should always be used within the context of the overall market trend.

Candlestick signals and any other analytical tools should not be considered separately from the general direction of the market.

The importance of the overall trend determines how a candlestick pattern should be interpreted.

A bullish candlestick pattern appearing during a downtrend does not automatically mean that the market will reverse.

The market trend must be considered before taking a trading decision.

## Source Reference

Steve Nison — Chapter 7: Continuation Patterns