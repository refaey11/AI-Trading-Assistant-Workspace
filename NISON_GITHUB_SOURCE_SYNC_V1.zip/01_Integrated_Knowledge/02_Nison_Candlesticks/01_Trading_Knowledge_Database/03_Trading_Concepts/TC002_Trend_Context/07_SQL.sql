CREATE TABLE trading_concepts_context (
    concept_id VARCHAR(20) PRIMARY KEY,
    concept_name VARCHAR(100),
    category VARCHAR(50),
    source VARCHAR(100),
    chapter VARCHAR(100),
    description TEXT,
    rules TEXT,
    application TEXT,
    confirmation TEXT
);


INSERT INTO trading_concepts_context VALUES
(
'TC002',
'Trend Context',
'Trading Concept',
'Steve Nison',
'Chapter 7 - Continuation Patterns',

'Japanese candlestick analysis should always be used within the context of the overall market trend.',

'Identify the general trend before interpreting candlestick patterns. Do not use signals separately from market direction.',

'Analyze candlestick patterns according to the surrounding market environment.',

'Confirm the trend before relying on any candlestick signal.'
);