# TC002 — Trend Context

## Examples

## Example 1 — Bullish Pattern Inside Downtrend

A Morning Star appeared while the overall market trend was still downward.

The appearance of the bullish pattern alone was not enough to justify buying.

The correct approach was to wait until buyers pushed prices above an important Window level.

---

## Example 2 — Window and Trend Confirmation

A Window appeared during a market move.

The interpretation of the Window depended on the direction of the overall trend.

The same tool can have different meanings depending on market context.

## Source

Steve Nison — Chapter 7: Continuation Patterns