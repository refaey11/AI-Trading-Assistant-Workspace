# TC002 — Trend Context

## Backtesting

Test whether candlestick signals behave differently depending on the overall trend.

Record:

- Market trend.
- Candlestick pattern.
- Pattern direction.
- Result after the signal.
- Whether the pattern followed or opposed the trend.

The purpose is to evaluate the importance of trend context when interpreting candlestick signals.

## Source

Steve Nison — Chapter 7