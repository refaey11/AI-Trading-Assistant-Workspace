# TC002 — Trend Context

## Common Mistakes

### 1. Trading a Pattern Alone

Ignoring the overall market trend can lead to incorrect interpretation.

### 2. Assuming Every Bullish Signal Means Buying

A bullish pattern inside a downtrend does not automatically mean reversal.

### 3. Ignoring Market Environment

Patterns must be evaluated according to where they appear.

### 4. Forgetting Trend Direction

The same pattern can have different meanings depending on the trend.

## Source

Steve Nison — Chapter 7: Continuation Patterns