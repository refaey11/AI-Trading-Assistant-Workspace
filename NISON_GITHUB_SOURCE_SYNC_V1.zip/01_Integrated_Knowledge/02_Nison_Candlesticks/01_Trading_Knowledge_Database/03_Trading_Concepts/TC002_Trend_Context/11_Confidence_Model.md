# TC002 — Trend Context

## Confirmation

Confirmation requires:

- Identifying the overall market trend.
- Understanding the location of the candlestick pattern.
- Evaluating whether the signal supports or conflicts with the trend.

A candlestick pattern should be interpreted inside the market context.

## Source

Steve Nison — Chapter 7