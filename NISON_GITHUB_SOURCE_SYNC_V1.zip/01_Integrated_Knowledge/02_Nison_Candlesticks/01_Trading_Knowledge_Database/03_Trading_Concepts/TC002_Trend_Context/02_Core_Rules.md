# TC002 — Trend Context

## Core Rules

- Always identify the general market trend before interpreting candlestick patterns.
- A candlestick signal should not be used alone without considering the market direction.
- A bullish pattern in a downtrend does not automatically create a buying opportunity.
- A bearish pattern in an uptrend does not automatically mean a complete reversal.
- Continuation and reversal patterns must be evaluated according to the surrounding market environment.

## Source

Steve Nison — Chapter 7: Continuation Patterns