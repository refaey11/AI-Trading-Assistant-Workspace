# TC003 — Incomplete Patterns

## Source
Steve Nison — Japanese Candlestick Charting Techniques

## Chapter
Chapter 7 — Continuation Patterns

## Category
Trading Concept

## Description

A trading decision should never be made based on a candlestick pattern before the pattern is completed.

A pattern must first complete its required conditions before its implication can be considered valid.

Steve Nison illustrates this concept using an incomplete Falling Three Methods pattern, where the final candle failed to satisfy the completion rules.

Because the pattern never completed, it could not be used as a valid bearish continuation signal.

## Source Reference

Steve Nison — Chapter 7