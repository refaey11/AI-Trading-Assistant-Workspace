# TC003 — Incomplete Patterns

## Backtesting

Compare:

- Completed patterns.
- Incomplete patterns.

Record:

- Pattern Name
- Complete (Yes / No)
- Trade Taken (Yes / No)
- Result

Purpose:

Evaluate the importance of waiting for completion before entering trades.

## Source

Steve Nison — Chapter 7