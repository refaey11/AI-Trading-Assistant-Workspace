# TC003 — Incomplete Patterns

## Trading Application

Before acting on any candlestick pattern:

1. Verify that every formation rule has been satisfied.
2. Wait until the final candle completes.
3. Ignore patterns that fail to meet the required completion conditions.

In Steve Nison's example, the Falling Three Methods pattern was ignored because the last candle failed to close below the first black candle.

## Source

Steve Nison — Chapter 7