# TC003 — Incomplete Patterns

## Confirmation

Confirmation exists only after:

- The final candle closes.
- Every required formation condition is satisfied.

Without completion, the pattern has no trading value.

## Source

Steve Nison — Chapter 7