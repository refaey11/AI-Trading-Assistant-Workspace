CREATE TABLE trading_concepts_execution (

    concept_id VARCHAR(20) PRIMARY KEY,
    concept_name VARCHAR(100),
    source VARCHAR(100),
    chapter VARCHAR(100),
    description TEXT,
    rules TEXT,
    confirmation TEXT

);

INSERT INTO trading_concepts_execution
VALUES(

'TC003',

'Incomplete Patterns',

'Steve Nison',

'Chapter 7',

'Never trade before a candlestick pattern is completed.',

'Verify all formation rules. Wait for the final candle. Ignore incomplete patterns.',

'Pattern satisfies every required completion condition.'

);