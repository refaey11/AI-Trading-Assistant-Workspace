# TC003 — Incomplete Patterns

## Checklist

- [ ] Has the final candle closed?
- [ ] Are all formation rules satisfied?
- [ ] Is the pattern complete?
- [ ] Has confirmation been received?
- [ ] Avoid trading incomplete patterns.

## Source

Steve Nison — Chapter 7