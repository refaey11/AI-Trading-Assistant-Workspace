# TC003 — Incomplete Patterns

## Core Rules

- Do not make trading decisions before a pattern is complete.
- A pattern must satisfy all of its required conditions.
- If one of the completion conditions is missing, the pattern is not valid.
- Wait for confirmation before relying on the pattern.

## Source

Steve Nison — Chapter 7