# TC003 — Incomplete Patterns

## Common Mistakes

### 1. Trading Before Completion

Entering before the final candle closes.

### 2. Ignoring Missing Conditions

Considering a pattern valid even though one formation rule is missing.

### 3. Ignoring Later Candles

A later candlestick may completely change the interpretation.

## Source

Steve Nison — Chapter 7