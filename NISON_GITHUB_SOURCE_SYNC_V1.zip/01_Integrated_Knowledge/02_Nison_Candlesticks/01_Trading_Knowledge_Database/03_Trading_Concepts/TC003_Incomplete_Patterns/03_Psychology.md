# TC003 — Incomplete Patterns

## Psychology

An incomplete pattern represents uncertainty.

The market has not yet finished delivering its message.

Acting before completion means acting before buyers and sellers have revealed the true outcome.

Patience is required until the pattern becomes complete.

## Source

Steve Nison — Chapter 7