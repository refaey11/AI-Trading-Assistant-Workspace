# TC003 — Incomplete Patterns

## Example

An apparent Falling Three Methods pattern developed.

The first long black candle appeared.

Three small rising candles followed.

Another black candle appeared.

However, the final candle did not close below the close of the first black candle.

The pattern remained incomplete.

A Doji appeared afterwards and formed a Harami Cross, indicating weakness in the previous downtrend.

This example demonstrates why traders should wait for pattern completion.

## Source

Steve Nison — Chapter 7