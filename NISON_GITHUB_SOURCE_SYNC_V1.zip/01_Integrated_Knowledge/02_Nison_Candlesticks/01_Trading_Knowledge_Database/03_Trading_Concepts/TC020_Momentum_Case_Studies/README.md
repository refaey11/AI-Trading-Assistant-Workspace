# TC020 — Momentum Case Studies

## Chapter

Chapter 14 — Candlesticks and Oscillators

## Subject

Momentum with Japanese Candlesticks.

## Purpose

This collection records the historical examples presented in the source material showing how Momentum can be combined with Japanese candlestick signals.

## Cases

### Case 01 — Figure 14.8
Gold — June 1990, Daily

Key evidence:

- Long-legged Doji
- New price high
- Momentum lower than at the previous price peak
- Momentum later moved below zero

The combination provided additional warning evidence for a downward trend.

### Case 02 — Figure 14.9
Heating Oil — July 1990, Daily

Key evidence:

- Momentum +200 overbought example
- Momentum -400 oversold example
- Evening Star
- Harami
- Hammer formations

The examples demonstrate how Momentum conditions can be considered together with confirming candlestick signals.

## Main Concepts

The cases demonstrate:

- Momentum as a measure of price speed.
- Momentum weakening while price reaches new highs.
- The zero-line indication.
- Overbought conditions.
- Oversold conditions.
- Candlestick confirmation.
- Confluence between Momentum and Japanese candlesticks.

## Source References

- Exhibit 14.8 — Gold, June 1990, Daily
- Exhibit 14.9 — Heating Oil, July 1990, Daily