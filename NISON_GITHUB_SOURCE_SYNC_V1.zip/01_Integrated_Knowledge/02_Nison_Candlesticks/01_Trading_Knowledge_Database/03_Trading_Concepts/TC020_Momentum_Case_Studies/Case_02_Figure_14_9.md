# Case 02 — Figure 14.9
## Heating Oil — July 1990, Daily
### Momentum with Candlesticks

## 1. Case Overview

Figure 14.9 demonstrates the use of the Momentum oscillator to identify overbought and oversold conditions and shows how these conditions can be considered together with candlestick signals.

## 2. Overbought Level

In the Heating Oil chart, a Momentum reading of +200 represented an overbought market.

The source explains that this reading meant:

The current close was $0.02 above the close ten days earlier.

At the +200 level, it was considered unlikely that the market would continue its upward trend in the same manner.

The market would instead be expected either to move sideways or to undergo a correction.

## 3. Oversold Level

The oversold condition occurred at a Momentum reading of -400.

This represented the current close being $0.04 below the close ten days earlier.

## 4. Candlestick Confirmation

The probability of a significant price top was considered greater when an overbought Momentum condition was accompanied by a confirming candlestick signal.

The source provides several examples.

### February

An overbought Momentum condition occurred together with:

- Evening Star
- Followed by a Harami

### April

Another overbought Momentum condition occurred together with:

- Evening Star

These candlestick signals provided additional evidence alongside the overbought Momentum condition.

## 5. March and April Hammer Examples

In March and April, Hammer formations A and B occurred while Momentum was at overbought levels.

At these points, the market was considered unlikely to decline again.

The source states that, to relieve the oversold condition, the market would need either to move sideways or to move upward.

## 6. Key Levels

### Overbought

Momentum = +200

Current close = $0.02 above the close ten days earlier.

### Oversold

Momentum = -400

Current close = $0.04 below the close ten days earlier.

## 7. Combined Evidence

The examples demonstrate the use of:

- Momentum overbought / oversold readings.
- Japanese candlestick signals.
- Evening Star.
- Harami.
- Hammer.

The source emphasizes the additional significance of Momentum conditions when supported by candlestick evidence.

## 8. Source Reference

- Exhibit: 14.9
- Market: Heating Oil
- Contract: July 1990
- Timeframe: Daily
- Indicator: Momentum
- Overbought Example: +200
- Oversold Example: -400
- Candlestick Examples: Evening Star, Harami, Hammer