# Case 01 — Figure 14.8
## Gold — June 1990, Daily
### Momentum with Candlesticks

## 1. Case Overview

Figure 14.8 demonstrates how the Momentum indicator can provide an additional warning when combined with a Japanese candlestick signal.

The example focuses on a long-legged Doji, a new price high, and weakening Momentum.

## 2. Candlestick Signal

A long-legged Doji appeared and provided a warning to traders holding long positions.

The Doji occurred at a new price high.

## 3. Momentum Behavior

Although price reached a new high at the Doji, the Momentum indicator was lower than it had been at the previous price peak at the end of November (A).

### Structure

- Price → New High
- Candlestick → Long-legged Doji
- Momentum → Lower than at the previous price peak
- Interpretation → Weakening internal momentum

## 4. Additional Confirmation

In February, Momentum moved below the zero line.

The source describes this as additional evidence of a downward trend that was about to begin.

## 5. Combined Evidence

The case therefore contained:

Long-legged Doji
+
New Price High
+
Lower Momentum
+
Later Momentum Below Zero

This combination provided warning evidence for a developing downward trend.

## 6. Source Reference

- Exhibit: 14.8
- Market: Gold
- Contract: June 1990
- Timeframe: Daily
- Indicator: Momentum
- Candlestick: Long-legged Doji
- Additional Signal: Momentum moved below zero