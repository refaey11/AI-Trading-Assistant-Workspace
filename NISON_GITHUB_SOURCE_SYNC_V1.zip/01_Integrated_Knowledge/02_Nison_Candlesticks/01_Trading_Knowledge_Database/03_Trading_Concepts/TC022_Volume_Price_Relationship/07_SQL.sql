CREATE TABLE volume_price_relationship (
    id INTEGER PRIMARY KEY,
    topic_code VARCHAR(20),
    price_direction VARCHAR(20),
    volume_direction VARCHAR(20),
    interpretation TEXT,
    trading_implication TEXT,
    confirmation_level VARCHAR(30),
    source_reference TEXT
);

INSERT INTO volume_price_relationship
(
    topic_code,
    price_direction,
    volume_direction,
    interpretation,
    trading_implication,
    confirmation_level,
    source_reference
)
VALUES
(
    'TC022',
    'UP',
    'UP',
    'Increasing volume supports the upward price movement.',
    'Bullish confirmation.',
    'Strong',
    'Chapter 15'
),
(
    'TC022',
    'UP',
    'DOWN',
    'Price is rising while participation is weakening.',
    'Exercise caution.',
    'Warning',
    'Chapter 15'
),
(
    'TC022',
    'DOWN',
    'UP',
    'Increasing volume supports stronger selling pressure.',
    'Bearish confirmation.',
    'Strong',
    'Chapter 15'
),
(
    'TC022',
    'DOWN',
    'DOWN',
    'Selling participation may be weakening.',
    'Monitor for possible stabilization.',
    'Moderate',
    'Chapter 15'
);