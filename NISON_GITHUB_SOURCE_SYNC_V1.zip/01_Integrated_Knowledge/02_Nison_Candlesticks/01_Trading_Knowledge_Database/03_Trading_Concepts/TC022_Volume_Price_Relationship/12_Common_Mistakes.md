# Common Mistakes — Volume & Price Relationship

## Mistake 1

Assuming declining volume always means a reversal.

### Correction

Declining volume is a warning about participation, not a guaranteed reversal signal.

---

## Mistake 2

Buying every time price falls with decreasing volume.

### Correction

Wait for additional price-action or candlestick evidence.

---

## Mistake 3

Selling immediately when price rises with decreasing volume.

### Correction

Weak volume does not mean that price must reverse.

---

## Mistake 4

Ignoring new highs and new lows.

### Correction

Always compare volume behavior with important price extremes.

---

## Mistake 5

Using volume without price.

### Correction

The relationship between price and volume is more useful than volume alone.

---

## Mistake 6

Ignoring candlestick confirmation.

### Correction

Use candlestick patterns as additional evidence when available.

---

## Mistake 7

Treating one volume reading as decisive.

### Correction

Analyze volume within the broader sequence of price and volume behavior.