# Core Rules — Volume & Price Relationship

## Rule 1 — Rising Price + Rising Volume

When price rises while volume increases, the upward movement receives stronger confirmation.

## Rule 2 — Rising Price + Declining Volume

When price continues rising while volume declines, caution is required.

The advance may be losing participation.

## Rule 3 — Falling Price + Rising Volume

Falling prices accompanied by increasing volume indicate stronger selling participation.

## Rule 4 — Falling Price + Declining Volume

A decline accompanied by decreasing volume can indicate weakening selling pressure.

## Rule 5 — New High + Weak Volume

A new price high accompanied by weaker volume can be a warning that the advance is losing strength.

## Rule 6 — New Low + Weak Volume

A new low accompanied by weaker selling activity can provide evidence that downward pressure may be weakening.

## Rule 7 — Candlestick Confirmation

Volume becomes more useful when it confirms an important candlestick signal.

## Rule 8 — Context

Volume must always be interpreted within the larger price structure and market context.