# Trading Application — Volume & Price Relationship

## Scenario 1 — Bullish Confirmation

Conditions:

- Price is rising.
- Volume is increasing.
- Market structure remains bullish.

Interpretation:

The volume behavior supports the upward movement.

---

## Scenario 2 — Bullish Move With Weak Volume

Conditions:

- Price continues making higher prices.
- Volume decreases.

Interpretation:

The advance should be monitored carefully.

The market may be moving upward despite weaker participation.

---

## Scenario 3 — Bearish Confirmation

Conditions:

- Price is falling.
- Volume is increasing.

Interpretation:

Selling pressure is receiving volume confirmation.

---

## Scenario 4 — Weakening Decline

Conditions:

- Price continues falling.
- Volume decreases.

Interpretation:

The selling pressure may be weakening.

This does not automatically create a buy signal.

---

## Scenario 5 — Candlestick + Volume

A candlestick reversal signal becomes more significant when volume behavior supports the interpretation.

Example:

A bullish candlestick appears near a low while selling volume weakens.

This combination provides stronger evidence than the candlestick alone.

## Important

Do not enter a trade only because volume increased or decreased.

Use volume as part of a complete analysis.