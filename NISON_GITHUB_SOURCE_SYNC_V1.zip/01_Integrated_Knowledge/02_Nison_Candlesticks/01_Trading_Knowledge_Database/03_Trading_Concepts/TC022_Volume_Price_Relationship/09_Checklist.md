# Volume & Price Checklist

### Price

- [ ] Is price rising?
- [ ] Is price falling?
- [ ] Has price reached a new high?
- [ ] Has price reached a new low?

### Volume

- [ ] Is volume increasing?
- [ ] Is volume decreasing?
- [ ] Is volume confirming the price movement?
- [ ] Is volume weakening during a new price extreme?

### Pressure

- [ ] Is buying pressure increasing?
- [ ] Is selling pressure increasing?
- [ ] Is buying participation weakening?
- [ ] Is selling participation weakening?

### Candlesticks

- [ ] Is there a reversal pattern?
- [ ] Is there a continuation pattern?
- [ ] Does volume support the candlestick signal?

### Decision

- [ ] Is the evidence strong enough?
- [ ] Am I using volume as confirmation?
- [ ] Am I avoiding a trade based on volume alone?