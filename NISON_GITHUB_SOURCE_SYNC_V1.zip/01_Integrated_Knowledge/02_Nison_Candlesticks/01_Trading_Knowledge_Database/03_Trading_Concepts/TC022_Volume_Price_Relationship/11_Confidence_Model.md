# Confidence Model — Volume & Price Relationship

## Strong Bullish Evidence

- Price rising
- Volume increasing
- Bullish candlestick confirmation
- Support or other technical confirmation

## Moderate Bullish Evidence

- Price rising
- Volume increasing

## Warning

- Price rising
- Volume decreasing

This is a warning, not an automatic sell signal.

## Strong Bearish Evidence

- Price falling
- Volume increasing
- Bearish candlestick confirmation
- Resistance or other technical confirmation

## Moderate Bearish Evidence

- Price falling
- Volume increasing

## Warning

- Price falling
- Volume decreasing

This may indicate weakening selling pressure but does not automatically create a buy signal.

## Core Principle

Confidence should increase when multiple independent pieces of evidence agree.