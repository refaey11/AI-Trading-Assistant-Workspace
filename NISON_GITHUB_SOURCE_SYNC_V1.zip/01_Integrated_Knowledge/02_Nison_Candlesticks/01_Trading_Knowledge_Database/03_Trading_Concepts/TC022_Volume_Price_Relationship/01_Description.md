# Volume & Price Relationship

## Definition

Volume can be used together with price movement to evaluate the strength or weakness of a market move.

The main idea is that price movement and trading volume should be analyzed together rather than separately.

## Core Concept

When prices rise:

- Increasing volume can support the strength of the advance.
- Declining volume can indicate weaker participation and should increase caution.

When prices fall:

- Increasing volume can support the strength of selling pressure.
- Declining volume can indicate weakening selling pressure.

## Volume as Confirmation

Volume does not predict price by itself.

It provides additional evidence that can confirm or weaken an interpretation obtained from price action and candlesticks.

## Key Principle

Price tells us what the market is doing.

Volume helps us evaluate the participation behind that movement.