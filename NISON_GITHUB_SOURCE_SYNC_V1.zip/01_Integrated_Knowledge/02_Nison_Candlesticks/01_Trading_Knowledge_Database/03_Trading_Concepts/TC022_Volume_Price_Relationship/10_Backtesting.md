# Backtesting — Volume & Price Relationship

## Objective

Test whether the relationship between price and volume provides useful confirmation for candlestick and price-action setups.

## Data Required

For each historical setup record:

- Market
- Date
- Timeframe
- Price direction
- Volume direction
- Previous high/low
- New high/low
- Candlestick pattern
- Entry
- Stop Loss
- Target
- Result

## Classifications

### Bullish Confirmation

Price UP + Volume UP

### Bullish Warning

Price UP + Volume DOWN

### Bearish Confirmation

Price DOWN + Volume UP

### Bearish Weakening

Price DOWN + Volume DOWN

## Test

Compare the performance of setups:

1. With volume confirmation.
2. Without volume confirmation.
3. With weakening volume.
4. With candlestick confirmation.

## Goal

Determine whether volume adds measurable statistical value to the trading setup.