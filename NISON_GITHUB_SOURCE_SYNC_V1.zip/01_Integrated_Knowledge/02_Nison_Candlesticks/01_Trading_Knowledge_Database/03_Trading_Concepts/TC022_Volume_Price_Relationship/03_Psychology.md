# Psychology — Volume & Price Relationship

Volume provides information about market participation.

## Rising Prices

When prices rise with increasing volume, more market participants are supporting the advance.

This can indicate stronger buying interest.

## Rising Prices With Falling Volume

If prices continue to rise while volume decreases, the market may still be advancing, but participation is becoming weaker.

This does not automatically mean that the market must reverse.

It means the trader should become more cautious.

## Falling Prices

When prices decline with increasing volume, selling participation is stronger.

## Falling Prices With Weakening Volume

If prices continue falling while volume becomes weaker, selling pressure may be losing strength.

## Main Psychological Principle

The relationship between price and volume can reveal whether participation is supporting or weakening the current movement.