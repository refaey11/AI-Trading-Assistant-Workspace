# Examples — Volume & Price Relationship

## Example 1 — Bonds

A market moved upward while trading volume increased.

The increase in volume supported the interpretation that the advance had strong participation.

---

## Example 2 — Bonds: Weakening Volume

The market reached higher prices while volume weakened.

The chapter uses this type of behavior as evidence that the strength behind the movement may be weakening.

---

## Example 3 — Silver

The market experienced a strong decline.

After a candlestick reversal pattern appeared, volume behavior provided additional evidence concerning the possible formation of a low.

The combination of price action, candlestick structure, and volume was more informative than volume alone.

---

## Example 4 — Cocoa

A bullish candlestick signal appeared.

Price subsequently moved higher, but the advance was accompanied by a reduction in trading volume.

This demonstrated why volume should be monitored even after a bullish price signal.

---

## Example 5 — New High With Weak Participation

Price reaches a new high while volume fails to confirm the move.

Interpretation:

The market may still continue upward, but the trader should treat the new high with greater caution.