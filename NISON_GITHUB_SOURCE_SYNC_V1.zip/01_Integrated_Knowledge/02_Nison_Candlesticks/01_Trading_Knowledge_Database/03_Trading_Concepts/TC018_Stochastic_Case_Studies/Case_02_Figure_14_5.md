# Case 02 — Figure 14.5
## Copper — Weekly
### Stochastics with Candlesticks

## 1. Case Overview

Figure 14.5 demonstrates the use of the Stochastic Oscillator together with Japanese candlesticks to evaluate the possibility of a new solid bottom in the copper market.

The case focuses on:

- Hammer formations
- Positive divergence
- Positive K% / D% crossover
- Oversold conditions

## 2. Candlestick Signals

In the middle of 1989, the copper market formed a solid bottom after a Hammer appeared.

Another series of Hammers appeared in early 1990.

This raised the question of whether these Hammers indicated the formation of another solid bottom.

## 3. Positive Stochastic Divergence

Hammer B reached a lower price bottom than bottom A.

However, the Stochastic reading at B was higher than the reading at A.

### Divergence Structure

- Price → Lower Low
- Stochastic → Higher Reading
- Result → Positive Divergence

This positive divergence indicated that selling pressure on the market was weakening.

## 4. Positive K% / D% Crossover

There was also a positive crossover.

The continuous K% line moved above the dotted D% line.

## 5. Oversold Condition

The positive crossover became more significant because it occurred together with an oversold reading.

The text identifies the oversold condition as:

D% < 25%

## 6. Confluence of Evidence

In early 1990, several technical indications appeared together:

- A group of Hammer-like candlesticks
- Positive divergence
- Positive K% / D% crossover
- Oversold condition

The book describes this group of technical indications as strong enough to announce the end of the declining trend.

## 7. Key Structure

### Price
Lower Low at B Compared with A

### Candlestick
Hammer-like Formations

### Stochastic Divergence
Positive Divergence

### Crossover
K% Crossed Above D%

### Market Condition
Oversold — Below 25%

### Combined Evidence
Hammer-like Candlesticks
+
Positive Divergence
+
Positive K% / D% Crossover
+
Oversold Condition

### Result
Evidence supporting the end of the declining trend.

## 8. Source Reference

- Exhibit: 14.5
- Market: Copper
- Timeframe: Weekly
- Analysis: Stochastics with Candlesticks
- Candlestick Evidence: Hammers
- Stochastic Signal: Positive Divergence
- Crossover: K% Above D%
- Oversold Reference: Below 25%