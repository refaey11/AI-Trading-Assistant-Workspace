# Case 04 — Figure 14.7
## British Pound — June 1990, Daily
### Stochastics with Candlesticks

## 1. Case Overview

Figure 14.7 demonstrates how an imperfect candlestick pattern can receive additional support from the Stochastic Oscillator.

The case focuses on an imperfect Morning Star, positive divergence, and a subsequent positive K% / D% crossover.

## 2. Market Context

The text notes that Japanese candlesticks are not frequently used with British Pound futures because the chart often contains:

- Small real bodies.
- Doji candlesticks.
- Frequent overnight gaps.

However, the market sometimes produces candlestick signals worth watching, especially when they are confirmed by another indicator.

## 3. Candlestick Signal

During the week of March 19, an imperfect Morning Star appeared.

The third white candlestick did not penetrate deeply enough into the territory of the first black candlestick for the pattern to be considered a perfect Morning Star.

The text emphasizes that other technical evidence should be reviewed before deciding how important an imperfect pattern is.

## 4. Positive Stochastic Divergence

At the Morning Star, or more precisely the imperfect Morning Star, prices reached a new low.

However, the Stochastic Oscillator did not reach a new low.

### Divergence Structure

- Price → New Low
- Stochastic → Failed to Make a New Low
- Result → Positive Bullish Divergence

This provided bullish evidence despite the imperfection of the candlestick pattern.

## 5. Positive K% / D% Crossover

The positive divergence was subsequently confirmed when:

K% crossed above D%

This provided additional bullish confirmation.

## 6. Interpretation

The imperfect Morning Star initially caused the trader to pause, at least temporarily, before assuming that a new bottom was approaching.

However, the Stochastic Oscillator provided additional evidence:

- Positive divergence appeared.
- K% later crossed above D%.

The Stochastic evidence therefore supported the possibility that a bottom was approaching.

## 7. Key Structure

### Price
New Low

### Candlestick
Imperfect Morning Star

### Stochastic Divergence
Positive Bullish Divergence

### Crossover
K% Crossed Above D%

### Combined Evidence
Imperfect Morning Star
+
Positive Stochastic Divergence
+
Positive K% / D% Crossover

### Result
Evidence supporting the approach of a market bottom.

## 8. Source Reference

- Exhibit: 14.7
- Market: British Pound
- Contract: June 1990
- Timeframe: Daily
- Analysis: Stochastics with Candlesticks
- Candlestick Pattern: Imperfect Morning Star
- Stochastic Signal: Positive Divergence
- Crossover: K% Above D%