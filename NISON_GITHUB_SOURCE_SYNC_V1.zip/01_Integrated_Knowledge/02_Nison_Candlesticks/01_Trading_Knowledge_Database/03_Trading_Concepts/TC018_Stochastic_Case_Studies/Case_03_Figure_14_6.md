# Case 03 — Figure 14.6
## S&P — June 1990, Daily
### Stochastics with Candlesticks

## 1. Case Overview

Figure 14.6 demonstrates the combination of a Japanese candlestick signal with negative divergence in the Stochastic Oscillator, followed by confirmation from a negative K% / D% crossover.

## 2. Candlestick Signal

The candlesticks of April 2 and April 16 formed a Dark Cloud Cover pattern.

On April 16, the black candlestick pushed prices above the highest points of March.

Price therefore reached a new high.

## 3. Negative Stochastic Divergence

Although price reached a new high, the Stochastic Oscillator did not reach a new high.

### Divergence Structure

- Price → New High
- Stochastic → No New High
- Result → Negative Divergence

The Dark Cloud Cover and the negative divergence were both signals drawing attention to the difficulty of continuing the market's advance.

## 4. Negative K% / D% Crossover

The following declining trend received confirmation through a negative crossover.

The crossover occurred when the faster K% line moved below the slower D% line.

## 5. Sequence of Evidence

The sequence described in the case was:

1. Dark Cloud Cover appeared.
2. Price reached a new high.
3. The Stochastic Oscillator failed to reach a new high.
4. Negative divergence appeared.
5. K% crossed below D%.
6. The subsequent declining trend received additional confirmation.

## 6. Key Structure

### Price
New High

### Candlestick
Dark Cloud Cover

### Stochastic Divergence
Negative Divergence

### Crossover
K% Crossed Below D%

### Combined Evidence
Dark Cloud Cover
+
Negative Stochastic Divergence
+
Negative K% / D% Crossover

### Result
Additional evidence supporting the subsequent declining trend.

## 7. Source Reference

- Exhibit: 14.6
- Market: S&P
- Contract: June 1990
- Timeframe: Daily
- Analysis: Stochastics with Candlesticks
- Candlestick Pattern: Dark Cloud Cover
- Stochastic Signal: Negative Divergence
- Crossover: K% Below D%