# Case 01 — Figure 14.4
## Dow Jones Industrial Average, 1989–1990
### Stochastics with Candlesticks

## 1. Case Overview

Figure 14.4 demonstrates the use of the Stochastic Oscillator together with Japanese candlesticks.

The case focuses on a Doji that appeared on January 3 and on the failure of the Stochastic Oscillator to confirm a new price high.

## 2. Candlestick Signal

A Doji appeared on January 3 after a long white candlestick.

The Doji reached a new price high above the highs recorded in December.

The text notes that a Doji appearing after a long white candlestick is not a favorable sign.

## 3. Stochastic Confirmation

Although price reached a new high, the Stochastic Oscillator did not rise along with the higher prices.

Therefore:

- Price → New High
- Stochastic → Failed to make a corresponding new high
- Result → Negative Stochastic Divergence

## 4. Combined Signal

Two bearish indications appeared together:

1. A Doji at a new price high.
2. Negative divergence in the Stochastic Oscillator.

The Stochastic divergence confirmed the negative signal provided by the Doji.

## 5. Interpretation

The failure of the Stochastic Oscillator to rise with the new price high indicated that the oscillator was not confirming the strength shown by price.

The negative divergence therefore added support to the bearish warning from the candlestick.

## 6. Key Structure

### Price
New Price High

### Candlestick
Doji

### Stochastic
Failed to Make a New High

### Result
Bearish / Negative Stochastic Divergence

### Combined Evidence
Doji + Negative Divergence

## 7. Source Reference

- Exhibit: 14.4
- Market: Dow Jones Industrial Average
- Period: 1989–1990
- Analysis: Stochastics with Candlesticks
- Candlestick Signal: Doji
- Stochastic Signal: Negative Divergence