# TC018 — Stochastic Case Studies

## Chapter

Chapter 14 — Candlesticks and Oscillators

## Subject

Stochastic Oscillator with Japanese Candlesticks.

## Purpose

This case-study collection records the examples presented in the source material showing how Stochastic Oscillator signals can complement Japanese candlestick analysis.

## Cases

### Case 01 — Figure 14.4
Dow Jones Industrial Average, 1989–1990

Key evidence:

- Doji
- New price high
- Stochastic failed to make a new high
- Negative divergence

---

### Case 02 — Figure 14.5
Copper — Weekly

Key evidence:

- Hammer formations
- Lower price low
- Higher Stochastic reading
- Positive divergence
- K% crossed above D%
- Oversold condition below 25%

The combination of these technical indications was described as strong enough to signal the end of the declining trend.

---

### Case 03 — Figure 14.6
S&P — June 1990, Daily

Key evidence:

- Dark Cloud Cover
- New price high
- Stochastic failed to make a new high
- Negative divergence
- K% crossed below D%

The declining trend received additional confirmation from the negative crossover.

---

### Case 04 — Figure 14.7
British Pound — June 1990, Daily

Key evidence:

- Imperfect Morning Star
- New price low
- Stochastic failed to make a new low
- Positive divergence
- K% crossed above D%

The Stochastic evidence supported the possibility of an approaching bottom despite the imperfection of the candlestick pattern.

## Main Lessons From the Cases

The examples demonstrate the use of:

- Positive divergence.
- Negative divergence.
- K% / D% crossovers.
- Overbought / oversold context.
- Japanese candlestick confirmation.
- Multiple technical indications occurring together.

The source material shows that candlestick signals can be evaluated together with Stochastic evidence rather than being considered in isolation.

## Source References

- Exhibit 14.4 — Dow Jones Industrial Average, 1989–1990
- Exhibit 14.5 — Copper, Weekly
- Exhibit 14.6 — S&P, June 1990, Daily
- Exhibit 14.7 — British Pound, June 1990, Daily