CREATE TABLE volume_basics (
    id INTEGER PRIMARY KEY,
    topic_code VARCHAR(20),
    concept_name VARCHAR(100),
    definition TEXT,
    bullish_interpretation TEXT,
    bearish_interpretation TEXT,
    confirmation_rule TEXT,
    limitation TEXT,
    source_reference TEXT
);

INSERT INTO volume_basics (
    topic_code,
    concept_name,
    definition,
    bullish_interpretation,
    bearish_interpretation,
    confirmation_rule,
    limitation,
    source_reference
)
VALUES
(
    'TC021',
    'Volume',
    'A measure of trading activity in the market.',
    'Increasing volume during rising prices can provide confirmation of upward movement.',
    'Increasing volume during falling prices can indicate stronger selling pressure.',
    'Volume should be interpreted together with price action and candlestick signals.',
    'Volume can be affected by market and contract characteristics.',
    'Chapter 15, Volume and Open Interest'
);