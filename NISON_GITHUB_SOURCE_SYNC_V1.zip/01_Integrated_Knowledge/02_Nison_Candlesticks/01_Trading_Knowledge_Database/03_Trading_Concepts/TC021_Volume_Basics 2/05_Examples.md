# Examples — Volume Basics

## Example 1 — Rising Price + Rising Volume

Price is moving upward and volume is increasing.

Interpretation:

The upward movement has stronger participation and therefore receives additional confirmation.

---

## Example 2 — Falling Price + Rising Volume

Price is declining while volume increases.

Interpretation:

Selling participation is increasing.

This supports the bearish interpretation.

---

## Example 3 — Rising Price + Weak Volume

Price reaches higher levels but volume does not increase.

Interpretation:

The advance should be treated with caution because the move is not receiving strong volume confirmation.

---

## Example 4 — Candlestick + Volume

A bullish candlestick pattern appears near support.

If volume also increases around the pattern, the candlestick signal receives additional supporting evidence.

The volume itself is not the entry signal.