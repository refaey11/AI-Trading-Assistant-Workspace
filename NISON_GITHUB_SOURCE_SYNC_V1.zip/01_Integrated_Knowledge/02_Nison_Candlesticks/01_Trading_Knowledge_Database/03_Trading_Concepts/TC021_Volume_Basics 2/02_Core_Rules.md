# Core Rules — Volume

## Rule 1 — Volume and Price

Increasing volume can strengthen the interpretation of a price movement.

## Rule 2 — Rising Market

If prices are rising and volume is also increasing, the upward movement has stronger confirmation.

## Rule 3 — Falling Market

If prices are falling and volume increases, this can indicate increasing selling pressure.

## Rule 4 — Weak Volume

A price movement occurring with weak or declining volume should be treated with more caution.

## Rule 5 — Volume Is Confirmation

Volume should generally be used together with price action rather than as a standalone trading signal.

## Rule 6 — Volume at Extremes

A price reaching a new high or low while volume behavior becomes weaker can provide information about the internal strength of the move.

## Rule 7 — Context Matters

Volume interpretation depends on the market environment, contract characteristics, and other factors.

The chapter specifically warns that volume numbers can sometimes be distorted by differences between futures contracts and markets.