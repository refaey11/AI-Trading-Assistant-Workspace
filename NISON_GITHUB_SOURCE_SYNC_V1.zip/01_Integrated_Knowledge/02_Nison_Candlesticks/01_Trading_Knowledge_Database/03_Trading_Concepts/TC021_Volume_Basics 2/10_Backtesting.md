# Backtesting — Volume Basics

## Objective

Test whether volume confirmation improves the reliability of candlestick and price-action signals.

## Basic Test

For each historical setup:

1. Identify the price movement.
2. Record volume behavior.
3. Identify any candlestick signal.
4. Classify volume as:
   - Increasing
   - Decreasing
   - Neutral
5. Record whether volume confirmed the price movement.
6. Record the trade outcome.

## Variables

- Market
- Timeframe
- Price direction
- Volume direction
- Candlestick pattern
- Entry
- Stop Loss
- Target
- Result

## Important

Do not assume that increasing volume automatically produces a profitable trade.

The purpose of the test is to determine whether volume confirmation adds statistical value to the trading setup.