# Confidence Model — Volume

Volume should increase confidence only when it supports the existing price-action interpretation.

## Suggested Evidence Structure

### Stronger Evidence

Price direction
+
Volume confirmation
+
Candlestick confirmation
+
Important support/resistance

### Moderate Evidence

Price direction
+
Volume confirmation

### Weak Evidence

Volume alone

## Principle

Volume should increase confidence in an existing setup rather than independently create the setup.

Example:

Bullish price action + bullish candlestick + increasing volume
= stronger confirmation.

Bullish volume alone
= insufficient evidence.