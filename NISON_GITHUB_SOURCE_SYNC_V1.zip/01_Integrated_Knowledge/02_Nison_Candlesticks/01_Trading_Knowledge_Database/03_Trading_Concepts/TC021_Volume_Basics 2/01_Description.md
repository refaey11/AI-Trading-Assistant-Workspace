# Volume Basics

## Definition

Volume is a measure of trading activity in the market.

The basic idea presented in the chapter is:

> When volume increases, the force behind a price movement may be increasing.

Volume can therefore be used as supporting evidence when analyzing price movement.

## Main Purpose

Volume can help the trader:

- Confirm the strength of a price trend.
- Evaluate whether buying or selling pressure is increasing.
- Identify possible weakness when price movement is not supported by volume.
- Support interpretations of candlestick signals.

## Important Principle

Increasing prices accompanied by increasing volume generally provide stronger confirmation of an upward move.

Decreasing prices accompanied by increasing volume can indicate stronger selling pressure.

## Important Limitation

Volume is useful, but it should not be treated as an independent signal.

The chapter emphasizes combining volume with price action and candlestick patterns.