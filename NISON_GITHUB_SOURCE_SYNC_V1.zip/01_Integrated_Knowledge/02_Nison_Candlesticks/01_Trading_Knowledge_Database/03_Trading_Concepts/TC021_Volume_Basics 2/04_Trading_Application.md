# Trading Application — Volume

## Using Volume to Confirm a Trend

When price moves upward while volume increases:

1. Identify the upward price movement.
2. Check whether volume is increasing.
3. If both move together, the price movement receives additional confirmation.

## Using Volume to Evaluate a Decline

When price moves downward while volume increases:

1. Identify the downward movement.
2. Check volume.
3. Increasing volume suggests stronger participation in the decline.
4. This can support the interpretation of increasing selling pressure.

## Using Volume with Candlesticks

Volume becomes more useful when combined with candlestick patterns.

Example:

A bullish candlestick pattern occurring at support is more meaningful if volume provides supporting evidence.

Likewise, a bearish candlestick pattern near resistance can receive additional confirmation from volume behavior.

## Do Not Trade Volume Alone

Volume should not automatically trigger a trade.

Use:

Price Action
+
Candlestick Pattern
+
Volume
+
Market Context