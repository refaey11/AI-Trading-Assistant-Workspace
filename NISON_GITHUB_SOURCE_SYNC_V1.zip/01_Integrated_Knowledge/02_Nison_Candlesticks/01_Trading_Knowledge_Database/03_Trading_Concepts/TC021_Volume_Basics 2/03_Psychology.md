# Psychology — Volume

Volume provides information about market participation.

When volume increases, more market activity is taking place.

This can help reveal whether traders are strongly participating in a price move or whether the move is occurring with relatively weak participation.

## Buying Pressure

Increasing volume during an advance can indicate stronger participation from buyers.

## Selling Pressure

Increasing volume during a decline can indicate stronger participation from sellers.

## Important Psychological Idea

Price alone shows what happened to the market.

Volume can provide additional information about the intensity of participation behind that movement.

Therefore:

Price + Volume > Price Alone

However, volume should still be interpreted within the broader market context.