# Volume Checklist

Before using volume as confirmation, check:

- [ ] What is the current price direction?
- [ ] Is volume increasing or decreasing?
- [ ] Does volume confirm the price movement?
- [ ] Is buying pressure increasing?
- [ ] Is selling pressure increasing?
- [ ] Is there a relevant candlestick pattern?
- [ ] Is the market trending or moving sideways?
- [ ] Is volume being used as confirmation rather than as a standalone signal?
- [ ] Are there market-specific factors that may affect volume?