# Case Study 01 — Figure 15.3

## Figure
Exhibit 15.3 — Silver-July 1990, Daily
OBV with Candlesticks

## Market
Silver — July 1990

## Timeframe
Daily

## Main Tools

- Japanese Candlesticks
- On-Balance Volume (OBV)

## Case Purpose

This case demonstrates the use of On-Balance Volume together with Japanese candlesticks.

## OBV Calculation Principle

When the current closing price is higher than the previous close:

- The day's volume is added to the cumulative OBV.

When the current closing price is lower than the previous close:

- The day's volume is subtracted from the cumulative OBV.

When prices are unchanged:

- The volume is ignored.

## Interpretation

OBV is used in relation to the dominant price trend.

When prices rise together with rising OBV, this provides a positive indication.

When prices fall together with falling OBV, the increase in volume supports continuation of the decline.

## Candlestick Relationship

The purpose of combining OBV with candlesticks is to use volume behavior as additional evidence alongside the candlestick signals.

The candlestick provides the price-action evidence, while OBV provides volume-related confirmation.

## Key Lesson

The case demonstrates the complementary use of:

Price
+
Japanese Candlesticks
+
On-Balance Volume

OBV should therefore be interpreted together with the price movement and candlestick evidence rather than in isolation.

## Source Reference

Chapter 15 — Volume and Open Interest

Exhibit 15.3 — Silver-July 1990, Daily (OBV with Candlesticks)