# TC025 — OBV Candlestick Case Study

## Case Included

### Case 01 — Figure 15.3

Market:
Silver — July 1990

Timeframe:
Daily

Indicator:
On-Balance Volume (OBV)

Complementary Analysis:
Japanese Candlesticks

## Main Lesson

The case demonstrates the use of OBV together with Japanese candlestick analysis.

## Source

Chapter 15 — Volume and Open Interest

Exhibit 15.3 — Silver-July 1990, Daily (OBV with Candlesticks)

## Source Rule

Only information supported by the supplied chapter is included in this case study.