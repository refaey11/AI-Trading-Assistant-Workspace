# Checklist

□ Trend identified

□ Multiple candlestick patterns

□ Same price area

□ Support or resistance

□ Confirmation candle

□ Volume confirmation

□ Risk defined

□ Stop Loss

□ Target

□ Confidence calculated