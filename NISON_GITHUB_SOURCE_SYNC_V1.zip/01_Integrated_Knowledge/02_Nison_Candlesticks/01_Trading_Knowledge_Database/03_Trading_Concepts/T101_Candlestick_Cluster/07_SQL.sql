CREATE TABLE candlestick_clusters (
    id INTEGER PRIMARY KEY,
    cluster_name TEXT,
    market_bias TEXT,
    number_of_patterns INTEGER,
    confirmation BOOLEAN,
    confidence REAL,
    notes TEXT
);