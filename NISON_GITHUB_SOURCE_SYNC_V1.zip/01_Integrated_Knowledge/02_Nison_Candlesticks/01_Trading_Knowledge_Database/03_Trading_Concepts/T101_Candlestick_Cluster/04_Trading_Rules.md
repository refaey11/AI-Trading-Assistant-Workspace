# Trading Rules

Bullish Cluster

Requirements:

- Multiple bullish patterns
- Same support area
- Bullish confirmation candle

Entry

After confirmation.

Stop Loss

Below the lowest bullish signal.

Target

Next resistance.

---

Bearish Cluster

Requirements

- Multiple bearish patterns
- Same resistance area
- Bearish confirmation

Entry

After confirmation.

Stop

Above cluster high.

Target

Nearest support.