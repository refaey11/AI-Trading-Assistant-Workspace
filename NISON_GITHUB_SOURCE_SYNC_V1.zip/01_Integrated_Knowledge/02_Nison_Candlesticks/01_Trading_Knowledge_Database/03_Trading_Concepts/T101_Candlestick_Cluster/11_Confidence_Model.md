# Confidence Model

Single Pattern
⭐⭐☆☆☆

Two Matching Patterns
⭐⭐⭐☆☆

Three Matching Patterns
⭐⭐⭐⭐☆

Four or More Patterns
⭐⭐⭐⭐⭐

Increase confidence further when:

- Trend agrees
- Support/Resistance agrees
- Volume confirms