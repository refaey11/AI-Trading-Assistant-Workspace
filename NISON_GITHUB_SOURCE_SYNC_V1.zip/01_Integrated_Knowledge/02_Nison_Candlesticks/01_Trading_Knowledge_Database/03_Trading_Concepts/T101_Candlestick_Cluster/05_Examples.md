# Examples

## Example 1

Hammer
+
Bullish Engulfing
+
Support

→ Strong Bullish Cluster

---

## Example 2

Hanging Man
+
Doji
+
Shooting Star

→ Strong Bearish Cluster

---

## Example 3

Morning Star
+
Bullish Window
+
Support Retest

→ Bullish Cluster

---

## Example 4

Evening Star
+
Dark Cloud Cover
+
Resistance

→ Bearish Cluster

---

## Example 5

Hammer
+
Bullish Engulfing
+
Tweezer Bottom

→ High Probability Reversal