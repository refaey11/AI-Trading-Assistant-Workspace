# Formation Rules

A valid Candlestick Cluster generally contains:

- Two or more candlestick patterns.
- Patterns appearing within the same price zone.
- Signals supporting the same market direction.
- Confirmation from price action.

Typical combinations include:

- Hammer + Bullish Engulfing
- Hanging Man + Doji
- Shooting Star + Harami
- Evening Star + Hanging Man
- Gravestone Doji + Dark Cloud Cover

Clusters may also include:

- Windows (Gaps)
- Support
- Resistance
- Previous swing highs/lows