# Common Mistakes

- Trading a single pattern.
- Ignoring nearby candlestick signals.
- Ignoring trend direction.
- Ignoring support/resistance.
- Trading before confirmation.
- Treating every pattern equally.
- Ignoring volume.
- Ignoring market context.