# Backtesting

Compare:

Single Pattern

vs

Candlestick Cluster

Measure:

- Win Rate
- Average RR
- Drawdown
- False Signals
- Profit Factor

Goal:

Determine whether clustered signals outperform isolated patterns.