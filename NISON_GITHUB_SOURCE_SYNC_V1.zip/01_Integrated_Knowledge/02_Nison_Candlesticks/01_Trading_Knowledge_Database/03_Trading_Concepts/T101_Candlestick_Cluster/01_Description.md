# Candlestick Cluster

A Candlestick Cluster occurs when several candlestick patterns or reversal signals appear within the same price area.

Instead of relying on a single pattern, traders evaluate multiple independent candlestick signals that all point toward the same market expectation.

The more signals that agree,
the stronger the probability of a reversal or continuation.

This concept is one of the strongest applications of Japanese candlestick analysis.