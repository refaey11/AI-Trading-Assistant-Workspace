# TC004 — Eight to Ten New Highs (or Lows)

## Core Rules

- Count consecutive new highs or new lows.
- The sequence should occur without a meaningful correction.
- After eight to ten consecutive records, expect an increased probability of correction.
- This concept is a warning, not an automatic reversal signal.

## Source

Steve Nison — Chapter 7