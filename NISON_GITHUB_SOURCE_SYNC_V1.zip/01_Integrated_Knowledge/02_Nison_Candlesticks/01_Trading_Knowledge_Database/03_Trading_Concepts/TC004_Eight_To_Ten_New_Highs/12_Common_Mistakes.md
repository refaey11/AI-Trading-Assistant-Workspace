# TC004 — Eight to Ten New Highs (or Lows)

## Common Mistakes

### 1. Treating Eight Highs as a Sell Signal

The concept only warns of increased correction probability.

### 2. Ignoring Market Context

Always evaluate the count within the broader market structure.

### 3. Ignoring Additional Confirmation

The count should be combined with other technical evidence before making a decision.

## Source

Steve Nison — Chapter 7