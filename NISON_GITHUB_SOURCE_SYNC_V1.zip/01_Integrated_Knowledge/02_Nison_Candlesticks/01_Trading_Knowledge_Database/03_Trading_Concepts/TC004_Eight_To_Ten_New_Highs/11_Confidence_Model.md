# TC004 — Eight to Ten New Highs (or Lows)

## Confirmation

The concept gains importance when combined with:

- Resistance.
- Windows.
- Reversal candlestick patterns.

The count alone is not sufficient.

## Source

Steve Nison — Chapter 7