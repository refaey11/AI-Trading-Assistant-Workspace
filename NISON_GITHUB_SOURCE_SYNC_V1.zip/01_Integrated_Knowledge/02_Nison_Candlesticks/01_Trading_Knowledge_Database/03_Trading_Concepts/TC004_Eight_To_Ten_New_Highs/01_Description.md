# TC004 — Eight to Ten New Highs (or Lows)

## Source
Steve Nison — Japanese Candlestick Charting Techniques

## Chapter
Chapter 7 — Continuation Patterns

## Category
Trading Concept

## Description

Japanese technical analysis states that after eight to ten consecutive new highs or eight to ten consecutive new lows without a meaningful correction, the probability of a significant correction increases.

Japanese traders refer to each new high as a "new record high" and each new low as a "new record low."

When approximately eight consecutive new highs have appeared, Japanese traders describe the market as being "80% full."

This concept serves as a warning that the current trend may be approaching exhaustion.

## Source Reference

Steve Nison — Chapter 7