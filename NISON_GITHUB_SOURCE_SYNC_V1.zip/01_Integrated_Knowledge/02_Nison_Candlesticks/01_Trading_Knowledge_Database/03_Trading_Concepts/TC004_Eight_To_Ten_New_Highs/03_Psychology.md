# TC004 — Eight to Ten New Highs (or Lows)

## Psychology

Repeated new highs indicate strong buying pressure.

However, after many consecutive advances without meaningful correction, the market may become vulnerable to profit-taking.

The concept reflects increasing exhaustion rather than an immediate reversal.

## Source

Steve Nison — Chapter 7