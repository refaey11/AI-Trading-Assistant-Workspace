# TC004 — Eight to Ten New Highs (or Lows)

## Trading Application

Monitor markets making consecutive new highs or lows.

When the count approaches eight to ten:

- Increase caution.
- Watch for additional warning signals.
- Look for resistance, reversal candles, or other confirming evidence.

Do not assume an automatic reversal.

## Source

Steve Nison — Chapter 7