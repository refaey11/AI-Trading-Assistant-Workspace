# TC004 — Eight to Ten New Highs (or Lows)

## Backtesting

Record:

- Number of consecutive highs/lows.
- Presence of correction.
- Reversal afterwards (Yes/No).

Compare outcomes before and after eight consecutive records.

## Source

Steve Nison — Chapter 7