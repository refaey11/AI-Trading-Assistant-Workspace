CREATE TABLE trading_concept_exhaustion (

    concept_id VARCHAR(20) PRIMARY KEY,
    concept_name VARCHAR(100),
    source VARCHAR(100),
    chapter VARCHAR(100),
    description TEXT,
    rules TEXT

);

INSERT INTO trading_concept_exhaustion
VALUES(

'TC004',

'Eight to Ten New Highs or Lows',

'Steve Nison',

'Chapter 7',

'Correction probability increases after eight to ten consecutive new highs or lows.',

'Count consecutive records without meaningful correction.'

);