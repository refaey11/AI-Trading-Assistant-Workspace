# TC004 — Eight to Ten New Highs (or Lows)

## Example

In the gold market example presented by Steve Nison:

- Eight consecutive new highs developed.
- Price simultaneously reached resistance created by a previous Window.
- The combination increased the warning that the market was approaching an important top.

## Source

Steve Nison — Chapter 7