# TC004 — Eight to Ten New Highs (or Lows)

## Checklist

- [ ] Count consecutive new highs/lows.
- [ ] Confirm there has been no meaningful correction.
- [ ] Count ≥ 8?
- [ ] Look for additional warning signals.
- [ ] Avoid assuming automatic reversal.

## Source

Steve Nison — Chapter 7