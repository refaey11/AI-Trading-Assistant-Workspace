CREATE TABLE dual_moving_average_system (

id INTEGER PRIMARY KEY,

concept_code TEXT,

fast_ma INTEGER,

slow_ma INTEGER,

cross_type TEXT,

trend TEXT,

candlestick_confirmation TEXT,

entry_rule TEXT,

stop_loss_rule TEXT,

target_rule TEXT,

confidence TEXT,

notes TEXT

);