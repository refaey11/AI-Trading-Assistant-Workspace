# TC011 - Confidence Model

Trend Alignment +20

Golden/Death Cross +20

Candlestick Confirmation +20

Support/Resistance +15

Volume Confirmation +15

Risk/Reward +10

90–100 = Very High

70–89 = High

50–69 = Moderate

Below 50 = Avoid