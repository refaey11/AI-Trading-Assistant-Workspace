# TC011 - Market Psychology

The crossover represents a shift in market control.

Golden Cross

Short-term buyers become stronger than long-term sellers.

Momentum shifts upward.

Institutions begin accumulating.

---

Death Cross

Short-term sellers dominate.

Momentum shifts downward.

Institutions begin distributing.

---

False Crossovers

Sideways markets produce many false signals because buyers and sellers remain balanced.

Professionals wait for confirmation before acting.

---

Professional View

The crossover reflects a change in crowd behavior—not merely two lines crossing.