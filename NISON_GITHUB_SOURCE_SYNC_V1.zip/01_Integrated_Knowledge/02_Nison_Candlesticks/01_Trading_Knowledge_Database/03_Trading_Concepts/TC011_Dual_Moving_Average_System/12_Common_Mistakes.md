# TC011 - Common Mistakes

- Trading every crossover.

- Ignoring market structure.

- Ignoring candlestick confirmation.

- Using only one timeframe.

- Trading sideways markets.

- Entering before candle closes.

- Ignoring Stop Loss.

Professional Rule

Golden Cross and Death Cross are confirmation tools—not standalone trading systems.