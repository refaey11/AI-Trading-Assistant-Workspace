# TC011 - Dual Moving Average System

## Name

Dual Moving Average System

---

## Category

Trend Following

Trend Confirmation

Moving Average Strategy

---

## Source

Steve Nison

Beyond Candlesticks

Chapter 13

---

## Definition

The Dual Moving Average System uses two Moving Averages with different periods to identify changes in market trend.

The relationship between the short-term Moving Average and the long-term Moving Average provides objective buy and sell signals.

---

## Objective

- Confirm trend changes.
- Filter market noise.
- Generate systematic entry and exit signals.
- Improve trend-following decisions.

---

## Key Signals

### Golden Cross

The short-term Moving Average crosses above the long-term Moving Average.

Bullish signal.

---

### Death Cross

The short-term Moving Average crosses below the long-term Moving Average.

Bearish signal.

---

## Professional Principle

The crossover itself is not enough.

The strongest signals occur when:

- Market Structure
- Moving Average Crossover
- Candlestick Confirmation

all agree.