# TC011 - Trading Application

Bullish Workflow

Identify Uptrend

↓

Golden Cross

↓

Bullish Candlestick

↓

Entry

↓

Stop Loss below support

↓

Trend Management

---

Bearish Workflow

Identify Downtrend

↓

Death Cross

↓

Bearish Candlestick

↓

Entry

↓

Stop Loss above resistance

↓

Trend Management

---

Best Practice

Never trade the crossover alone.

Always require price action confirmation.