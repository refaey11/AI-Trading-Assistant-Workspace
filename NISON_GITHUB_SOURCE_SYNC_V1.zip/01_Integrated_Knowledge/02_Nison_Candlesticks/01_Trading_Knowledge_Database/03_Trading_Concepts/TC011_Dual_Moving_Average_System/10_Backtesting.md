# TC011 - Backtesting

Record

- Date
- Asset
- Fast MA
- Slow MA
- Cross Type
- Trend
- Confirmation
- Entry
- Exit
- Result
- R Multiple

Metrics

- Win Rate
- Profit Factor
- Drawdown
- Expectancy