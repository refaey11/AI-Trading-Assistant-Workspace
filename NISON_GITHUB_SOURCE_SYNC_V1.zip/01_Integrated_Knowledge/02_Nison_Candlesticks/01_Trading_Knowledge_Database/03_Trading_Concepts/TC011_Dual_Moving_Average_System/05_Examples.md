# TC011 - Examples

Example 1

Golden Cross

Fast EMA 12 crosses above EMA 26.

Bullish Engulfing appears.

Buy Signal confirmed.

---

Example 2

Death Cross

EMA 12 crosses below EMA 26.

Dark Cloud Cover forms.

Bearish continuation confirmed.

---

Example 3

False Golden Cross

Golden Cross appears during a sideways market.

Price quickly reverses.

False Signal.

Lesson:

Avoid range-bound markets.