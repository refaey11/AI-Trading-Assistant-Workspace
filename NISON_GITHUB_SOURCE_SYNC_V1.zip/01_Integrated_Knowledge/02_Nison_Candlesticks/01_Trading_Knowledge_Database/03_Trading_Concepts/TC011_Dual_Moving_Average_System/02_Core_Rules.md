# TC011 - Core Rules

## Rule 1

Golden Cross indicates bullish momentum.

---

## Rule 2

Death Cross indicates bearish momentum.

---

## Rule 3

Higher timeframe trend should agree with the crossover.

---

## Rule 4

Ignore crossovers occurring during sideways markets.

---

## Rule 5

Candlestick confirmation strengthens every crossover.

---

## Rule 6

The larger the distance between both Moving Averages after crossing,

the stronger the trend.

---

## Rule 7

Crossovers should never be traded in isolation.

Always combine with:

- Support / Resistance
- Candlestick Patterns
- Market Structure