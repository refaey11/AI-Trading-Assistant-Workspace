# TC011 - Checklist

□ Trend identified

□ Fast MA identified

□ Slow MA identified

□ Golden / Death Cross confirmed

□ Candlestick confirmation

□ Support / Resistance checked

□ Risk / Reward acceptable

□ Stop Loss defined

□ Trade documented