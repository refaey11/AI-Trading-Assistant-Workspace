-- TC029 — Elliott Wave Theory
-- Source: Steve Nison — Japanese Candlestick Charting Techniques
-- Chapter 16

CREATE TABLE IF NOT EXISTS elliott_wave_structure (
    id INTEGER PRIMARY KEY,
    wave_name VARCHAR(20) NOT NULL,
    wave_type VARCHAR(30) NOT NULL,
    sequence_order INTEGER NOT NULL
);

INSERT INTO elliott_wave_structure
(wave_name, wave_type, sequence_order)
VALUES
('Wave 1', 'Impulse', 1),
('Wave 2', 'Corrective', 2),
('Wave 3', 'Impulse', 3),
('Wave 4', 'Corrective', 4),
('Wave 5', 'Impulse', 5),
('Wave A', 'Corrective', 6),
('Wave B', 'Corrective', 7),
('Wave C', 'Corrective', 8);


CREATE TABLE IF NOT EXISTS elliott_wave_confirmation (
    id INTEGER PRIMARY KEY,
    confirmation_type VARCHAR(50) NOT NULL,
    description TEXT
);

INSERT INTO elliott_wave_confirmation
(confirmation_type, description)
VALUES
('Candlestick', 'Japanese candlestick patterns used as supporting evidence near potential wave turning points.'),
('Fibonacci', 'Fibonacci relationships used to estimate potential wave targets.'),
('Volume', 'Trading volume used as additional market information in the chapter examples.'),
('Open Interest', 'Open interest used as additional information about market participation.');


CREATE TABLE IF NOT EXISTS elliott_wave_examples (
    id INTEGER PRIMARY KEY,
    example_name VARCHAR(100) NOT NULL,
    description TEXT
);

INSERT INTO elliott_wave_examples
(example_name, description)
VALUES
('Crude Oil', 'Historical chart example involving Elliott Wave structure and candlestick analysis.'),
('Wave 4', 'Example involving a corrective Wave 4 and Fibonacci analysis.'),
('Wave 5', 'Example involving a Fibonacci projection for a potential Wave 5 target.'),
('Five-Wave Decline', 'Example demonstrating a five-wave declining structure.');


CREATE TABLE IF NOT EXISTS elliott_wave_fibonacci (
    id INTEGER PRIMARY KEY,
    wave_name VARCHAR(20),
    relationship VARCHAR(100),
    target_value DECIMAL(10,2)
);

INSERT INTO elliott_wave_fibonacci
(wave_name, relationship, target_value)
VALUES
('Wave 5', '161.8% relationship using Wave 3', 88.08);