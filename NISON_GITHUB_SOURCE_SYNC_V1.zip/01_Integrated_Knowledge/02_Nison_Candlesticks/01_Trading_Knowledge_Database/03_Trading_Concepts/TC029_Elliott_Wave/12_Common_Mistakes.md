# Elliott Wave Theory — Common Mistakes

## 1. Relying Only on the Wave Count

Elliott Wave analysis should not automatically be treated as sufficient evidence by itself.

The chapter demonstrates combining Elliott Wave analysis with other technical information.

---

## 2. Ignoring Candlestick Evidence

Potential wave termination areas should be examined for relevant Japanese candlestick patterns.

Ignoring this evidence can remove an important part of the approach demonstrated in the chapter.

---

## 3. Ignoring Fibonacci Relationships

Fibonacci relationships are used in the chapter to estimate potential wave targets.

They should be considered when the required price information is available.

---

## 4. Ignoring Open Interest

Open interest can provide additional information about market participation.

When available, it should be considered together with price movement.

---

## 5. Ignoring Volume

Trading volume is included in the chapter examples as additional market information.

When available, it can be considered alongside the wave structure and candlestick evidence.

---

## 6. Treating a Wave Count as Certain

Elliott Wave interpretation involves identifying a possible structure.

If the chart does not provide enough evidence, the interpretation should remain uncertain.

---

## 7. Inventing Missing Information

Do not invent:

- Wave counts
- Prices
- Fibonacci relationships
- Targets
- Volume information
- Open-interest information

when the required evidence is unavailable.

---

## 8. Treating a Fibonacci Target as Guaranteed

A Fibonacci projection is an estimated target.

It should not be treated as a guaranteed price level.

---

## 9. Treating Historical Examples as Guaranteed Results

The historical examples in the chapter demonstrate applications of Elliott Wave analysis.

They do not establish that the same result will occur every time.

---

## 10. Adding Unsupported Trading Rules

Chapter 16 does not establish:

- A fixed entry rule
- A fixed stop-loss
- A fixed take-profit
- A guaranteed win rate
- A guaranteed probability of success

These should not be attributed to the chapter.

---

## Final Principle

The approach demonstrated in the chapter is based on combining multiple forms of evidence rather than relying on Elliott Wave counting alone.