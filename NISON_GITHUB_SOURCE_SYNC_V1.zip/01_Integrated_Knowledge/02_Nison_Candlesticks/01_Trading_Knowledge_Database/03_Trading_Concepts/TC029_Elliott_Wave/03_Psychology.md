# Elliott Wave Theory — Psychology

## Market Psychology

Chapter 16 does not present a separate psychological trading model.

The psychological ideas are mainly shown through market participation, price movement, candlestick behavior, and open interest.

## Market Participation

Open interest is used in the chapter to provide information about participation in the market.

Changes in open interest can help the analyst understand whether additional traders are participating in a price movement.

## Buying and Selling Pressure

Candlestick patterns are used to observe potential changes in the balance between buyers and sellers.

When a reversal-type candlestick appears near an expected Elliott Wave termination point, it may provide supporting evidence that the market is changing direction.

## Wave Termination

The chapter demonstrates that traders can use Elliott Wave structure together with candlestick patterns to examine areas where a wave may be ending.

The psychological interpretation comes from observing price behavior and the evidence provided by the market.

## Important Limitation

Chapter 16 does not provide a standalone psychological model or specific rules for trader psychology.

Therefore, no additional psychological rules should be attributed to the chapter.