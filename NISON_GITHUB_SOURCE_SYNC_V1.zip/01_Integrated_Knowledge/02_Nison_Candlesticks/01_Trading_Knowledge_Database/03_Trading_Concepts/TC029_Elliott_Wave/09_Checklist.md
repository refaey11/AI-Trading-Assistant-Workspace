# Elliott Wave Theory — Checklist

## Wave Structure

- [ ] Identify the overall market direction.
- [ ] Identify Wave 1.
- [ ] Identify Wave 2.
- [ ] Identify Wave 3.
- [ ] Identify Wave 4.
- [ ] Identify Wave 5.
- [ ] Identify Wave A.
- [ ] Identify Wave B.
- [ ] Identify Wave C.

## Wave Analysis

- [ ] Identify the possible current wave.
- [ ] Identify potential wave termination.
- [ ] Check for smaller wave subdivisions.
- [ ] Record uncertainty when the wave count is unclear.

## Candlestick Confirmation

- [ ] Check for Hammer.
- [ ] Check for Harami.
- [ ] Check for Dark Cloud Cover.
- [ ] Check for Piercing Line.
- [ ] Check for Shooting Star.
- [ ] Check for Morning Star.
- [ ] Check for Doji.
- [ ] Check for Tweezers Top.

## Fibonacci

- [ ] Check whether a Fibonacci relationship can be applied.
- [ ] Record the input wave.
- [ ] Record the Fibonacci relationship.
- [ ] Calculate the projected target.
- [ ] Compare the projected target with price behavior.

## Volume

- [ ] Check volume when available.
- [ ] Record relevant volume behavior.
- [ ] Determine whether volume provides supporting evidence.

## Open Interest

- [ ] Check open interest when available.
- [ ] Record whether open interest is increasing or decreasing.
- [ ] Compare open-interest changes with price movement.
- [ ] Determine whether open interest provides supporting evidence.

## Final Review

- [ ] Wave structure is documented.
- [ ] Potential termination area is documented.
- [ ] Candlestick evidence is documented.
- [ ] Fibonacci evidence is documented.
- [ ] Volume is documented when available.
- [ ] Open interest is documented when available.
- [ ] Conflicting evidence is documented.
- [ ] No unsupported rule has been added.
- [ ] No guaranteed outcome is claimed.