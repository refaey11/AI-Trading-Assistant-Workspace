# Elliott Wave Theory — Core Rules

## 1. Five-Wave Impulse Structure

The basic Elliott Wave pattern consists of five advancing waves:

- Wave 1
- Wave 2
- Wave 3
- Wave 4
- Wave 5

Waves 1, 3, and 5 are impulse waves.

Waves 2 and 4 are corrective waves.

## 2. Three-Wave Correction

After the five-wave advancing sequence, the market can form a corrective sequence consisting of:

- Wave A
- Wave B
- Wave C

This creates the basic 5-wave advance followed by a 3-wave correction.

## 3. Wave Subdivision

Elliott Waves can be subdivided into smaller waves.

A larger wave may therefore contain smaller wave structures. This allows the analyst to study market movement at different degrees.

## 4. Wave 3

The chapter describes Wave 3 as commonly being the strongest wave among the impulse waves.

Wave 3 can also be subdivided into smaller waves.

## 5. Wave 4

Wave 4 is a corrective wave.

The chapter provides examples of using Fibonacci relationships to estimate potential Wave 4 targets.

## 6. Wave 5

Wave 5 is the final impulse wave of the five-wave advancing sequence.

The chapter demonstrates an example of estimating a Wave 5 target using a Fibonacci relationship with Wave 3.

## 7. Candlestick Confirmation

Elliott Wave counts should not be considered in isolation.

Japanese candlestick patterns can provide confirmation near important wave turning points.

Examples shown in the chapter include:

- Harami
- Dark Cloud Cover
- Piercing Line
- Shooting Star
- Morning Star
- Hammer
- Doji
- Tweezers Top

## 8. Fibonacci Relationships

Fibonacci relationships can be used to estimate potential wave targets.

The chapter gives examples where the price range of one wave is multiplied by a Fibonacci percentage and then applied to another wave point to estimate a target.

## 9. Open Interest

Open interest can be considered together with Elliott Wave analysis.

Changes in open interest can provide additional information about market participation and the behavior of a price move.

## 10. Combined Analysis

The chapter demonstrates the combination of:

Elliott Wave Structure  
+ Candlestick Confirmation  
+ Fibonacci Relationships  
+ Open Interest

The purpose is to improve the interpretation of potential wave turning points and targets.

## Source

Steve Nison — Japanese Candlestick Charting Techniques, Chapter 16.