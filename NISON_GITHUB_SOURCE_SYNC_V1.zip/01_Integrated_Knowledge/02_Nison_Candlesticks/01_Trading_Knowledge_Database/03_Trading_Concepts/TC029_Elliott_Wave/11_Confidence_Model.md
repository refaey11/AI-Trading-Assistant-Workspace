# Elliott Wave Theory — Confidence Model

## Purpose

This model is used to organize the evidence supporting or contradicting an Elliott Wave interpretation.

It is not a statistical probability model.

---

## 1. Elliott Wave Structure

### Strong
The wave structure is clearly identifiable and supported by the price movement.

### Moderate
A reasonable wave structure can be identified, but some uncertainty remains.

### Weak
The proposed wave count has limited supporting evidence.

### Unclear
There is insufficient information to identify the wave structure reliably.

---

## 2. Candlestick Evidence

### Strong
A relevant candlestick pattern appears near the potential wave termination and supports the interpretation.

### Moderate
Candlestick evidence provides some support but is not decisive.

### Weak
The candlestick evidence is limited or unclear.

### None
No relevant candlestick confirmation is available.

---

## 3. Fibonacci Evidence

### Strong
A Fibonacci relationship provides a clear supporting target.

### Moderate
A Fibonacci relationship provides additional but incomplete support.

### Weak
The Fibonacci relationship is uncertain or provides limited support.

### None
No applicable Fibonacci relationship is available.

---

## 4. Volume Evidence

### Strong
Volume provides clear additional supporting information.

### Moderate
Volume provides some supporting information.

### Weak
Volume provides limited information.

### None
Volume is unavailable or not informative.

---

## 5. Open Interest Evidence

### Strong
Open interest provides clear supporting information about market participation.

### Moderate
Open interest provides some additional context.

### Weak
Open interest provides limited information.

### None
Open interest is unavailable.

---

## Overall Assessment

The analyst should combine the available evidence:

**Elliott Wave Structure**
+
**Candlestick Evidence**
+
**Fibonacci Evidence**
+
**Volume**
+
**Open Interest**

The final assessment should be:

- Strong Support
- Moderate Support
- Weak Support
- Unclear
- Conflicting Evidence

---

## Important Rule

Do not convert this assessment into an unsupported numerical probability.

The chapter does not establish a fixed percentage for Elliott Wave success.

Confidence should reflect the quality and consistency of the available evidence.