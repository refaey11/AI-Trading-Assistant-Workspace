# Elliott Wave Theory — Description

## Definition

Elliott Wave Theory is a framework for analyzing market price movements through recurring wave structures.

The theory identifies a repeating sequence of advancing and corrective waves that can be used to interpret market behavior.

## Core Structure

A complete Elliott Wave cycle consists of:

- Five-wave impulse sequence:
  - Wave 1
  - Wave 2
  - Wave 3
  - Wave 4
  - Wave 5

- Three-wave corrective sequence:
  - Wave A
  - Wave B
  - Wave C

Waves 1, 3, and 5 are impulse waves, while Waves 2 and 4 are corrective waves within the advancing sequence.

## Candlestick Confirmation

Elliott Wave analysis can be combined with Japanese candlestick analysis.

Candlestick patterns may provide confirmation at important Elliott Wave turning points.

Examples discussed in the chapter include:

- Hammer
- Harami
- Dark Cloud Cover
- Piercing Line
- Shooting Star
- Morning Star
- Doji
- Tweezers Top

## Fibonacci Relationships

Fibonacci relationships can be used to estimate potential wave targets.

The chapter demonstrates examples of calculating wave targets using Fibonacci relationships between different Elliott Waves.

## Open Interest

Open interest can be analyzed together with Elliott Wave structure.

Changes in open interest may provide additional information about participation and the strength or weakness of a market movement.

## Main Concept

The chapter presents Elliott Wave analysis as a combined framework:

Elliott Wave Structure + Candlestick Confirmation + Fibonacci Relationships + Open Interest

These tools are used together to interpret potential turning points and estimate wave targets.

## Source

Steve Nison — Japanese Candlestick Charting Techniques, Chapter 16.