# Elliott Wave Theory — Examples

## Example 1 — Crude Oil

Chapter 16 demonstrates Elliott Wave analysis using an intraday crude-oil chart.

The chart is analyzed by identifying Elliott Wave structure and examining Japanese candlestick patterns around potential wave termination points.

The example demonstrates how smaller waves can be identified within a larger wave structure.

## Example 2 — Wave 4

The chapter presents an example involving the corrective Wave 4.

A Fibonacci relationship is used to estimate a potential Wave 4 target.

Candlestick behavior near the expected termination area is then examined as supporting evidence.

## Example 3 — Wave 5

The chapter provides an example of calculating a potential Wave 5 target using a Fibonacci relationship with Wave 3.

The example produces a target of approximately 88.08.

The projected target is then considered together with other technical evidence.

## Example 4 — Five-Wave Decline

The chapter also presents an example of five declining waves.

The wave structure is examined together with candlestick formations around important wave points.

## Example 5 — Open Interest

The chapter discusses examples where open interest is examined together with price movement.

Changes in open interest are used as additional information about market participation.

## Main Lesson

The examples demonstrate that Elliott Wave analysis can be combined with:

- Japanese candlesticks
- Fibonacci relationships
- Trading volume
- Open interest

to provide additional evidence when interpreting potential wave turning points.