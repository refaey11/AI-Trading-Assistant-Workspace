# Open Interest — Backtesting

## Source Limitation

The supplied chapter does not provide a formal statistical backtesting methodology for open interest.

It does not specify:

- A fixed entry rule.
- A fixed stop-loss rule.
- A fixed target.
- A required sample size.
- A win-rate threshold.
- A statistical confidence requirement.

## Source-Based Observations

Historical observations can be organized according to the relationships described in the chapter:

- Rising price + rising open interest.
- Falling price + rising open interest.
- Rising price + falling open interest.
- Falling price + falling open interest.
- Unusually high open interest + new price extremes.

## Important

These observations should not be converted into performance claims unless they are separately tested.

No backtesting result is attributed to the book.