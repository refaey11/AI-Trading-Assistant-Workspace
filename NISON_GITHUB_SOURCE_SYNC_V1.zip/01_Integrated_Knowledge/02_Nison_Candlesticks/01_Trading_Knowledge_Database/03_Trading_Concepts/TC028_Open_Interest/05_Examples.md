# Open Interest — Examples From the Chapter

## Example 1 — Bonds

A secondary rise in bonds began on March 13 and continued until March 22.

The book explains that short covering caused the advance.

The rise stopped when the short-covering activity ended.

A Rickshaw Man appeared at the top area and warned of a possible decline.

Later, open interest began increasing while the market declined from April 9.

The increasing open interest indicated that both buyers and short sellers were entering, but the bears were dominant.

When Doji candles appeared on April 27 and May 2, open interest began declining.

This reflected weakening pressure from the bears.

## Example 2 — Bonds in May and June

Increasing prices together with increasing open interest during May provided evidence of a healthy market.

In June, prices rose while open interest declined.

The book interpreted the large June rise as short covering rather than a healthy continuation of the trend.

A Shooting Star announced a top, followed by a sharp decline.

## Example 3 — Cotton

The chapter discusses unusually high open interest together with new price highs.

The increase in open interest meant that new traders were entering the market.

The book warns that such a situation can create difficulties if prices suddenly reverse.

## Example 4 — Sugar

Sugar traded within a range for approximately two months.

Open interest increased significantly during the advance beginning in late April and reached unusually high levels near the end of May.

New buyers entered during the rise.

These buyers placed sell-stop orders to protect their gains.

When the market reversed sharply, the resulting stop orders contributed to a rapid decline.

## Source

Chapter 15 — Volume and Open Interest.