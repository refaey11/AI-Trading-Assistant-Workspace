# Open Interest — Checklist

## Price

- [ ] Is price rising?
- [ ] Is price falling?
- [ ] Has price reached a new extreme?

## Open Interest

- [ ] Is open interest increasing?
- [ ] Is open interest decreasing?
- [ ] Is open interest unusually high?

## Relationship

- [ ] Rising price + rising open interest?
- [ ] Falling price + rising open interest?
- [ ] Rising price + falling open interest?
- [ ] Falling price + falling open interest?

## Candlesticks

- [ ] Is there a Doji?
- [ ] Is there a Rickshaw Man?
- [ ] Is there a Shooting Star?
- [ ] Is there another relevant candlestick signal?

## Interpretation

- [ ] Is the trend receiving open-interest confirmation?
- [ ] Could the price rise be related to short covering?
- [ ] Are traders leaving positions?
- [ ] Is unusually high open interest occurring near a new price extreme?

## Final Check

- [ ] Price has been considered.
- [ ] Open interest has been considered.
- [ ] Candlesticks have been considered.
- [ ] No unsupported trading rule has been added.