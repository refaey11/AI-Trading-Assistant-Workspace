# Open Interest — Confidence Model

## Source Limitation

The book does not provide a numerical confidence model for open interest.

It does not assign percentages or numerical scores to the different relationships.

## Source-Based Evidence

The chapter provides qualitative interpretations:

### Rising Price + Rising Open Interest

Positive confirmation of the rising trend.

### Falling Price + Rising Open Interest

Evidence that new participants are entering while the bears may have the upper hand.

### Rising Price + Falling Open Interest

Warning that the advance may be driven by short covering and liquidation.

### Falling Price + Falling Open Interest

Warning that traders are leaving positions and the trend may lose its driving force.

## Important

No numerical confidence score should be presented as a rule from the book.