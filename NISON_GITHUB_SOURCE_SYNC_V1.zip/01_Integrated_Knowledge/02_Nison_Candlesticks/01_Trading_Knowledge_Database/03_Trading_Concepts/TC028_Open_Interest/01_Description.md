# Open Interest — Description

## Definition

Open Interest refers to contracts that remain open in the futures market.

An increase in open interest means that new participants are entering the market, either as buyers or as short sellers.

## Open Interest and Market Movement

Open interest is used together with price movement to help evaluate the strength or weakness of a market trend.

The book emphasizes the importance of increasing open interest in confirming the direction of a trend.

## Increasing Open Interest

When open interest increases during a rising market, new buyers and new short sellers are entering the market.

In a rising trend, the book states that the bulls are in control and the advance should continue.

When open interest increases during a declining market, both buyers and short sellers are entering, but the bears may have the upper hand.

## Decreasing Open Interest

When open interest decreases during either a rising or falling market, it can indicate that the existing trend may not continue.

The reason given is that traders holding positions are leaving the market.

## Open Interest and Short Covering

If prices rise while open interest declines, the advance may be caused by short covering and liquidation of old long positions.

The book warns that such an advance is not necessarily a healthy sign for continued strength.

## Source

Chapter 15 — Volume and Open Interest