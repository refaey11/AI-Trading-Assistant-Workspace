# Open Interest — Psychology

## New Market Participants

Increasing open interest means that new traders are entering the market.

They may enter as:

- Buyers
- Short sellers

## Declining Open Interest

Declining open interest means that traders holding positions are leaving the market.

According to the book, when these traders leave their old positions, the force available to move the market can begin to disappear.

## Short Covering

When prices rise while open interest declines, buying may be coming from short sellers covering their positions.

The book explains that once these buyers leave the market, the market may become vulnerable to further weakness.

## Long Position Liquidation

A decline in open interest can also reflect the liquidation of old long positions.

## The Water-Hose Analogy

The book compares increasing open interest with a continuing supply of water entering a hose.

As long as the source remains open, the flow continues.

Declining open interest is compared with closing the tap.

The remaining flow can continue temporarily, but without a new source the flow eventually stops.

The market trend is compared with this flow.