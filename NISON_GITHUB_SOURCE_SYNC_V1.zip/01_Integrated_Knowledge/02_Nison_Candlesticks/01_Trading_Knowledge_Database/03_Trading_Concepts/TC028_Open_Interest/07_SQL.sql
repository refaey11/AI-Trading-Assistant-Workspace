CREATE TABLE open_interest_rules (
    id INTEGER PRIMARY KEY,
    topic_code VARCHAR(20),
    price_direction VARCHAR(30),
    open_interest_direction VARCHAR(30),
    interpretation TEXT,
    source_reference TEXT
);

INSERT INTO open_interest_rules
(
    id,
    topic_code,
    price_direction,
    open_interest_direction,
    interpretation,
    source_reference
)
VALUES
(
    1,
    'TC028',
    'Rising',
    'Rising',
    'Increasing open interest confirms the rising trend; bulls are described as being in control.',
    'Chapter 15'
),
(
    2,
    'TC028',
    'Falling',
    'Rising',
    'New participants are entering while prices decline; the bears may have the upper hand.',
    'Chapter 15'
),
(
    3,
    'TC028',
    'Rising',
    'Falling',
    'The rise may be caused by short covering and liquidation of old long positions.',
    'Chapter 15'
),
(
    4,
    'TC028',
    'Falling',
    'Falling',
    'Traders are leaving positions and the trend may not continue.',
    'Chapter 15'
);