# Open Interest — Core Rules

## Rule 1 — Rising Market + Rising Open Interest

Increasing open interest during a rising market is presented as confirmation of the upward trend.

The book states that the bulls are in control and the advance should continue.

## Rule 2 — Falling Market + Rising Open Interest

Increasing open interest during a decline means that new participants are entering the market.

The book explains that the bears may have the upper hand during such a decline.

## Rule 3 — Rising Market + Falling Open Interest

A rising market accompanied by declining open interest is a warning.

The advance may be caused by short covering and liquidation of old long positions.

## Rule 4 — Falling Market + Falling Open Interest

Declining open interest during a declining market indicates that traders are leaving their positions.

The book states that this can mean the trend may not continue.

## Rule 5 — Open Interest at New Price Extremes

Unusually high open interest combined with new price extremes can create difficulties and should be treated carefully.

## Rule 6 — Open Interest Is Not Used Alone

The book analyzes open interest together with price, volume, and candlestick behavior.