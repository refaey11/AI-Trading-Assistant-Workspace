# Open Interest — Common Mistakes

## Mistake 1 — Confusing Open Interest With Volume

Open interest and volume are not the same measure.

The chapter discusses them as separate forms of market information.

## Mistake 2 — Ignoring the Price Direction

Open interest must be interpreted together with the direction of prices.

## Mistake 3 — Assuming Rising Open Interest Is Always Bullish

Rising open interest during a rising market is interpreted differently from rising open interest during a declining market.

## Mistake 4 — Ignoring Falling Open Interest

Declining open interest can indicate that traders are leaving the market and that the existing trend may lose its driving force.

## Mistake 5 — Treating a Rising Market With Falling Open Interest as Strong Confirmation

The book specifically warns that such a rise may be caused by short covering and liquidation.

## Mistake 6 — Ignoring Unusually High Open Interest

Unusually high open interest combined with new price extremes can create difficulties.

## Mistake 7 — Ignoring Candlestick Evidence

The chapter demonstrates the use of open interest together with Japanese candlesticks.

## Mistake 8 — Ignoring Market Context

The book notes that other factors, such as seasonality, should also be considered when analyzing open interest.