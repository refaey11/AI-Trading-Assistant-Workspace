# Open Interest — Trading Application

## Rising Prices + Rising Open Interest

Interpretation:

The book considers this a healthy combination.

Increasing open interest provides confirmation for the rising trend.

## Rising Prices + Falling Open Interest

Interpretation:

The rise may be caused by short covering and liquidation of old long positions.

The book does not consider this a favorable context for continued strength.

## Falling Prices + Rising Open Interest

Interpretation:

New participants are entering the market while prices decline.

The book describes the bears as having the advantage in this situation.

## Falling Prices + Falling Open Interest

Interpretation:

Existing traders are leaving the market.

The decline may therefore lose the force required for continued movement.

## Open Interest With Candlesticks

The book combines open interest with Japanese candlestick signals.

Important examples include:

- Doji
- Rickshaw Man
- Shooting Star
- Other candlestick evidence shown in the chapter

## Important

The book does not provide a mechanical entry, stop-loss, or take-profit system based solely on open interest.