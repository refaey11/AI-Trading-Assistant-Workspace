# TC005 - Common Mistakes

## Mistake 1

Drawing Fibonacci on the wrong swing.

Always draw from a completed impulse wave.

---

## Mistake 2

Trading immediately when price touches a retracement level.

Always wait for confirmation.

---

## Mistake 3

Ignoring the primary trend.

Retracement trades should normally follow the dominant trend.

---

## Mistake 4

Believing every 61.8% retracement will reverse.

No retracement level guarantees a reversal.

---

## Mistake 5

Ignoring candlestick confirmation.

A retracement level without confirmation has much lower probability.

---

## Mistake 6

Ignoring support and resistance.

Retracement levels become stronger when they overlap with historical price levels.

---

## Mistake 7

Ignoring market context.

Trending markets and ranging markets behave differently.

---

## Mistake 8

Using Fibonacci as a prediction tool.

Fibonacci identifies potential reaction zones, not certain turning points.

---

## Mistake 9

Placing Stop Loss exactly on the retracement level.

Stops should be placed beyond the confirming candlestick or structural swing.

---

## Mistake 10

Using only one confirmation.

Professional traders look for confluence, not isolated signals.