# TC005 - Examples

---

## Example 1

### Strong Uptrend

Market makes a strong bullish impulse.

Price begins correcting.

Retracement reaches:

38.2%

Hammer appears.

Price resumes trend.

### Lesson

Strong trends often retrace only 38.2%.

---

## Example 2

### Medium Strength Trend

Price retraces to:

50%

Morning Star appears.

Bullish continuation follows.

### Lesson

50% is one of the strongest institutional retracement areas.

---

## Example 3

### Deep Correction

Price reaches:

61.8%

Bullish Engulfing appears.

Trend resumes.

### Lesson

61.8% often produces the final buying opportunity.

---

## Example 4

### Bearish Trend

Price rallies toward

38.2%

Shooting Star forms.

Trend resumes downward.

---

## Example 5

### Resistance + Retracement

50%

+

Previous Resistance

+

Bearish Engulfing

↓

High Probability Sell

---

## Example 6

### Support + Retracement

61.8%

+

Horizontal Support

+

Hammer

↓

High Probability Buy

---

## Example 7

### Trendline + Retracement

38.2%

+

Trendline

+

Morning Star

↓

Strong Bullish Confirmation

---

## Example 8

### Failed Retracement

Price closes decisively below

61.8%

No bullish confirmation.

### Lesson

Probability of trend continuation decreases.

Possible reversal begins.