# TC005 - Retracement Levels

## Name
Retracement Levels with Candlesticks

## Category
Technical Analysis

## Source
Steve Nison - Beyond Candlesticks
Chapter 12

## Definition

Retracement is a temporary counter move against the primary trend.

Markets rarely move in a straight line.
After every impulse move, price usually retraces a portion before continuing.

The most important retracement levels are:

- 38.2%
- 50%
- 61.8%

These levels become much stronger when they align with Japanese candlestick reversal signals.

## Core Idea

Trend
↓

Price Retracement
↓

Retracement Level
↓

Candlestick Confirmation
↓

Trade Decision

The retracement level alone is NOT an entry signal.

The candlestick provides confirmation.

## Objective

Identify high-probability reversal zones using:

- Fibonacci Retracement
- 50% Retracement
- Candlestick Patterns
- Previous Support/Resistance