CREATE TABLE retracement_levels (

id INTEGER PRIMARY KEY,

concept_id TEXT,

retracement_level REAL,

strength TEXT,

market_condition TEXT,

bullish_confirmation TEXT,

bearish_confirmation TEXT,

notes TEXT

);

INSERT INTO retracement_levels VALUES
(1,'TC005',38.2,
'Weak',
'Strong Trend',
'Hammer, Morning Star, Bullish Engulfing',
'Shooting Star, Evening Star',
'Shallow correction');

INSERT INTO retracement_levels VALUES
(2,'TC005',50,
'Strong',
'Normal Trend',
'Hammer, Morning Star, Bullish Engulfing',
'Bearish Engulfing, Dark Cloud Cover',
'Dow Theory Level');

INSERT INTO retracement_levels VALUES
(3,'TC005',61.8,
'Very Strong',
'Deep Correction',
'Hammer, Morning Star, Bullish Engulfing',
'Shooting Star, Bearish Engulfing',
'Golden Ratio');