# TC005 - Trading Application

## Step 1

Determine trend.

Never use retracement in sideways markets.

---

## Step 2

Identify the latest impulse move.

Uptrend:

Swing Low → Swing High

Downtrend:

Swing High → Swing Low

---

## Step 3

Draw Fibonacci Retracement.

Focus on:

38.2%

50%

61.8%

---

## Step 4

Wait.

Never predict.

Allow price to reach the level.

---

## Step 5

Observe Candlestick Confirmation.

Bullish Examples

• Hammer

• Morning Star

• Bullish Engulfing

• Piercing Pattern

Bearish Examples

• Shooting Star

• Evening Star

• Bearish Engulfing

• Dark Cloud Cover

---

## Step 6

Entry

Enter after confirmation candle closes.

Never enter before candle closes.

---

## Step 7

Stop Loss

Below bullish confirmation.

Above bearish confirmation.

---

## Step 8

Targets

Previous High

Trend Continuation

Next Resistance

or

Measured Move

---

## Risk Management

Higher confluence

↓

Higher probability

Confluence includes:

Retracement

Trendline

Support

Resistance

Candlestick

Volume

---

## Professional Workflow

Trend

↓

Impulse

↓

Retracement

↓

Candlestick

↓

Entry

↓

Risk Management

↓

Target