# TC005 - Market Psychology

## Why Retracements Exist

Financial markets never move in straight lines.

Every strong move creates two groups:

1. Traders taking profits.
2. Traders waiting to join the trend.

Both groups create temporary counter-moves called retracements.

---

## Psychology of 38.2%

Represents confidence.

Buyers remain aggressive.

Very few traders are willing to sell.

Demand quickly absorbs supply.

Result:

Small correction.

Strong trend.

---

## Psychology of 50%

This is the battlefield.

Early buyers:

Take profits.

Late buyers:

Wait for discount.

Sellers:

Attempt to reverse price.

Institutional traders:

Often begin accumulating.

This creates heavy order flow.

---

## Psychology of 61.8%

Represents maximum acceptable correction.

If buyers defend this area:

Trend usually survives.

If sellers break it decisively:

Market confidence weakens.

Probability of trend reversal increases.

---

## Why Candlesticks Matter

Retracement alone tells us:

"Price reached an important level."

Candlestick tells us:

"Who won the battle."

Example

Price reaches 50%.

Hammer appears.

Meaning:

Sellers pushed lower.

Buyers completely rejected lower prices.

Control shifts back to buyers.

---

## Institutional Perspective

Large institutions rarely buy at highs.

They prefer waiting for pullbacks.

Retracement levels provide:

• Better pricing
• Lower risk
• Higher reward

---

## Retail Trader Mistake

Retail traders often chase trends.

Professionals wait for retracement.

Difference:

Retail buys emotionally.

Professionals buy strategically.

---

## Market Cycle

Impulse

↓

Profit Taking

↓

Retracement

↓

Accumulation

↓

Continuation

---

## Golden Principle

Price reaches the level.

Candlestick confirms.

Trader executes.