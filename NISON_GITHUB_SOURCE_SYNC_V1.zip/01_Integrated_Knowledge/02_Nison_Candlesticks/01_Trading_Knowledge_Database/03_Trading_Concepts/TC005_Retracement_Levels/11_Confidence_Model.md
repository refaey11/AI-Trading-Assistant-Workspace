# TC005 - Confluence Model

## Definition

Confluence is the alignment of multiple independent technical factors at the same price area.

The more independent factors agree...

the higher the probability of a successful trade.

Retracement levels should NEVER be traded in isolation.

---

## Confluence Levels

### ★☆☆☆☆ (Very Weak)

Retracement level only.

Example:

- 50% Retracement

No confirmation.

---

### ★★☆☆☆ (Weak)

Retracement

+

Trend Direction

---

### ★★★☆☆ (Medium)

Retracement

+

Candlestick Confirmation

Examples:

- Hammer
- Bullish Engulfing
- Shooting Star

---

### ★★★★☆ (Strong)

Retracement

+

Candlestick

+

Trendline

OR

Horizontal Support / Resistance

---

### ★★★★★ (Professional Setup)

Retracement

+

Candlestick Pattern

+

Trendline

+

Support / Resistance

+

Volume Confirmation

+

Higher Timeframe Agreement

This represents the highest probability setup.

---

## Confluence Priority

1. Trend
2. Retracement Level
3. Candlestick Pattern
4. Support / Resistance
5. Trendline
6. Volume
7. Higher Timeframe

---

## Professional Rule

Never trade because price reached a Fibonacci level.

Trade because multiple independent tools reached the same conclusion.