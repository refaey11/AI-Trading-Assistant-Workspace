# TC005 - Backtesting

Record:

Market

Date

Timeframe

Trend

Impulse Size

Retracement Level

38.2%

50%

61.8%

Candlestick Pattern

Entry

Stop Loss

Target

Result

Maximum Favorable Excursion (MFE)

Maximum Adverse Excursion (MAE)

Notes

Questions

1. Was the retracement level respected?

2. Which level worked best?

3. Did candlestick confirmation improve the trade?

4. Did trend alignment increase probability?

5. Could the entry have been improved?

6. Was risk management respected?