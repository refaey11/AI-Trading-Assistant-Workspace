# TC005 - Core Rules

## Rule 1
Always identify the primary trend first.

Never calculate retracement inside a sideways market.

---

## Rule 2
Draw retracement only after a completed impulse move.

Do not use incomplete swings.

---

## Rule 3
In an Uptrend

Swing Low
↓

Swing High

Retracement is measured from Low → High.

Expected support zones:

• 38.2%
• 50%
• 61.8%

---

## Rule 4
In a Downtrend

Swing High
↓

Swing Low

Retracement is measured from High → Low.

Expected resistance zones:

• 38.2%
• 50%
• 61.8%

---

## Rule 5
38.2%

Represents a shallow correction.

Usually appears during strong trends.

Trend strength remains high.

---

## Rule 6
50%

Most respected retracement.

Originates from Dow Theory.

Not a Fibonacci ratio.

Very common institutional level.

---

## Rule 7
61.8%

Golden Ratio.

Represents deep correction.

Last important retracement before trend failure.

---

## Rule 8

Never trade because price touched a retracement level.

Wait for confirmation.

---

## Rule 9

Candlestick confirmation is mandatory.

Examples:

Bullish

• Hammer
• Bullish Engulfing
• Morning Star
• Piercing Pattern

Bearish

• Shooting Star
• Bearish Engulfing
• Evening Star
• Dark Cloud Cover

---

## Rule 10

Multiple confirmations increase probability.

Retracement +

Trendline +

Support/Resistance +

Candlestick +

Volume

=

High Probability Setup

---

## Rule 11

61.8% failure may indicate:

Trend weakness

or

Possible Trend Reversal

---

## Rule 12

Retracement is a Zone.

Not an exact price.