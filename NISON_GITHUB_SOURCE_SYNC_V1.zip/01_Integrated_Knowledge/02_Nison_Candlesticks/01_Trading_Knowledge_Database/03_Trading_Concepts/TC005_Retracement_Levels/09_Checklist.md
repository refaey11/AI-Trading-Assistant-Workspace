# TC005 - Trading Checklist

Before opening a trade:

☐ Primary trend identified.

☐ Completed impulse wave identified.

☐ Fibonacci correctly drawn.

☐ Price reached a retracement level.

☐ Candlestick confirmation exists.

☐ Support or resistance agrees.

☐ Trendline agrees.

☐ Volume supports the setup.

☐ Stop Loss defined.

☐ Risk/Reward acceptable.

☐ Entry after candle closes.

☐ Trade follows the primary trend.