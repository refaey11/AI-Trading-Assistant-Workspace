# Tick Volume — Examples

## Example 1 — Cocoa

The chapter presents an intraday Cocoa chart using tick volume with candlesticks.

The chart demonstrates how tick volume can be examined alongside candlestick patterns.

A hammer and a bullish engulfing pattern appear in the example.

The tick volume information provides additional context for interpreting the price movement.

## Example 2 — Crude Oil

The chapter presents an intraday Crude Oil chart with tick volume and candlesticks.

The example shows a decline in price followed by candlestick activity and changes in tick volume.

The tick-volume behavior is used as additional evidence when evaluating the market movement.

## Main Lesson From the Examples

Tick volume is most useful when it is combined with:

- Price movement
- Candlestick patterns
- Market context
- Changes in activity