# Tick Volume — Checklist

## Before Analysis

- [ ] Identify the trading period.
- [ ] Identify the price direction.
- [ ] Identify relevant candlestick patterns.
- [ ] Check tick volume behavior.
- [ ] Compare tick volume with price movement.

## Confirmation

- [ ] Does tick volume support the price movement?
- [ ] Is market activity increasing?
- [ ] Is the candlestick signal supported?

## Warning Signs

- [ ] Is price moving while tick volume weakens?
- [ ] Is there conflicting evidence?
- [ ] Is the signal based only on tick volume?

## Final Check

- [ ] Tick volume is being used as supporting information.
- [ ] Tick volume is not being treated as exact contract volume.
- [ ] Price and candlestick context have been considered.