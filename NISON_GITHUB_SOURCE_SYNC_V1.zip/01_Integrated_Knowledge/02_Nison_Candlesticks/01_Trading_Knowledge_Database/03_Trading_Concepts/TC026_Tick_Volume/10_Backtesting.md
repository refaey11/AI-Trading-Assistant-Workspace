# Tick Volume — Backtesting Framework

## Objective

Test whether tick volume provides useful supporting information when combined with candlestick patterns.

## Variables

Record:

- Market
- Timeframe
- Price movement
- Candlestick pattern
- Tick volume
- Tick volume direction
- Result

## Basic Test

For each setup:

1. Identify the candlestick signal.
2. Record tick volume at the signal.
3. Compare tick volume with previous periods.
4. Classify tick volume as:
   - Increasing
   - Decreasing
   - Stable
5. Record the subsequent price behavior.

## Important Limitation

The chapter does not provide a complete statistical backtesting system.

Therefore, the database should store the observations without claiming that the chapter proves a specific win rate.

## Suggested Record

```text
Market:
Date:
Timeframe:
Candlestick Pattern:
Price Direction:
Tick Volume:
Previous Tick Volume:
Volume Direction:
Price Outcome:
Notes: