# Tick Volume — Trading Application

## Application 1 — Candlestick Confirmation

Tick volume can be used to evaluate a candlestick signal.

The chapter presents examples where candlestick patterns are accompanied by changes in tick volume.

The purpose is to determine whether the market activity supports the price signal.

## Application 2 — Detecting Weakening Movement

If prices continue moving in one direction while tick volume begins to decline, this can provide a warning that the movement may be losing strength.

## Application 3 — Intraday Analysis

Tick volume is particularly useful in intraday charts because it provides information about activity during shorter periods.

## Application 4 — Combining Price and Volume

The preferred approach is:

1. Identify the price movement.
2. Identify the relevant candlestick pattern.
3. Examine tick volume.
4. Determine whether tick volume supports or weakens the signal.
5. Avoid making a decision from tick volume alone.