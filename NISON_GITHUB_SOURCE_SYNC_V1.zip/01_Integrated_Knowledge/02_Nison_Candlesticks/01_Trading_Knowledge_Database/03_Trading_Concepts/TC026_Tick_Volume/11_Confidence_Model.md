---

# 11_Confidence_Model.md

```markdown
# Tick Volume — Confidence Model

## Purpose

Use tick volume as supporting evidence rather than as an independent trading signal.

## Evidence Levels

### Stronger Support

Conditions:

- Clear price movement
- Relevant candlestick signal
- Tick volume behavior supports the movement

Interpretation:

The tick volume provides additional confirmation.

### Neutral

Conditions:

- Candlestick signal exists
- Tick volume provides no clear confirmation or warning

Interpretation:

Tick volume does not materially change the analysis.

### Warning

Conditions:

- Price continues moving
- Tick volume weakens
- Candlestick behavior suggests possible loss of momentum

Interpretation:

The movement may be losing strength.

## Important Rule

This model is an organizational framework for the database.

It should not be interpreted as a numerical probability or guaranteed trading edge unless supported by separate testing.