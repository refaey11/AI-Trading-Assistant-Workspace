CREATE TABLE tick_volume_basics (
    id INTEGER PRIMARY KEY,
    concept_name VARCHAR(100),
    definition TEXT,
    measures TEXT,
    does_not_measure TEXT,
    primary_use TEXT,
    limitations TEXT,
    source_chapter INTEGER
);

INSERT INTO tick_volume_basics (
    id,
    concept_name,
    definition,
    measures,
    does_not_measure,
    primary_use,
    limitations,
    source_chapter
)
VALUES (
    1,
    'Tick Volume',
    'The number of price changes occurring during a trading period.',
    'Market activity during a specified period.',
    'It does not necessarily represent the exact number of contracts traded.',
    'To provide additional information when analyzing price movement and candlestick patterns.',
    'Should not be treated as an exact measure of contract volume or as an isolated trading signal.',
    15
);