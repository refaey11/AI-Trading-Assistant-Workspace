# Tick Volume — Core Rules

## Rule 1 — Tick Volume Measures Activity

Tick volume shows the number of price changes during a specified period.

It does not necessarily equal the number of contracts traded.

## Rule 2 — Use Tick Volume With Price

Tick volume becomes more useful when analyzed together with price movement and candlestick patterns.

## Rule 3 — Look for Confirmation

A candlestick signal can become more meaningful when tick volume provides supporting evidence.

## Rule 4 — Watch for Divergence

A price movement accompanied by weakening tick volume may provide a warning that the movement is losing strength.

## Rule 5 — Context Matters

Tick volume should be interpreted in the context of the current market movement rather than used as an isolated signal.

## Rule 6 — Do Not Treat Tick Volume as Exact Contract Volume

The chapter specifically explains that tick volume is not a direct measurement of the actual number of contracts traded.