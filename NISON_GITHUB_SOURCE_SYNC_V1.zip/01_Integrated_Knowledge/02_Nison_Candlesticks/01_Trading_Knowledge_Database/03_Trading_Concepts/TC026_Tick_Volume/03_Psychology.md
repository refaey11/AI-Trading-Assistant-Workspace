# Tick Volume — Psychology

## Market Participation

Tick volume can provide clues about the level of market activity behind a price movement.

When traders observe price movement together with changes in tick volume, they can evaluate whether market activity is supporting the movement.

## Buyer and Seller Pressure

The chapter uses tick volume together with candlestick behavior to help interpret changing pressure between buyers and sellers.

A price movement that loses supporting activity may indicate that the underlying pressure is weakening.

## Avoiding False Confidence

Tick volume should not be treated as proof that a trade will succeed.

It is supporting information that must be evaluated together with price action and candlestick patterns.

## Psychological Lesson

The trader should avoid relying on a single data point.

Price, candlestick behavior, and tick volume should be considered together before reaching a conclusion.