# Tick Volume — Description

## Definition

Tick Volume is the number of price changes, or "ticks," that occur during a trading period.

In the futures markets, daily reports may provide tick volume as an indication of trading activity during a session.

## Important Distinction

Tick volume does not represent the exact number of contracts traded.

For example, a chart may show a tick volume of 50 ticks per hour, but the actual number of contracts represented by those ticks is not necessarily known.

Therefore, tick volume should be treated as an indication of market activity rather than an exact measure of traded contract volume.

## Source Context

The chapter uses tick volume together with candlestick patterns to evaluate market behavior and identify possible confirmations or warnings.

## Key Idea

A change in tick volume can provide additional information about the strength or weakness of a price movement.