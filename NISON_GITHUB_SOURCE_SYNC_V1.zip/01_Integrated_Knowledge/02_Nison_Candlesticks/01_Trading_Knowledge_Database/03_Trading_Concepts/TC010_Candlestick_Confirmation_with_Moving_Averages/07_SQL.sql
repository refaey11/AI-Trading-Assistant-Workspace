CREATE TABLE moving_average_candlestick_confirmation (

    id INTEGER PRIMARY KEY,

    concept_code TEXT,

    moving_average_type TEXT,

    moving_average_period INTEGER,

    trend_direction TEXT,

    moving_average_role TEXT,

    candlestick_pattern TEXT,

    entry_rule TEXT,

    stop_loss_rule TEXT,

    target_rule TEXT,

    confidence_level TEXT,

    source_figure TEXT,

    notes TEXT

);