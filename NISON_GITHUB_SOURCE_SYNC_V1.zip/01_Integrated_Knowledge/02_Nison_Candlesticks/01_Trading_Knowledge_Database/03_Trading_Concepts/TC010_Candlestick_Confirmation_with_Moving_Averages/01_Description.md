# TC010 - Candlestick Confirmation with Moving Averages

## Name

Candlestick Confirmation with Moving Averages

---

## Category

Trend Following

Dynamic Support & Resistance

Candlestick Confirmation

---

## Source

Steve Nison

Beyond Candlesticks

Chapter 13

Figures 13.1, 13.2, 13.3

---

## Definition

Candlestick Confirmation with Moving Averages is the practice of combining Japanese candlestick reversal patterns with Moving Averages acting as Dynamic Support or Dynamic Resistance.

Instead of relying only on the Moving Average, traders wait for a candlestick signal that confirms whether buyers or sellers are defending the level.

---

## Objective

Increase trade reliability by requiring both:

- Dynamic Support / Resistance
- Candlestick Confirmation

before entering a trade.

---

## Core Principle

Moving Average

+

Candlestick Pattern

=

Higher Probability Trade

---

## Typical Bullish Patterns

- Hammer
- Bullish Engulfing
- Bullish Harami
- Piercing Pattern

---

## Typical Bearish Patterns

- Shooting Star
- Hanging Man
- Bearish Engulfing
- Dark Cloud Cover
- Evening Star

---

## Professional Principle

A Moving Average provides the location.

Candlesticks provide the timing.