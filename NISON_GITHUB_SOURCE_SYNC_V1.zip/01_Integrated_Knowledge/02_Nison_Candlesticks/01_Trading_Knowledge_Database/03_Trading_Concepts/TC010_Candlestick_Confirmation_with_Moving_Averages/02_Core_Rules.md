# TC010 - Core Rules

## Rule 1

Never buy simply because price reaches the Moving Average.

Wait for bullish confirmation.

---

## Rule 2

Never sell simply because price reaches the Moving Average.

Wait for bearish confirmation.

---

## Rule 3

Bullish patterns near a rising Moving Average strengthen support.

---

## Rule 4

Bearish patterns near a falling Moving Average strengthen resistance.

---

## Rule 5

The strongest setups occur when:

Trend

+

Moving Average

+

Candlestick Pattern

all agree.

---

## Rule 6

If price slices through the Moving Average without rejection,

ignore reversal signals.

---

## Rule 7

The Moving Average defines the zone.

The candlestick defines the entry.