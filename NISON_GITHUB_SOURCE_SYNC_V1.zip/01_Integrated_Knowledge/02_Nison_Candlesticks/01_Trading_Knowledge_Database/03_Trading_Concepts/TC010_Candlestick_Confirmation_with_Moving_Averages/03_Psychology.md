# TC010 - Market Psychology

## Why Candlestick Confirmation Matters

A Moving Average only identifies a potential support or resistance area.

It does not reveal whether buyers or sellers are actually defending that area.

Candlesticks provide this missing information.

---

## Bullish Psychology

Price declines toward a rising Moving Average.

Buyers begin defending the average.

This defense appears through bullish candlestick patterns such as:

- Hammer
- Bullish Engulfing
- Bullish Harami
- Piercing Pattern

The candlestick confirms that demand has overcome supply.

---

## Bearish Psychology

Price rallies toward a falling Moving Average.

Sellers begin defending the average.

This defense appears through bearish candlestick patterns such as:

- Shooting Star
- Hanging Man
- Bearish Engulfing
- Dark Cloud Cover

The candlestick confirms that supply has overcome demand.

---

## Dynamic Support

The Moving Average attracts buyers.

The candlestick proves that buyers actually entered.

---

## Dynamic Resistance

The Moving Average attracts sellers.

The candlestick proves that sellers actually entered.

---

## Professional Mindset

Professionals never assume that a Moving Average will hold.

They wait for price action to confirm whether the level is being respected.