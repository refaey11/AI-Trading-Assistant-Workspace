# TC010 - Examples

---

## Example 1

### Source

Figure 13.1

### Market Condition

Uptrend

### Moving Average

65-Day SMA

### Candlestick Confirmation

- Bullish Engulfing
- Hammer
- Bullish Harami
- Hammer-like Candle

### Observation

Each bullish candlestick appeared while price tested the 65-Day Moving Average.

### Interpretation

The Moving Average acted as Dynamic Support.

The candlestick patterns confirmed that buyers defended the level.

### Trading Lesson

Never buy because price touches the Moving Average.

Buy only after bullish candlestick confirmation appears.

---

## Example 2

### Source

Figure 13.2

### Market Condition

Potential Trend Reversal

### Moving Average

65-Day SMA

### Candlestick Confirmation

Dark Cloud Cover

### Observation

Price failed to reclaim the Moving Average.

A Dark Cloud Cover formed immediately after.

### Interpretation

The Moving Average acted as Dynamic Resistance.

The bearish candlestick confirmed that sellers rejected higher prices.

### Trading Lesson

When bearish candlestick patterns appear directly below a Moving Average, probability favors continuation of the downtrend.

---

## Example 3

### Source

Figure 13.3

### Market Condition

Bullish Trend

### Moving Average

65-Day SMA

### Candlestick Confirmation

- Hammer
- Tweezer Bottom

### Observation

Price tested the Moving Average twice.

The first test produced a Hammer.

The second test produced a Tweezer Bottom.

### Interpretation

Multiple bullish confirmations strengthened Dynamic Support.

### Trading Lesson

Repeated successful tests of a Moving Average increase confidence that institutions continue defending the trend.