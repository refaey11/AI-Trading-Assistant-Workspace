# TC010 - Confidence Model

## Base Score

Trend Alignment

+20

Price at Moving Average

+20

Dynamic Support / Resistance

+20

Candlestick Confirmation

+20

Risk / Reward

+10

Volume Confirmation (Optional)

+10

---

## Final Score

90–100

Very High Confidence

70–89

High Confidence

50–69

Moderate Confidence

Below 50

Avoid Trade