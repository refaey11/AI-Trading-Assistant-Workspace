# TC010 - Trading Application

## Bullish Setup

Step 1

Identify an uptrend.

↓

Step 2

Wait for price to retrace toward a rising Moving Average.

↓

Step 3

Watch for bullish candlestick confirmation.

Examples:

- Hammer
- Bullish Engulfing
- Bullish Harami
- Piercing Pattern

↓

Step 4

Enter after the confirmation candle closes.

↓

Step 5

Place Stop Loss below the confirmation candle.

---

## Bearish Setup

Step 1

Identify a downtrend.

↓

Step 2

Wait for price to rally toward a falling Moving Average.

↓

Step 3

Watch for bearish confirmation.

Examples:

- Shooting Star
- Hanging Man
- Bearish Engulfing
- Dark Cloud Cover

↓

Step 4

Enter after candle close.

↓

Step 5

Place Stop Loss above the confirmation candle.

---

## Professional Workflow

Trend

↓

Moving Average

↓

Candlestick Confirmation

↓

Entry

↓

Risk Management

↓

Exit