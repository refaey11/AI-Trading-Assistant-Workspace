# TC010 - Trading Checklist

□ Primary trend identified.

□ Moving Average identified.

□ Price testing the Moving Average.

□ Dynamic Support or Resistance confirmed.

□ Valid candlestick pattern formed.

□ Candle closed before entry.

□ Stop Loss defined.

□ Risk / Reward acceptable.

□ Position size calculated.

□ Trade recorded.