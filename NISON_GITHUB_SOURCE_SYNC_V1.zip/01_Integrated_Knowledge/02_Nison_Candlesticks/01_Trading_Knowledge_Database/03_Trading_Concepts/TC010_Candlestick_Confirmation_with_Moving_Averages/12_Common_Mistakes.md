# TC010 - Common Mistakes

## Mistake 1

Buying or selling solely because price touched the Moving Average.

---

## Mistake 2

Ignoring the primary trend.

---

## Mistake 3

Entering before the confirmation candle closes.

---

## Mistake 4

Trading against Dynamic Support or Resistance.

---

## Mistake 5

Ignoring nearby horizontal support or resistance.

---

## Mistake 6

Treating every candlestick pattern as equally reliable.

Patterns occurring at a Moving Average have greater significance.

---

## Mistake 7

Ignoring market context.

Moving Averages and candlestick patterns must always be interpreted within the broader market structure.