# TC010 - Backtesting

## Goal

Evaluate the effectiveness of combining Moving Averages with Candlestick Confirmation.

---

## Data to Record

Trade Number

Date

Asset

Moving Average Type

Moving Average Period

Trend

Candlestick Pattern

Dynamic Support / Resistance

Entry

Stop Loss

Target

Exit

Result

R-Multiple

Comments

---

## Metrics

Win Rate

Average Reward

Average Risk

Profit Factor

Maximum Drawdown

Expectancy

Average Holding Time

Confirmation Accuracy