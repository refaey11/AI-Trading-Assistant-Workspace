# 03 — Psychology

## TC033 — How I Benefited From Candlesticks

### Source
Chapter 20 — How I Benefited From Candlesticks

---

## 1. Individual Trading Style

The chapter emphasizes that every trader has an individual trading style.

The author's approach may differ from the approach of another trader.

The examples are therefore presented to demonstrate an approach rather than to require the reader to follow the same thoughts, processes, or procedures.

---

## 2. Avoiding Premature Decisions

The examples demonstrate waiting for additional evidence before acting.

In the first example, the trader did not immediately short sell after the market approached the neckline.

A long white candle was followed by a small black candle, providing evidence that the positive effect of the white candle was beginning to fade.

---

## 3. Avoiding Excessive Short Selling

In the coffee example, the market was already excessively oversold after a strong decline.

The appearance of a Harami warned against rushing into a short-selling position.

The chapter explains that the previous downward movement had been balanced, leaving the possibility of sideways trading or an upward move.

---

## 4. Respecting the Overall Trend

In the crude-oil example, a Hammer appeared during a rally.

The Hammer was not used as a buying signal because the overall market trend was downward.

The example demonstrates the importance of considering the broader market direction when interpreting a positive candlestick signal.

---

## 5. Waiting for Confirmation

In the Hammer example, the trader required confirmation before recommending a purchase because the support level was uncertain.

The following day's upward gap provided additional evidence before the purchase recommendation.

---

## 6. Responding to Failed Breakouts

In the final example, the market failed to break a short-term resistance level.

The stop-loss was then raised to the same price as the entry.

The stop was subsequently triggered during the market's decline.

---

## 7. Using Multiple Supporting Factors

The examples demonstrate combining candlestick signals with other technical evidence.

The supporting factors include:

- Support and resistance.
- Trend direction.
- Previous highs and lows.
- Price gaps/windows.
- Oscillator divergence.
- Western technical patterns.

The chapter demonstrates that candlestick signals can be integrated with other technical methods rather than used in isolation.