# 05 — Examples

## TC033 — How I Benefited From Candlesticks

### Source
Chapter 20 — How I Benefited From Candlesticks

---

## Example 20.1 — Short-Selling After a Head and Shoulders Break

The Head and Shoulders neckline was broken on May 29, turning the market downward.

During the week of June 11, prices rose strongly toward the neckline.

A long white candle appeared on June 11.

The following session produced a small black candle, indicating that the positive effect of the previous white candle was beginning to fade.

A short-selling recommendation was made on June 13 at $6.27.

The stop-loss was placed above the neckline at $6.35.

The target was $5.90, based on a previous support area from the same year.

On June 18, several bullish indications appeared:

- Bullish Engulfing Pattern.
- Spring-type price movement.
- Bullish White Belt Hold.
- Positive divergence involving the oscillator.

The short position was covered in the following session at $6.12.

---

## Example 20.2 — Coffee Short-Selling Trade

The market had formed declining highs since late May.

A downward-sloping resistance line showed the overall downward trend.

On June 14, the market fell below the May and March support levels.

A long black candle showed strong selling pressure.

However, the market was excessively oversold.

A small candle following the long black candle formed a Harami.

The Harami warned against rushing into a short-selling position.

The market then made a secondary upward move to $0.92.

The $0.92 level had previously acted as support in late March and May.

After being broken, the support level became resistance.

A downward Window appeared on June 20.

On June 21, the market failed to move above the resistance formed at the Window.

A short-selling recommendation was made at $0.9015.

The stop-loss was placed at the June 20 high of $0.9175.

The target was $0.8675, based on a previous support level from the same year.

The market declined after the recommendation.

---

## Example 20.3 — Crude Oil Short-Selling Trade

The crude-oil market was in a downward trend.

A Hammer appeared during a rally beginning on June 21.

The Hammer was not used as a buying signal because the overall market trend was downward.

Several days later, a Bearish Engulfing Pattern appeared twice consecutively.

A small Window existed between June 15 and June 18.

The Window was considered potential resistance if prices rallied.

The stop-loss was placed slightly above the Window at $17.65.

The target was a retest of the Hammer's low.

The market later rallied on June 25 and then declined from the resistance created by the Bearish Engulfing Pattern and the Window.

---

## Example 20.4 — Hammer and Morning Star Buying Trade

A Hammer appeared on June 4.

The market maintained a late-April and mid-May low near $2.65 at the close.

The same candle also formed a bullish Spring pattern because prices reached a new low and failed to maintain the new lower level.

Confirmation was required before recommending a purchase because the support at $2.65 was uncertain.

The following day, the market opened with an upward gap.

A purchase was recommended at $2.68 with a stop at $2.64 below the support line.

The target was the downward-sloping resistance line at $2.79.

A distinctive white candle following the Hammer completed a Morning Star pattern.

---

## Example 20.5 — Short-Term Buying Trade

The market provided several buying signals on Friday, March 2.

The first signal was a Hammer.

The Hammer had a small body located inside the previous long white candle, forming a bullish Harami.

The Hammer's low was supported by a support level formed in early February.

The market failed to maintain the new low.

A short-term purchase was recommended on Monday, March 5 at $21.38.

The target was a retest of the late-February highs near $22.

The stop-loss was placed below the Hammer's low at $21.10.

The market moved upward toward the February 28 and March 1 highs near $21.75.

The market failed to break the short-term resistance at this price.

The stop-loss was raised to the entry price.

The stop-loss was triggered during the orderly decline on March 7.

After prices moved below the Hammer's low, the market declined sharply.