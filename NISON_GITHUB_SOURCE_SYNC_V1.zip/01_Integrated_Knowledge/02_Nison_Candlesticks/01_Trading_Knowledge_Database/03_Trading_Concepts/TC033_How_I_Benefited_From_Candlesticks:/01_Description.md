# 01 — Description

## TC033 — How I Benefited From Candlesticks

### Chapter 20
### How I Benefited From Candlesticks

### Source Pages
Chapter 20 material supplied by the user

---

## Description

This chapter presents examples of trades recommended to Merrill Lynch during a month.

The recommendations used candlestick techniques as part of the analysis.

The examples are focused on futures because futures were the author's specialty.

The examples also focus on short-term trading, using:

- Intraday charts.
- Daily charts.

---

## Purpose of the Chapter

The purpose of the chapter is not to teach a fixed set of trading rules.

Instead, the chapter demonstrates how candlestick techniques can be combined with other technical methods.

The chapter aims to show how candlesticks can be integrated into an existing technical analysis approach.

---

## Trading Examples

The chapter presents several examples showing how candlestick signals were used in trading decisions.

The examples include:

- A short-selling trade following a Head and Shoulders neckline break.
- A coffee market short-selling trade.
- A crude-oil short-selling trade.
- A buying trade following a Hammer and Morning Star.
- A short-term buying trade involving a Hammer and a bullish Harami.

---

## Main Candlestick Concepts Mentioned

The chapter includes:

- Bullish Engulfing Pattern.
- Bearish Engulfing Pattern.
- Hammer.
- Bullish Harami.
- Bearish Harami.
- Piercing/Window-related price action as described in the examples.
- White Belt Hold.
- Spring.
- Morning Star.

---

## Chapter Theme

The examples demonstrate how candlestick signals can be used together with:

- Support and resistance.
- Trend lines.
- Head and Shoulders.
- Price gaps/windows.
- Momentum/oscillator divergence.
- Previous highs and lows.
- Price-action confirmation.

The chapter emphasizes that the trader's approach may differ from the author's approach and that the examples are intended to demonstrate the integration of candlesticks with other technical methods.