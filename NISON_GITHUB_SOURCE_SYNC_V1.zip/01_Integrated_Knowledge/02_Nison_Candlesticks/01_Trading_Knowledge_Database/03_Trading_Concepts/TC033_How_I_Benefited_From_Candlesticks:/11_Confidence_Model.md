# 11 — Confidence Model

## TC033 — How I Benefited From Candlesticks

### Source
Chapter 20 — How I Benefited From Candlesticks

---

## Confidence Model

The supplied Chapter 20 material does not provide a numerical confidence model.

The chapter does not assign numerical confidence scores or percentages to its candlestick signals.

---

## Supporting Evidence

The examples demonstrate the use of multiple technical factors when making trading decisions.

These factors include:

- Candlestick patterns.
- Support.
- Resistance.
- Trend direction.
- Previous highs and lows.
- Windows.
- Oscillator divergence.
- Head and Shoulders.
- Price gaps.

---

## Confirmation

The chapter demonstrates the use of additional evidence before some trading decisions.

In the Hammer buying example:

- A Hammer appeared near support.
- The support level was uncertain.
- Confirmation was required.
- The following day, the market opened with an upward gap.
- A purchase recommendation was then made.

---

## Trend Context

The crude-oil example demonstrates that the Hammer was not used as a buying signal because the overall market trend was downward.

---

## Source Limitation

No numerical confidence score, confidence percentage, or formal confidence model is provided in the supplied Chapter 20 material.