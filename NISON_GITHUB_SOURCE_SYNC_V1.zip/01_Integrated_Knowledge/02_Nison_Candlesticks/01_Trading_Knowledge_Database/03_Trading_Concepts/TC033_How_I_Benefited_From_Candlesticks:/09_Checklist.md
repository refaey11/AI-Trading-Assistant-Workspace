# 09 — Checklist

## TC033 — How I Benefited From Candlesticks

### Source
Chapter 20 — How I Benefited From Candlesticks

---

## Trading Context

- [ ] Identify whether the analysis is based on an intraday chart or a daily chart.
- [ ] Consider the overall market trend.
- [ ] Combine candlestick signals with other technical methods.

---

## Short-Selling Setup

- [ ] Check for bearish market direction.
- [ ] Consider relevant resistance levels.
- [ ] Consider previous support levels that may have become resistance.
- [ ] Check for bearish candlestick evidence.
- [ ] Consider a Bearish Engulfing Pattern when present.
- [ ] Consider a downward Window when present.
- [ ] Define a stop-loss level.
- [ ] Define a target based on the technical level described in the example.

---

## Short-Selling Management

- [ ] Watch for bullish candlestick evidence against an existing short position.
- [ ] Check for a Bullish Engulfing Pattern.
- [ ] Check for a bullish White Belt Hold.
- [ ] Check for Spring-type price movement.
- [ ] Check for positive oscillator divergence.
- [ ] Consider covering the short position when the supporting evidence indicates that the short-selling environment is no longer suitable.

---

## Oversold Conditions

- [ ] Identify when the market has become excessively oversold.
- [ ] Avoid rushing into a short-selling position when the chapter's example provides contrary evidence.
- [ ] Check for a Harami following a strong decline.
- [ ] Consider the possibility of sideways trading or an upward move described in the chapter.

---

## Hammer

- [ ] Identify a Hammer.
- [ ] Consider the overall market trend before interpreting the Hammer.
- [ ] Do not automatically use a Hammer as a buying signal when the overall trend is downward.
- [ ] Check the support level associated with the Hammer.
- [ ] When support is uncertain, wait for additional confirmation before recommending a purchase.

---

## Bullish Buying Evidence

- [ ] Check for a Bullish Harami.
- [ ] Check for a Spring-type price movement.
- [ ] Check for an upward gap.
- [ ] Check for a Morning Star when the described pattern is completed.
- [ ] Consider previous support levels.
- [ ] Consider failure to maintain a new low.

---

## Trade Management

- [ ] Define the entry price.
- [ ] Define the stop-loss.
- [ ] Define the target.
- [ ] Monitor the market's reaction at the target or resistance level.
- [ ] If the market fails to break short-term resistance, consider the stop-loss adjustment described in the example.
- [ ] Note whether the stop-loss is triggered during the subsequent market movement.