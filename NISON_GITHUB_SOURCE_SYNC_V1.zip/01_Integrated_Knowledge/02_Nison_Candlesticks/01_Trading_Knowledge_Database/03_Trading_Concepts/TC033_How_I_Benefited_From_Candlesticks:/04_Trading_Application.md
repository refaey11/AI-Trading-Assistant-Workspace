# 04 — Trading Application

## TC033 — How I Benefited From Candlesticks

### Source
Chapter 20 — How I Benefited From Candlesticks

---

## 1. Head and Shoulders Short-Selling Example

The market broke the neckline of a Head and Shoulders pattern on May 29.

The market then turned downward.

During the week of June 11, prices rose strongly toward the neckline.

A long white candle appeared on June 11.

The following session produced a small black candle, indicating that the positive effect of the previous white candle was beginning to fade.

A short-selling recommendation was made on June 13 at $6.27.

The stop-loss was placed above the neckline at $6.35.

The target was $5.90, based on a previous support area from the same year.

On June 18, several bullish indications appeared.

The short position was covered in the following session at $6.12.

---

## 2. June 18 Bullish Evidence

The evidence for covering the short position included:

### Bullish Engulfing

The white candle on June 18 engulfed the previous day's black candle.

The two candles formed a Bullish Engulfing Pattern.

### Spring-Type Price Movement

The June 18 opening price reached a new low for the market.

Prices then quickly moved back above a previous low and could not remain below that level.

The target was set at $6.30, the upper boundary of the range.

### White Belt Hold

The June 18 candle formed a bullish White Belt Hold.

### Positive Divergence

The price lows were not confirmed by deeper lows on the oscillators.

This formed positive divergence and indicated that the bears were losing control.

---

## 3. Coffee Short-Selling Example

The market had formed a series of declining highs since late May.

A downward-sloping resistance line described the overall downward trend.

On June 14, the market fell below the May and March support levels.

The black candle for that day showed strong selling pressure.

However, the market was excessively oversold, making a short-selling trade difficult at that point.

A small candle following the long black candle formed a Harami.

This warned against rushing into a short-selling position.

---

## 4. Coffee Resistance and Short Entry

The coffee market subsequently made a secondary upward move.

The rally stopped near $0.92.

The chapter explains that the $0.92 level had previously acted as support in late March and May.

After the support was broken, it became resistance.

When the market declined from $0.92, it indicated continued bearish control.

A downward Window appeared on June 20.

On June 21, the market failed to move above the resistance formed at the Window.

A short-selling recommendation was made at $0.9015.

The stop-loss was placed at the June 20 high of $0.9175.

The target was $0.8675, based on a previous support level from the same year.

The market declined after the recommendation.

---

## 5. Crude Oil Short-Selling Example

The crude-oil market was in a downward trend.

The trader was looking for short-selling opportunities near rallies.

A Hammer appeared during the rally beginning on June 21.

The Hammer was not used as a buying signal because the overall market trend was downward.

Several days later, a Bearish Engulfing Pattern appeared twice consecutively.

This provided evidence supporting short selling.

A small Window existed between June 15 and June 18.

The Window was considered as potential resistance if prices rallied.

The stop-loss for the short position was placed slightly above the Window at $17.65.

The target was a retest of the Hammer's low.

The market later rallied on June 25 and then declined from the resistance created by the Bearish Engulfing Pattern and the Window.

---

## 6. Hammer and Morning Star Buying Example

A Hammer appeared on June 4.

The market maintained a late-April and mid-May low near $2.65 at the close.

The same candle also formed a bullish Spring pattern because prices reached a new low and failed to maintain the new lower level.

Confirmation was required before recommending a purchase because the support at $2.65 was uncertain.

The following day, the market opened with an upward gap.

A purchase was recommended at $2.68 with a stop at $2.64 below the support line.

The target was the downward-sloping resistance line at $2.79.

A distinctive white candle following the Hammer completed a Morning Star pattern.

---

## 7. Short-Term Buying Example

In the final example, the market provided several buying signals on Friday, March 2.

The first signal was a Hammer.

The Hammer had a small body located inside the previous long white candle, forming a bullish Harami.

The Hammer's low was also supported by a support level formed in early February.

The market failed to maintain the new low, indicating that the bears had attempted to break the market but failed.

A short-term purchase was recommended on Monday, March 5 at $21.38.

The target was a retest of the late-February highs near $22.

The stop-loss was placed below the Hammer's low at $21.10.

The market moved upward toward the February 28 and March 1 highs near $21.75.

When the market failed to break the short-term resistance at that price, the stop-loss was raised to the entry price.

The stop-loss was triggered during the orderly decline on March 7.

After prices moved below the Hammer's low, the market declined sharply.