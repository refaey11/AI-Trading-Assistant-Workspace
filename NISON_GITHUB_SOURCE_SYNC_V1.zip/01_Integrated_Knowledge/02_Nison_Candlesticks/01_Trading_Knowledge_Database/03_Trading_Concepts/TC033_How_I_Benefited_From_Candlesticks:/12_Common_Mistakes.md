# 12 — Common Mistakes

## TC033 — How I Benefited From Candlesticks

### Source
Chapter 20 — How I Benefited From Candlesticks

---

## Points of Attention From Chapter 20

### 1. Do Not Treat Candlesticks as a Fixed Set of Rules

The chapter states that its purpose is not to teach a set of trading rules.

The examples demonstrate how candlestick techniques can be combined with other technical methods.

---

### 2. Consider the Overall Trend

In the crude-oil example, a Hammer appeared during a rally.

The Hammer was not used as a buying signal because the overall market trend was downward.

---

### 3. Do Not Rush Into Short Selling in an Excessively Oversold Market

In the coffee example, the market had become excessively oversold after a strong decline.

A small candle following the long black candle formed a Harami.

This warned against rushing into a short-selling position.

---

### 4. Consider Confirmation When Support Is Uncertain

In the Hammer buying example, the support level at $2.65 was uncertain.

Although the Hammer was positive, confirmation was required before recommending a purchase.

The following day, the market opened with an upward gap.

---

### 5. Consider Previous Support and Resistance

In the coffee example, the $0.92 level had previously acted as support.

After the market broke that support, the same level became resistance.

---

### 6. Monitor Failed Resistance Breakouts

In the short-term buying example, the market failed to break the short-term resistance near $21.75.

The stop-loss was then raised to the entry price.

---

## Source Limitation

This file contains only points supported by the supplied Chapter 20 material.

No additional common mistakes or trading rules have been added.