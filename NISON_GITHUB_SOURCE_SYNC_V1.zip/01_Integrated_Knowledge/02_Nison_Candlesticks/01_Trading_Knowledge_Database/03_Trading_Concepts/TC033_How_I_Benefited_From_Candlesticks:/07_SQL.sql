-- =========================================================
-- TC033 — How I Benefited From Candlesticks
-- Chapter 20
-- =========================================================


-- =========================================================
-- CONCEPT
-- =========================================================

CREATE TABLE tc033_candlestick_trading (
    id INTEGER PRIMARY KEY,
    concept_code VARCHAR(20) NOT NULL,
    concept_name VARCHAR(150) NOT NULL,
    chapter INTEGER NOT NULL
);

INSERT INTO tc033_candlestick_trading
(
    id,
    concept_code,
    concept_name,
    chapter
)
VALUES
(
    1,
    'TC033',
    'How I Benefited From Candlesticks',
    20
);


-- =========================================================
-- CHAPTER APPROACH
-- =========================================================

CREATE TABLE tc033_chapter_approach (
    id INTEGER PRIMARY KEY,
    concept_code VARCHAR(20) NOT NULL,
    item_name VARCHAR(100) NOT NULL,
    description TEXT NOT NULL
);

INSERT INTO tc033_chapter_approach
(
    id,
    concept_code,
    item_name,
    description
)
VALUES
(
    1,
    'TC033',
    'Trading Focus',
    'The examples focus on futures.'
),
(
    2,
    'Trading Style',
    'The examples reflect a short-term trading approach.'
),
(
    3,
    'Charts',
    'The examples use intraday charts and daily charts.'
),
(
    4,
    'Chapter Purpose',
    'The chapter demonstrates how candlestick techniques can be combined with other technical methods.'
);


-- =========================================================
-- CANDLESTICK SIGNALS
-- =========================================================

CREATE TABLE tc033_candlestick_signals (
    id INTEGER PRIMARY KEY,
    concept_code VARCHAR(20) NOT NULL,
    signal_name VARCHAR(100) NOT NULL,
    role TEXT
);

INSERT INTO tc033_candlestick_signals
(
    id,
    concept_code,
    signal_name,
    role
)
VALUES
(
    1,
    'TC033',
    'Bullish Engulfing Pattern',
    'Used as bullish evidence and in the covering of a short position.'
),
(
    2,
    'TC033',
    'Bearish Engulfing Pattern',
    'Used as bearish evidence supporting short selling.'
),
(
    3,
    'TC033',
    'Hammer',
    'Provided evidence of a possible turning point and was used in buying and short-selling examples.'
),
(
    4,
    'TC033',
    'Harami',
    'Warned against rushing into short selling in the coffee example.'
),
(
    5,
    'TC033',
    'Bullish Harami',
    'Provided bullish evidence in the short-term buying example.'
),
(
    6,
    'TC033',
    'White Belt Hold',
    'Provided bullish evidence in the covering of the short position.'
),
(
    7,
    'TC033',
    'Spring',
    'Provided bullish evidence when prices reached a new low and failed to maintain the new lower level.'
),
(
    8,
    'TC033',
    'Morning Star',
    'Completed after a distinctive white candle followed the Hammer.'
);


-- =========================================================
-- TECHNICAL EVIDENCE
-- =========================================================

CREATE TABLE tc033_technical_evidence (
    id INTEGER PRIMARY KEY,
    concept_code VARCHAR(20) NOT NULL,
    tool_name VARCHAR(100) NOT NULL,
    role TEXT
);

INSERT INTO tc033_technical_evidence
(
    id,
    concept_code,
    tool_name,
    role
)
VALUES
(
    1,
    'TC033',
    'Head and Shoulders',
    'The neckline break turned the market downward in the first example.'
),
(
    2,
    'TC033',
    'Support',
    'Previous support levels were used in identifying targets and resistance.'
),
(
    3,
    'TC033',
    'Resistance',
    'Previous support could become resistance after being broken.'
),
(
    4,
    'TC033',
    'Window',
    'Used as potential resistance and as evidence of further decline in the coffee example.'
),
(
    5,
    'TC033',
    'Oscillator Divergence',
    'Positive divergence indicated that the bears were losing control.'
);


-- =========================================================
-- HISTORICAL EXAMPLES
-- =========================================================

CREATE TABLE tc033_examples (
    id INTEGER PRIMARY KEY,
    concept_code VARCHAR(20) NOT NULL,
    example_code VARCHAR(20) NOT NULL,
    market VARCHAR(100),
    description TEXT
);

INSERT INTO tc033_examples
(
    id,
    concept_code,
    example_code,
    market,
    description
)
VALUES
(
    1,
    'TC033',
    '20.1',
    NULL,
    'Head and Shoulders neckline break, short selling, and later covering after bullish candlestick and oscillator evidence.'
),
(
    2,
    'TC033',
    '20.2',
    'Coffee',
    'Oversold decline, Harami, secondary rally to previous support turned resistance, Window, and short-selling recommendation.'
),
(
    3,
    'TC033',
    '20.3',
    'Crude Oil',
    'Downward trend, Hammer during a rally, two Bearish Engulfing Patterns, Window resistance, and short-selling setup.'
),
(
    4,
    'TC033',
    '20.4',
    NULL,
    'Hammer and Spring at support, upward gap, purchase recommendation, and Morning Star.'
),
(
    5,
    'TC033',
    '20.5',
    NULL,
    'Hammer, Bullish Harami, support, short-term purchase, resistance failure, and stop-loss adjustment.'
);