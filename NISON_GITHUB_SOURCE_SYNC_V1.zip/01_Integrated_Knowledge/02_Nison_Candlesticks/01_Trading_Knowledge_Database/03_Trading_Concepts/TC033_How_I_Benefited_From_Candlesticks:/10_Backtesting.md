# 10 — Backtesting

## TC033 — How I Benefited From Candlesticks

### Source
Chapter 20 — How I Benefited From Candlesticks

---

## Backtesting Information

The supplied Chapter 20 material does not provide a formal statistical backtesting study.

It does not provide:

- Win Rate.
- Profit Factor.
- Sharpe Ratio.
- Maximum Drawdown.
- Number of winning trades.
- Number of losing trades.
- Statistical performance results.

Therefore, no statistical backtesting results are attributed to Chapter 20.

---

## Historical Trade Examples

The chapter provides examples of individual trading recommendations and their subsequent market movements.

The examples include:

- Short-selling trades.
- Covering a short position.
- Buying trades.
- Short-term buying.

---

## Example 20.1

The chapter describes:

- Head and Shoulders neckline break.
- Short-selling recommendation at $6.27.
- Stop-loss at $6.35.
- Target at $5.90.
- Bullish evidence on June 18.
- Short position covered at $6.12.

---

## Example 20.2

The chapter describes:

- Coffee market decline.
- Excessively oversold condition.
- Harami.
- Secondary upward move to $0.92.
- Downward Window.
- Short-selling recommendation at $0.9015.
- Stop-loss at $0.9175.
- Target at $0.8675.
- Subsequent decline.

---

## Example 20.3

The chapter describes:

- Downward crude-oil market.
- Hammer during a rally.
- Two Bearish Engulfing Patterns.
- Window used as potential resistance.
- Stop-loss at $17.65.
- Target based on a retest of the Hammer's low.
- Subsequent decline from resistance.

---

## Example 20.4

The chapter describes:

- Hammer near $2.65 support.
- Spring-type price movement.
- Upward gap.
- Purchase at $2.68.
- Stop-loss at $2.64.
- Target at $2.79.
- Morning Star completion.

---

## Example 20.5

The chapter describes:

- Hammer.
- Bullish Harami.
- Support from early February.
- Purchase at $21.38.
- Target near $22.
- Stop-loss at $21.10.
- Resistance near $21.75.
- Stop-loss raised to the entry price.
- Stop-loss triggered during the decline.

---

## Source Limitation

The chapter provides historical trade examples but does not provide a formal statistical backtesting methodology or statistical performance results.

No additional backtesting statistics are added to this file.