# 02 — Core Rules

## TC033 — How I Benefited From Candlesticks

### Source
Chapter 20 — How I Benefited From Candlesticks

---

## 1. Candlesticks as Part of a Broader Analysis

The chapter demonstrates how candlestick techniques can be combined with other technical methods.

Candlesticks are not presented as a fixed set of trading rules.

The examples show how candlestick signals can provide additional evidence for trading decisions.

---

## 2. Short-Term Trading

The author's approach in the examples is short-term.

The examples use:

- Intraday charts.
- Daily charts.

---

## 3. Short Selling After a Bearish Setup

In the first example, the market had broken the neckline of a Head and Shoulders pattern.

The market then turned downward.

After a subsequent rise toward the neckline, a long white candle was followed by a small black candle.

The small black candle indicated that the positive effect of the previous white candle was beginning to fade.

A short-selling recommendation was then made.

---

## 4. Covering a Short Position

In the same example, the short position was covered after several bullish indications appeared.

The evidence included:

- A Bullish Engulfing Pattern.
- A Spring-type price movement.
- A bullish White Belt Hold.
- Positive divergence involving the oscillator.

The combination of these signals indicated that the environment was no longer suitable for the short-selling position.

---

## 5. Overextended Decline and Bearish Harami

In the coffee example, the market had moved below previous support levels.

A long black candle showed strong selling pressure.

However, the market was already in an excessively oversold condition.

A small candle following the long black candle formed a Harami.

This warned against rushing into a short-selling position because the previous downward movement had been balanced.

The chapter describes two possible outcomes:

- Sideways trading.
- An upward move.

---

## 6. Support Becoming Resistance

In the coffee example, the market later rallied to $0.92.

The chapter explains that previous support at $0.92 had become resistance after being broken.

When the market declined from this level, it indicated that the bears were still controlling the market.

---

## 7. Window as Bearish Evidence

The coffee market opened with a downward Window on June 20.

This indicated an expectation of further decline.

When the market failed to move above the resistance formed at the Window, a short-selling recommendation was made.

---

## 8. Bearish Engulfing in a Downtrend

In the crude-oil example, the overall market trend was downward.

A Hammer appeared during a rally, but it was not used as a buying signal because the overall market trend was bearish.

Several days later, a Bearish Engulfing Pattern appeared twice consecutively.

This was used as evidence supporting short selling.

---

## 9. Confirmation of a Hammer

In another example, a Hammer appeared at a support level.

Although the Hammer was positive, confirmation was required before recommending a purchase because the support level was uncertain.

The following day, the market opened with an upward gap.

A buying recommendation was then made with a stop below the support level.

A distinctive white candle following the Hammer completed a Morning Star pattern.

---

## 10. Multiple Buying Signals

In the final example, a Hammer provided a buying signal.

The Hammer's small body was inside the previous long white candle, forming a bullish Harami.

Additional support came from:

- A support level formed in early February.
- Failure of the market to maintain the new low.

The combination indicated that the bears had attempted to break the market but had failed.

---

## 11. Managing a Short-Term Trade

In the final example, the short-term buying target was a retest of previous highs.

After the market failed to break short-term resistance, the stop-loss was raised to the entry price.

The stop was triggered during the subsequent orderly decline.

After prices moved below the Hammer's low, the market declined sharply.