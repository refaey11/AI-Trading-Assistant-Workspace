# TC008 - Backtesting

## Goal

Measure whether Multi-Timeframe Confirmation improves trading performance.

---

## Data to Record

Trade Number

Date

Asset

Higher Timeframe

Lower Timeframe

Primary Trend

Candlestick Pattern

Entry

Stop Loss

Target

Exit

Result

R-Multiple

Comments

---

## Metrics

Win Rate

Average Reward

Average Risk

Maximum Drawdown

Profit Factor

Expectancy

Average Holding Time

Confidence Score Accuracy