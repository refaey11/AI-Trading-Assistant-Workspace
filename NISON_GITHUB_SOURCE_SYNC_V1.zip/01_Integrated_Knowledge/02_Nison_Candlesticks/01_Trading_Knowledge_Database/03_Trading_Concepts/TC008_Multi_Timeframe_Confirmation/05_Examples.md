# TC008 - Examples

---

## Example 1

### Market

Bullish Reversal

### Higher Timeframe

Daily Chart

Hammer formed at a major support level.

### Lower Timeframe

1H Chart

Hammer formed at the same support area.

### Result

The market reversed strongly.

---

## Example 2

### Market

Bearish Reversal

### Higher Timeframe

Daily Chart

Shooting Star formed at resistance.

### Lower Timeframe

4H Chart

Bearish Engulfing appeared immediately after.

### Result

The market started a new bearish leg.

---

## Example 3

### Market

Chapter 12

Figure 12.6

### Daily Chart

Hammer

### Hourly Chart

Hammer

### Confluence

- Retracement Support
- Two Timeframes
- Same Bullish Message

### Result

Strong bullish continuation.

Later,

A Hanging Man warned that bullish momentum was weakening.

The rally stalled shortly afterward.