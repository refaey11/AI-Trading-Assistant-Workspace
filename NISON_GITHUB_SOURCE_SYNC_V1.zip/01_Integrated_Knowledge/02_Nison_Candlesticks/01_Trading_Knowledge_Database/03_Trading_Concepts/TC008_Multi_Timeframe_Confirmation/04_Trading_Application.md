# TC008 - Trading Application

## Step 1

Determine the primary trend using the higher timeframe.

Example:

Daily Chart

---

## Step 2

Mark important areas.

- Support
- Resistance
- Trendlines
- Retracement Levels

---

## Step 3

Move to the lower timeframe.

Example:

1H or 4H Chart.

---

## Step 4

Wait for confirmation.

Examples:

Bullish

- Hammer
- Morning Star
- Bullish Engulfing

Bearish

- Shooting Star
- Evening Star
- Bearish Engulfing

---

## Step 5

Enter only after confirmation closes.

Never anticipate.

---

## Step 6

Place Stop Loss

Bullish:

Below confirmation candle.

Bearish:

Above confirmation candle.

---

## Step 7

Manage the trade according to the higher timeframe trend.

Never let a lower timeframe signal override a strong higher timeframe trend.

---

## Professional Workflow

Higher Timeframe

↓

Market Structure

↓

Lower Timeframe Confirmation

↓

Entry

↓

Risk Management

↓

Exit