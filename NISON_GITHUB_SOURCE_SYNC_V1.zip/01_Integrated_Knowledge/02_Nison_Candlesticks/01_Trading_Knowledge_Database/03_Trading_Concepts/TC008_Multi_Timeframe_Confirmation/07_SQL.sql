CREATE TABLE multi_timeframe_confirmation (

    id INTEGER PRIMARY KEY,

    concept_code TEXT,

    higher_timeframe TEXT,

    lower_timeframe TEXT,

    market_bias TEXT,

    support_resistance TEXT,

    candlestick_pattern TEXT,

    confirmation_status TEXT,

    entry_rule TEXT,

    stop_loss_rule TEXT,

    target_rule TEXT,

    confidence_level TEXT,

    notes TEXT

);