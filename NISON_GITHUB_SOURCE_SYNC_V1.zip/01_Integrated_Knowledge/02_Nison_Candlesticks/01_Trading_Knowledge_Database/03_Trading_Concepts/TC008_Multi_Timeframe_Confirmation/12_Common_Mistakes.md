# TC008 - Common Mistakes

## Mistake 1

Trading using only the lower timeframe.

---

## Mistake 2

Ignoring the higher timeframe trend.

---

## Mistake 3

Entering before candlestick confirmation closes.

---

## Mistake 4

Confusing retracement with trend reversal.

---

## Mistake 5

Giving equal weight to all timeframes.

Higher timeframes always carry more importance.

---

## Mistake 6

Ignoring support and resistance.

---

## Mistake 7

Assuming multi-timeframe confirmation guarantees success.

It increases probability.

It never guarantees the outcome.