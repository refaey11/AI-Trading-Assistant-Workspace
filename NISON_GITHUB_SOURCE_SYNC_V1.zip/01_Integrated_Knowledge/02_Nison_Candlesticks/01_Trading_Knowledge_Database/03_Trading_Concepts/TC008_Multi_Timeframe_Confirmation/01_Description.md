# TC008 - Multi-Timeframe Confirmation

## Name

Multi-Timeframe Confirmation

---

## Category

Candlestick Analysis

Trend Confirmation

Multi-Timeframe Analysis

---

## Source

Steve Nison

Beyond Candlesticks

Chapter 12

Figure 12.6

---

## Definition

Multi-Timeframe Confirmation occurs when the same market message appears across two or more timeframes.

Example:

Daily Chart

↓

Hammer

AND

Hourly Chart

↓

Hammer

The agreement between multiple timeframes significantly increases the probability that the reversal is genuine.

---

## Objective

Improve trading accuracy by confirming the same market signal on higher and lower timeframes before entering a trade.

---

## Core Principle

Higher Timeframe

↓

Lower Timeframe

↓

Same Market Message

↓

Higher Confidence

---

## Typical Combinations

Weekly + Daily

Daily + 4H

Daily + 1H

4H + 1H

---

## Professional Principle

One timeframe identifies the opportunity.

Multiple timeframes validate the opportunity.