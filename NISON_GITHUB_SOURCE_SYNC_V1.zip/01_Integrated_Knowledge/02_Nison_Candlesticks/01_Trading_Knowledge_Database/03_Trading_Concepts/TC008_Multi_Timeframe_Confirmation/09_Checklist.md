# TC008 - Trading Checklist

□ Higher timeframe trend identified.

□ Major support or resistance marked.

□ Lower timeframe analyzed.

□ Candlestick confirmation detected.

□ Both timeframes agree.

□ Entry after candle close.

□ Stop Loss defined.

□ Risk / Reward acceptable.

□ Position size calculated.

□ Trade recorded.