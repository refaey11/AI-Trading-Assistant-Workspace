# TC008 - Confidence Model

## Base Score

Higher timeframe trend identified

+20

Support / Resistance identified

+20

Lower timeframe confirmation

+20

Candlestick confirmation

+20

Trend alignment

+10

Good Risk / Reward

+10

---

## Final Score

90–100

Very High Confidence

70–89

High Confidence

50–69

Moderate Confidence

Below 50

Avoid Trade