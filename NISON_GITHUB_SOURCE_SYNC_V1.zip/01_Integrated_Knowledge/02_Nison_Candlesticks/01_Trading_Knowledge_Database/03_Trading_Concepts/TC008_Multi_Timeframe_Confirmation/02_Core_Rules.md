# TC008 - Core Rules

## Rule 1

Always analyze the higher timeframe first.

---

## Rule 2

The lower timeframe must confirm the higher timeframe.

---

## Rule 3

Conflicting signals reduce trade quality.

---

## Rule 4

Matching candlestick patterns increase confidence.

---

## Rule 5

The higher timeframe has priority.

---

## Rule 6

Never ignore higher timeframe support or resistance.

---

## Rule 7

Multi-Timeframe analysis improves probability.

It never guarantees success.

---

## Rule 8

The strongest setups occur when:

Trend

+

Retracement

+

Candlestick

+

Multiple Timeframes

all agree.