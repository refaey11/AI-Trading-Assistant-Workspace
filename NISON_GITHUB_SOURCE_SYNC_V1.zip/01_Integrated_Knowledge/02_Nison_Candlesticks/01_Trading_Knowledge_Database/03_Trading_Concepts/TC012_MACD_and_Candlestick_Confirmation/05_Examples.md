# TC012 - Examples

Example 1

Figure 13.7

Hammer formed.

Golden Cross appeared.

Bullish reversal confirmed.

---

Example 2

Figure 13.7

Dark Cloud Cover appeared.

Death Cross followed.

Bearish continuation confirmed.

---

Example 3

Figure 13.8

Morning Star formed.

Bullish MACD crossover appeared.

Market established a major bottom.

---

Example 4

Histogram remained below zero.

Price rallied.

Bearish candlestick appeared.

Momentum failed to confirm.

Continuation downward.