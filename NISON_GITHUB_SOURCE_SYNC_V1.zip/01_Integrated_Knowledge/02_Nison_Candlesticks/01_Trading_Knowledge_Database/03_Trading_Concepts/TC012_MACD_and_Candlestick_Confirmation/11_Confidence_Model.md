# TC012 - Confidence Model

Trend Alignment +20

MACD Cross +20

Histogram Confirmation +15

Candlestick Pattern +20

Support / Resistance +15

Risk / Reward +10

90–100 = Very High

70–89 = High

50–69 = Moderate

Below 50 = Avoid