# TC012 - Common Mistakes

- Trading every MACD crossover.

- Ignoring Histogram.

- Ignoring Candlestick Confirmation.

- Ignoring higher timeframe trend.

- Using MACD in sideways markets.

- Entering before candle closes.

- Treating MACD as a leading indicator.

Professional Rule

MACD confirms momentum.

Candlesticks determine execution.

Price remains the primary source of truth.