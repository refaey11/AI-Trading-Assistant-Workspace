# TC012 - Trading Application

Bullish Setup

Trend

↓

Hammer

↓

Bullish MACD Cross

↓

Entry

↓

Risk Management

---

Bearish Setup

Trend

↓

Shooting Star

↓

Bearish MACD Cross

↓

Entry

↓

Risk Management

---

Professional Rule

Candlestick triggers the setup.

MACD confirms momentum.

Never reverse the order.