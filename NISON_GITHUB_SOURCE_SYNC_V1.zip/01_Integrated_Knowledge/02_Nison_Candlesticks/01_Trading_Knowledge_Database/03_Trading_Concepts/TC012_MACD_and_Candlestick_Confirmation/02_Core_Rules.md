# TC012 - Core Rules

Rule 1

Bullish MACD crossover supports bullish candlestick signals.

---

Rule 2

Bearish MACD crossover supports bearish candlestick signals.

---

Rule 3

Histogram above zero indicates bullish momentum.

---

Rule 4

Histogram below zero indicates bearish momentum.

---

Rule 5

MACD confirmation is stronger when it agrees with market trend.

---

Rule 6

Ignore MACD crossovers against higher timeframe trend.

---

Rule 7

Momentum confirmation increases confidence but never replaces price action.