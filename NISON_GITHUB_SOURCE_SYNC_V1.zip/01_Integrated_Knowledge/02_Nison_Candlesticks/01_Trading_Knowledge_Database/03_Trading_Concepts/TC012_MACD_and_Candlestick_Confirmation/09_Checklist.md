# TC012 - Checklist

□ Trend identified

□ MACD crossover confirmed

□ Histogram checked

□ Candlestick confirmation

□ Support / Resistance checked

□ Entry confirmed

□ Stop Loss defined

□ Risk / Reward acceptable

□ Trade documented