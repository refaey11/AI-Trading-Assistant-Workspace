# TC012 - MACD and Candlestick Confirmation

## Name

MACD and Candlestick Confirmation

---

## Category

Momentum Confirmation

Trend Following

Oscillator Confirmation

---

## Source

Steve Nison

Beyond Candlesticks

Chapter 13

Figures 13.7 – 13.8

---

## Definition

The Moving Average Convergence Divergence (MACD) measures trend momentum by comparing two Exponential Moving Averages (EMAs).

When combined with Japanese Candlestick patterns, MACD helps distinguish between high-quality and low-quality reversal signals.

---

## Objective

- Confirm trend reversals.
- Measure momentum strength.
- Validate candlestick patterns.
- Reduce false trading signals.

---

## Components

- MACD Line
- Signal Line
- Histogram

---

## Core Principle

Momentum should confirm price action.

Candlesticks provide timing.

MACD provides momentum confirmation.