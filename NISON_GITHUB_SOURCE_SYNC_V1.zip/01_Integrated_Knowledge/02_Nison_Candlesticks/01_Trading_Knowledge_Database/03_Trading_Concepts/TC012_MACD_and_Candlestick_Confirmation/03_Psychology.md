# TC012 - Market Psychology

MACD measures the speed of buyers and sellers.

A crossover indicates that one side is gaining momentum.

---

Bullish MACD

Buyers accelerate faster than sellers.

Momentum begins shifting upward.

---

Bearish MACD

Sellers dominate.

Momentum weakens.

Institutions begin reducing long exposure.

---

Histogram

Positive Histogram

Bullish momentum dominates.

Negative Histogram

Bearish momentum dominates.

---

Professional View

Momentum confirms conviction.

Price tells us what happened.

MACD tells us how strong it happened.