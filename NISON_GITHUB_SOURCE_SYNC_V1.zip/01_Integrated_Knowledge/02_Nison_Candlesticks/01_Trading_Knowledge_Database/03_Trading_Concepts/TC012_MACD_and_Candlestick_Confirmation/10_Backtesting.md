# TC012 - Backtesting

Record

- Date
- Asset
- MACD Signal
- Histogram
- Candlestick
- Trend
- Entry
- Exit
- Result
- R Multiple

Metrics

- Win Rate
- Expectancy
- Profit Factor
- Maximum Drawdown