CREATE TABLE macd_confirmation (

id INTEGER PRIMARY KEY,

concept_code TEXT,

macd_signal TEXT,

histogram TEXT,

trend TEXT,

candlestick_pattern TEXT,

entry_rule TEXT,

stop_loss_rule TEXT,

target_rule TEXT,

confidence_level TEXT,

notes TEXT

);