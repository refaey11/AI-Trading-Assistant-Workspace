Case 01 — Figure 14.1: Copper-May 1990, Daily

Case Overview

This case study shows how the Relative Strength Index (RSI) can be combined with Japanese candlestick signals to identify both bullish and bearish reversal warnings.

The main lesson is that RSI divergence can strengthen a candlestick signal, while candlesticks can sometimes provide an earlier warning than the RSI confirmation.



1. Bullish Setup in January

During the decline in January, the market formed a price low on January 24.

At that point, the RSI reading was approximately 28.

On January 31, the market formed a lower price low, which became the lowest point of the decline. However, the RSI reading was approximately 39, higher than its reading on January 24.

Divergence Structure

	●	Price → Lower Low
	●	RSI → Higher Low
	●	Result → Bullish RSI Divergence

This indicated that the selling pressure was weakening even though price was making a new low.



2. Bullish Candlestick Confirmation

The January 31 session also produced a Bullish Engulfing Pattern.

The white candlestick engulfed the previous black candlestick.

This provided additional bullish confirmation alongside the positive RSI divergence.

Combined Signal

	●	Bullish RSI Divergence
	●	Bullish Engulfing Pattern
	●	New price low
	●	RSI failed to make a new low

Interpretation

The combination suggested that the previous decline was losing momentum and that a bullish reversal was becoming more likely.



3. Bearish Warning in March

On March 14, a Doji appeared.

The following candlestick was similar to a Hanging Man, although its lower shadow was not long enough to qualify as a perfect Hanging Man.

These candlesticks provided warning signals that the previous advance could be losing strength.



4. Bearish RSI Divergence

The market reached new price highs on March 15 and March 16.

However, RSI failed to reach corresponding new highs.

Divergence Structure

	●	Price → Higher High
	●	RSI → Lower High
	●	Result → Bearish RSI Divergence

This indicated weakening internal momentum despite the new price highs.

The divergence was especially important because it appeared at the same time as bearish candlestick warnings.



5. Further Confirmation

The market made another strong advance on March 21 and reached a new price high.

However, RSI continued to decline rather than confirming the new price extreme.

This provided additional evidence of weakening momentum.

The market subsequently experienced an orderly correction toward the March support area near $1.11.



6. Key Lessons

Bullish RSI Divergence

Price Lower Low + RSI Higher Low → Bullish Divergence

The January example became stronger because the divergence was accompanied by a Bullish Engulfing candlestick.

Bearish RSI Divergence

Price Higher High + RSI Lower High → Bearish Divergence

The March example became stronger because the divergence appeared together with a Doji and a Hanging-Man-like warning.

Confirmation Principle

RSI divergence should not be treated as an isolated trading signal.

A stronger setup occurs when:

	●	Price reaches an important extreme.
	●	RSI fails to confirm that extreme.
	●	A Japanese candlestick pattern provides reversal evidence.
	●	The broader market context supports the interpretation.



7. Trading Interpretation

The important concept in this case is confluence.

Neither the candlestick pattern nor the RSI divergence should automatically be treated as a guaranteed reversal.

The strongest evidence came from the combination:

Price Extreme + RSI Divergence + Candlestick Signal

January

Lower Low + Higher RSI Low + Bullish Engulfing → Bullish Reversal Evidence

March

Higher High + Lower RSI High + Doji/Hanging-Man-like Warning → Bearish Reversal Evidence



8. Source Reference

	●	Exhibit: 14.1
	●	Market: Copper-May 1990
	●	Timeframe: Daily
	●	Primary indicator: RSI
	●	Complementary analysis: Japanese Candlesticks