# Case 02 — Figure 14.2: Wheat-May 1990, Daily

## Case Overview

This case study shows how RSI divergence can strengthen a Japanese candlestick reversal signal.

The main lesson is that a candlestick pattern may provide an early reversal warning, while RSI can provide additional confirmation through divergence, trendline support, and a later breakout above a previous RSI high.

────────

## 1. Bearish Reversal Setup

The previous decline began after a Bearish Engulfing Pattern.

This bearish candlestick signal indicated that selling pressure had become dominant and that the market was entering a declining phase.

However, the decline eventually reached a point where the market began showing evidence that the selling pressure was weakening.

────────

## 2. Bullish Candlestick Reversal

The decline stopped at a Piercing Pattern.

The Piercing Pattern provided a bullish reversal warning and suggested that the previous decline could be losing strength.

This created the initial bullish evidence from the candlestick analysis.

────────

## 3. Bullish RSI Divergence

The bullish candlestick signal received additional support from RSI.

The market later formed a lower price low on March 29.

However, RSI did not confirm the new price low.

Divergence Structure

• Price → Lower Low
• RSI → Higher Low
• Result → Bullish RSI Divergence

This indicated that the internal momentum of the decline was weakening even though price was still making lower lows.

────────

## 4. RSI Trendline Support

Another important confirmation came from the RSI trendline.

The RSI maintained its upward trendline, which also acted as support.

This occurred even though the market formed a lower price low on March 29.

The ability of RSI to remain above its rising support line provided additional evidence that downside momentum was weakening.

────────

## 5. RSI Breakout Confirmation

Some analysts consider RSI to provide a bullish signal when it moves above its previous RSI high.

In this example, RSI needed to break above the level it had reached on April 20, marked as point A.

When RSI eventually moved above that previous high at point B, it provided another bullish confirmation.

Signal Structure

• Point A → Previous RSI High
• Point B → RSI Breakout Above Previous High
• Result → Additional Bullish Confirmation

────────

## 6. Candlestick + RSI Confluence

The candlestick analysis provided an earlier bullish warning than the RSI breakout confirmation.

The bullish evidence consisted of:

• Piercing Pattern
• Bullish RSI Divergence
• Rising RSI Trendline
• RSI Breakout Above Previous High

The combination of these signals strengthened the interpretation that the previous decline was approaching an end.

────────

## 7. Key Lessons

### Rule 01 — Bullish RSI Divergence

Price Lower Low + RSI Higher Low → Bullish Divergence

The divergence suggests that selling pressure is weakening despite the new price low.

### Rule 02 — RSI Trendline Support

Price makes a lower low + RSI maintains its rising trendline → Additional Bullish Evidence

An RSI trendline can act as support and provide additional confirmation of weakening downside momentum.

### Rule 03 — RSI Breakout Confirmation

RSI breaks above its previous high → Bullish Confirmation

A breakout above a previous RSI high can provide confirmation after a bullish divergence has already appeared.

### Rule 04 — Candlesticks Can Lead RSI Confirmation

A bullish candlestick pattern may appear before RSI gives its later confirmation signal.

Therefore, waiting only for the RSI breakout may result in entering later than the initial candlestick reversal signal.

────────

## 8. Trading Interpretation

The important concept in this case is confluence.

The strongest bullish evidence came from combining:

Candlestick Reversal + RSI Divergence + RSI Trendline Support + RSI Breakout

The sequence was:

Bearish Engulfing → Decline → Piercing Pattern → Lower Price Low → Higher RSI Low → RSI Trendline Support → RSI Breakout Above Previous High

This combination provided increasing evidence that the previous bearish trend was losing strength and that a bullish reversal was becoming more likely.

────────

## 9. Source Reference

• Exhibit: 14.2
• Market: Wheat-May 1990
• Timeframe: Daily
• Primary indicator: RSI
• Candlestick analysis: Japanese Candlesticks
• Main concept: Bullish RSI Divergence
• Additional confirmation: RSI Trendline Support + RSI Breakout