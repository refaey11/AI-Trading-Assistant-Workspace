# Case 03 — Figure 14.3: Dow Jones Industrial Average

## Case Overview

This case study demonstrates how RSI can be used to confirm weakness in an advancing market when combined with Japanese candlestick signals.

The main lesson is that a market can continue making new highs while RSI shows weakening internal momentum. When this bearish RSI divergence appears together with bearish candlestick signals, the reversal warning becomes stronger.

────────

## 1. Initial Warning — Area A

In mid-May, the market formed a Shooting Star followed by several Doji candlesticks.

These candlestick signals warned that the previous advance was losing strength.

The advance ended temporarily and the market entered a sideways period during the following weeks.

Area A therefore provided the first warning that the bullish trend was becoming vulnerable.

────────

## 2. New Price High — Area B

After the sideways consolidation, the market began another strong advance.

Prices eventually reached a new high at area B.

The high at B was approximately 100 points above the high at area A.

However, RSI did not increase along with price.

The RSI readings at A and B were approximately equal.

This indicated that the additional price advance was not accompanied by stronger internal momentum.

Interpretation

• Price → Higher High
• RSI → No New High
• Result → Weakening Internal Momentum

────────

## 3. Additional Candlestick Warning at B

A Bearish Harami appeared at area B.

The Bearish Harami provided another warning that the market's upward movement was becoming vulnerable.

The combination of:

• Higher Price High
• Weak RSI Confirmation
• Bearish Harami

increased the probability that the advance was losing momentum.

────────

## 4. Correction After Area B

Following the high at B, the market experienced a correction of approximately 100 points.

After this correction, the market began another advance.

This recovery eventually pushed prices toward the 3000 level at area C.

────────

## 5. Bearish RSI Divergence — Area C

At area C, the market reached a new price high above the previous high at B.

However, RSI was significantly lower than it had been at B.

Divergence Structure

• Price → Higher High
• RSI → Lower High
• Result → Bearish RSI Divergence

This was a stronger warning than the earlier RSI weakness at area B because RSI now clearly failed to confirm the new price extreme.

The divergence indicated that the internal strength of the market was deteriorating despite continued price appreciation.

────────

## 6. Candlestick Confirmation at C

The bearish RSI divergence at C was accompanied by several bearish candlestick signals:

• Shooting Star
• Doji
• Hanging Man

These patterns provided additional evidence that the market was vulnerable near the new price high.

The combination created a strong technical warning.

Signal Structure

Higher Price High + Lower RSI High + Bearish Candlesticks → Strong Bearish Reversal Evidence

────────

## 7. Key Lessons

### Rule 01 — RSI Divergence at New Highs

Price Higher High + RSI Lower High → Bearish RSI Divergence

The divergence indicates weakening internal momentum.

### Rule 02 — Equal RSI Readings Can Also Warn of Weakness

Price makes a significantly higher high while RSI remains approximately unchanged → Internal Momentum Weakness

The market is advancing, but RSI is not confirming the strength of that advance.

### Rule 03 — Candlesticks Strengthen RSI Evidence

RSI divergence becomes more meaningful when it appears together with bearish candlestick patterns.

Examples in this case:

• Shooting Star
• Doji
• Bearish Harami
• Hanging Man

### Rule 04 — Multiple Warnings Increase Confluence

A single bearish signal should not automatically be treated as a reversal.

The evidence becomes stronger when several independent signals point toward the same conclusion.

────────

## 8. Trading Interpretation

The case demonstrates a progression of bearish warnings.

Area A

Shooting Star + Doji → Initial Warning

Area B

Higher Price High + Weak RSI Confirmation + Bearish Harami → Increasing Weakness

Area C

Higher Price High + Lower RSI High + Shooting Star + Doji + Hanging Man → Strong Bearish Evidence

The most important signal occurred at C because the market reached a new high while RSI made a significantly lower high.

This bearish divergence showed that the internal strength of the market was weakening even though price continued upward.

────────

## 9. Source Reference

• Exhibit: 14.3
• Market: Dow Jones Industrial Average
• Primary indicator: RSI
• Complementary analysis: Japanese Candlesticks
• Main concept: Bearish RSI Divergence
• Additional concepts: RSI Confirmation + Candlestick Confluence