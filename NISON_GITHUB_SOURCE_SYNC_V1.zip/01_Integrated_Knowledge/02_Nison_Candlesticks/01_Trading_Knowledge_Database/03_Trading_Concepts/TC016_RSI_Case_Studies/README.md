# TC016 — RSI Case Studies

## Source
Steve Nison — Japanese Candlestick Charting Techniques

## Chapter
Chapter 14 — Candlesticks and Oscillators

## Topic
Relative Strength Index (RSI) — Case Studies

## Purpose
This folder contains practical case studies showing how RSI divergences and candlestick patterns can be combined to confirm bullish and bearish market signals.

## Case Studies

### Case 01 — Copper
**Exhibit 14.1 — Copper-May 1990, Daily**

Focus:
- Bullish RSI divergence
- Bearish RSI divergence
- Candlestick confirmation
- Bullish Engulfing
- Doji
- Hanging Man
- Price vs RSI divergence

### Case 02 — Wheat
**Exhibit 14.2 — Wheat-May 1990, Daily**

Focus:
- Bullish RSI divergence
- Piercing Pattern
- RSI trendline/support
- Candlestick signal appearing before RSI confirmation
- Confirmation through previous RSI high

### Case 03 — Dow Jones
**Exhibit 14.3 — Dow Jones Industrial Average**

Focus:
- RSI as confirmation tool
- Bearish divergence
- Shooting Star
- Doji
- Hanging Man
- Internal market weakness
- Higher price highs with weaker RSI