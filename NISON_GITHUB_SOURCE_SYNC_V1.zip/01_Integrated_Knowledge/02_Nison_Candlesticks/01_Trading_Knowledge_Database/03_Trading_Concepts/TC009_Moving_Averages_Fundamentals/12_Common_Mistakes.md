# TC009 - Common Mistakes

## Mistake 1

Using Moving Averages in sideways markets.

---

## Mistake 2

Ignoring the slope of the Moving Average.

---

## Mistake 3

Trading every Moving Average crossover without confirmation.

---

## Mistake 4

Using one Moving Average without considering market structure.

---

## Mistake 5

Entering before candlestick confirmation.

---

## Mistake 6

Using an unsuitable Moving Average period for the trading style.

---

## Mistake 7

Treating Moving Averages as exact support or resistance levels.

They represent dynamic zones, not precise prices.

---

## Professional Advice

Always combine:

- Market Structure
- Moving Average
- Candlestick Confirmation
- Risk Management

Never rely on the Moving Average alone.