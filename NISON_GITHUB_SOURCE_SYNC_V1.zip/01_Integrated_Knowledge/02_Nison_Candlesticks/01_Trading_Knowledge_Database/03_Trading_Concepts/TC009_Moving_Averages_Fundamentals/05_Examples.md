# TC009 - Examples

---

## Example 1

### Market

Bullish Trend

### Setup

Price remained above the 65-period Moving Average.

The market pulled back toward the Moving Average.

A Hammer formed directly on the Moving Average.

### Result

The Moving Average acted as Dynamic Support.

The bullish trend resumed.

---

## Example 2

### Market

Bearish Trend

### Setup

Price rallied toward the 65-period Moving Average.

A Dark Cloud Cover appeared at the Moving Average.

### Result

The Moving Average acted as Dynamic Resistance.

The bearish trend continued.

---

## Example 3

### Market

Sideways Market

### Setup

Price crossed above and below the Moving Average repeatedly.

No clear trend existed.

### Result

Multiple false signals occurred.

Moving Averages performed poorly.

---

## Example 4

### Market

Chapter 13

Figure 13.1

### Setup

65-Day Moving Average

Bullish Engulfing

Hammer

Harami

Hammer-like Candle

### Result

The Moving Average provided Dynamic Support.

Candlestick confirmation validated the support.

---

## Example 5

### Market

Chapter 13

Figure 13.2

### Setup

Price failed to reclaim the 65-Day Moving Average.

Dark Cloud Cover formed.

### Result

Dynamic Resistance successfully rejected price.

The bearish trend resumed.