# TC009 - Core Rules

## Rule 1

Price above the Moving Average indicates bullish market conditions.

---

## Rule 2

Price below the Moving Average indicates bearish market conditions.

---

## Rule 3

Moving averages work best during trending markets.

---

## Rule 4

They perform poorly during sideways markets.

---

## Rule 5

Short-period averages react faster but generate more false signals.

---

## Rule 6

Long-period averages react slower but provide more reliable trend confirmation.

---

## Rule 7

Moving averages can act as dynamic support or resistance.

---

## Rule 8

The slope of the Moving Average is often more important than price crossing it.

A rising Moving Average suggests bullish momentum.

A falling Moving Average suggests bearish momentum.