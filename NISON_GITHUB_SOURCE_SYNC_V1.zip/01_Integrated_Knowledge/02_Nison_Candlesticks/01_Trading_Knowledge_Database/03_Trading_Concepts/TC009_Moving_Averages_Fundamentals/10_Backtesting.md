# TC009 - Backtesting

## Goal

Measure the effectiveness of Moving Average trend-following strategies.

---

## Data to Record

Trade Number

Date

Asset

Moving Average Type

Moving Average Period

Trend Direction

Support / Resistance

Candlestick Pattern

Entry

Stop Loss

Target

Exit

Result

R-Multiple

Comments

---

## Metrics

Win Rate

Average Reward

Average Risk

Maximum Drawdown

Profit Factor

Expectancy

Average Holding Time

False Signal Rate