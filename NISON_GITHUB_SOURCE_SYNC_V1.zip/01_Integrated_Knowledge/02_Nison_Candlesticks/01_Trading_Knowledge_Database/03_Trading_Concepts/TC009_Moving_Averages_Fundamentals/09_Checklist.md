# TC009 - Trading Checklist

□ Moving Average identified.

□ Correct period selected.

□ Market trend identified.

□ Price above or below Moving Average confirmed.

□ Dynamic Support or Resistance identified.

□ Candlestick confirmation exists.

□ Moving Average slope checked.

□ Risk / Reward acceptable.

□ Stop Loss defined.

□ Position size calculated.

□ Trade documented.