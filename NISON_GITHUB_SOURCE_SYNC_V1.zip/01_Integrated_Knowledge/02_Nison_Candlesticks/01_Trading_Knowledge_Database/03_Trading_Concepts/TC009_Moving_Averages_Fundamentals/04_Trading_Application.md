# TC009 - Trading Application

## Application 1

### Trend Identification

If price closes above the selected Moving Average:

→ Bullish Bias

If price closes below the selected Moving Average:

→ Bearish Bias

---

## Application 2

### Dynamic Support

During an uptrend:

Wait for price to retrace toward the Moving Average.

Look for bullish confirmation before entering.

---

## Application 3

### Dynamic Resistance

During a downtrend:

Wait for price to rally toward the Moving Average.

Look for bearish confirmation before entering.

---

## Application 4

### Trend Filter

Only take Long positions when price remains above the Moving Average.

Only take Short positions when price remains below the Moving Average.

---

## Application 5

### Trend Strength

Observe the slope of the Moving Average.

Strong upward slope:

Strong bullish trend.

Strong downward slope:

Strong bearish trend.

Flat Moving Average:

Sideways market.

---

## Professional Workflow

Identify Trend

↓

Mark Moving Average

↓

Wait for Pullback

↓

Look for Candlestick Confirmation

↓

Enter Trade

↓

Manage Risk