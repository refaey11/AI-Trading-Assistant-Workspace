# TC009 - Market Psychology

## Why Moving Averages Work

Moving averages work because they represent the average opinion of market participants over a selected period.

Instead of reacting to every price fluctuation, they smooth market noise and reveal the dominant trend.

---

## Bullish Psychology

When price remains above the Moving Average:

- Buyers are consistently willing to pay higher prices.
- Market confidence increases.
- Institutions continue accumulating positions.
- Pullbacks toward the Moving Average are often viewed as buying opportunities.

---

## Bearish Psychology

When price remains below the Moving Average:

- Sellers control the market.
- Confidence weakens.
- Institutions distribute positions.
- Rallies toward the Moving Average are often viewed as selling opportunities.

---

## Dynamic Support & Resistance

Unlike horizontal support and resistance, Moving Averages move with the market.

As long as traders respect the average price, it becomes a dynamic area where buying or selling pressure repeatedly appears.

---

## Market Noise

Every market contains random fluctuations.

The Moving Average filters these fluctuations and helps traders focus on the primary trend instead of reacting emotionally to every candle.

---

## Professional Mindset

Professionals do not trade every price movement.

They trade the dominant trend.

The Moving Average helps distinguish between temporary corrections and genuine trend changes.