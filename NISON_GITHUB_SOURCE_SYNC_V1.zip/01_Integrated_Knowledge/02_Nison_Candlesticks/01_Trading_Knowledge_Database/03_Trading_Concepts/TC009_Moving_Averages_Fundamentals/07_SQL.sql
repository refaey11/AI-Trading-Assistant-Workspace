CREATE TABLE moving_average_fundamentals (

    id INTEGER PRIMARY KEY,

    concept_code TEXT,

    moving_average_type TEXT,

    period INTEGER,

    market_condition TEXT,

    application TEXT,

    support_resistance TEXT,

    trend_direction TEXT,

    confirmation_pattern TEXT,

    confidence_level TEXT,

    notes TEXT

);