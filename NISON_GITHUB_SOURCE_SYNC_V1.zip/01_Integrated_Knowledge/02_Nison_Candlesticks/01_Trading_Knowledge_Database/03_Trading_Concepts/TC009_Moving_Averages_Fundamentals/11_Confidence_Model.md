# TC009 - Confidence Model

## Base Score

Trend identified

+20

Price above / below Moving Average

+20

Moving Average slope confirms trend

+20

Dynamic Support / Resistance

+15

Candlestick Confirmation

+15

Risk / Reward acceptable

+10

---

## Final Score

90–100

Very High Confidence

70–89

High Confidence

50–69

Moderate Confidence

Below 50

Avoid Trade