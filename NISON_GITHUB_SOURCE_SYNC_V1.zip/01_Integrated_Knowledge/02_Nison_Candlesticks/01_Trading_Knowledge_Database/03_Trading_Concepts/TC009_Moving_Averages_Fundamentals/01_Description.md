# TC009 - Moving Averages Fundamentals

## Name

Moving Averages Fundamentals

---

## Category

Trend Following

Dynamic Support & Resistance

Trend Identification

---

## Source

Steve Nison

Beyond Candlesticks

Chapter 13

---

## Definition

A Moving Average is a trend-following technical indicator that smooths price data by calculating the average price over a specified number of periods.

It helps traders identify the direction of the market while filtering short-term price fluctuations.

---

## Objective

- Identify the primary trend.
- Filter market noise.
- Detect dynamic support and resistance.
- Improve trading decisions using trend confirmation.

---

## Types of Moving Averages

### Simple Moving Average (SMA)

Calculates the arithmetic average of prices over a fixed number of periods.

---

### Weighted Moving Average (WMA)

Assigns greater weight to recent prices.

Recent market activity has more influence.

---

### Exponential Moving Average (EMA)

Applies exponential weighting to recent prices while still considering older prices.

More responsive than SMA.

---

## Characteristics

Moving averages are lagging indicators.

They confirm trend changes after price has already started moving.

---

## Main Uses

- Trend Identification
- Dynamic Support
- Dynamic Resistance
- Momentum Analysis
- Trend Following Systems