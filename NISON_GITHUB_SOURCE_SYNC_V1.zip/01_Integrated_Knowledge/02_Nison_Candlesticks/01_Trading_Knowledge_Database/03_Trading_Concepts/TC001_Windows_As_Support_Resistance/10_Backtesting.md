# TC001 — Windows as Support and Resistance

## Backtesting

## Purpose

Test the behavior of Windows as described by Steve Nison in Chapter 7: Continuation Patterns.

## Test Conditions

### Uptrend

- Identify markets where a Window appears during an uptrend.
- Observe whether price returns to test the open Window.
- Observe whether the Window acts as a support area.
- Observe the result after the Window is closed.

### Downtrend

- Identify markets where a Window appears during a downtrend.
- Observe whether price rebounds toward the Window.
- Observe whether the Window acts as a resistance area.
- Observe the result after the Window is closed.

## Data To Record

- Market
- Timeframe
- Trend Direction
- Window Location
- Support/Resistance Behavior
- Window Closed (Yes/No)
- Price Action After Closing
- Outcome

## Note

Backtesting rules are based only on the concepts described by Steve Nison regarding Windows, support, resistance, and trend context.

## Source

Steve Nison — Japanese Candlestick Charting Techniques  
Chapter 7 — Continuation Patterns