# TC001 — Windows as Support and Resistance

## Core Rules

### 1. Window Direction

- In an uptrend, a Window indicates that prices are likely to continue rising.
- In a downtrend, a Window indicates that prices are likely to continue falling.

### 2. Window as Support

In an uptrend, the Window becomes a support area where the market can rest during organized pullbacks.

If the pullback closes the Window and selling pressure continues after the Window is closed, it indicates that the uptrend has ended.

### 3. Window as Resistance

In a downtrend, the Window becomes a resistance area where price rebounds may face resistance.

If the Window is closed and the market continues rising after closing it, the downtrend has ended.

### 4. Testing Windows

Japanese technical analysis suggests that corrections often return toward open Windows.

Open Windows are frequently tested.

### 5. Trading With the Window

In an uptrend, organized pullbacks toward the Window can be used as a buying area.

If sellers continue pressure after the Window is closed, long positions should be liquidated and short selling may be considered.

The opposite strategy applies when the Window appears in a downtrend.

## Source

Steve Nison — Chapter 7: Continuation Patterns