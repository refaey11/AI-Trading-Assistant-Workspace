# TC001 — Windows as Support and Resistance

## Confirmation

The Window concept should be confirmed by considering the overall market trend.

### Confirmation Points

- The market trend should be identified before interpreting the Window.
- In an uptrend, the Window should be observed as a potential support area.
- In a downtrend, the Window should be observed as a potential resistance area.
- Open Windows should be monitored because corrections often return to test them.
- Closing the Window should be watched together with continued buying or selling pressure.

### Trend Confirmation

A Window should not be analyzed separately from the general market trend.

Japanese candlestick analysis, like any other analytical tool, should be used within the context of the overall market direction.

## Source

Steve Nison — Japanese Candlestick Charting Techniques  
Chapter 7 — Continuation Patterns