# TC001 — Windows as Support and Resistance

## Trading Application

### Uptrend

When a Window appears during an uptrend:

- The Window can be used as a support area during organized pullbacks.
- Corrections often return to test open Windows.
- Long positions should be monitored if selling pressure continues after the Window is closed.

### Downtrend

When a Window appears during a downtrend:

- The Window can act as a resistance area.
- Price rebounds may encounter resistance at the Window.
- If the Window is closed and the market continues upward, the previous downtrend has ended.

### Trend Context

Japanese candlestick analysis should always be used within the context of the overall market trend.

A candlestick signal or any analytical tool should be evaluated according to the general market trend.

## Source

Steve Nison — Chapter 7: Continuation Patterns