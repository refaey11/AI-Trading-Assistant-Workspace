# TC001 — Windows as Support and Resistance

## Psychology

A Window reflects strong market momentum in the direction of the current trend.

In an uptrend, the appearance of a Window shows strength from buyers and indicates that prices are likely to continue higher.

The Window also becomes an area where buyers may defend the market during organized pullbacks.

If the market returns and closes the Window, continued selling pressure after the close of the Window indicates that the previous upward momentum has failed.

In a downtrend, a Window reflects selling strength.

Price rebounds toward the Window may face resistance because the Window represents an area where sellers previously controlled the market.

Closing the Window and continuing in the opposite direction indicates that the previous trend has ended.

## Source

Steve Nison — Japanese Candlestick Charting Techniques  
Chapter 7 — Continuation Patterns