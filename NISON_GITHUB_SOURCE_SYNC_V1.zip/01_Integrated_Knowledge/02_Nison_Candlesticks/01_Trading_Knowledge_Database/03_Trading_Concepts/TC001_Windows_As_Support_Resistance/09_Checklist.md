# TC001 — Windows as Support and Resistance

## Checklist

Before using the Window concept, check:

### Market Context

- [ ] Is the general market trend identified?
- [ ] Is the market in an uptrend or downtrend?

### Window Identification

- [ ] Is there a clear gap between the previous and current sessions?
- [ ] Is the Window identified correctly?

### Support and Resistance

- [ ] In an uptrend, is the Window being used as support?
- [ ] In a downtrend, is the Window being used as resistance?

### Trend Continuation

- [ ] Is the Window still open?
- [ ] Has the Window been closed?
- [ ] Did selling or buying pressure continue after closing the Window?

### Decision Process

- [ ] Was the Window analyzed together with the overall market trend?
- [ ] Was a decision avoided before confirming the market context?

## Source

Steve Nison — Chapter 7: Continuation Patterns