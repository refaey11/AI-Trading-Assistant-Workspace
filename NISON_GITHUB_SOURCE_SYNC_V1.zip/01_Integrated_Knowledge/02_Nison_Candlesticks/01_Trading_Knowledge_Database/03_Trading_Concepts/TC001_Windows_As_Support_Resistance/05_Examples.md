# TC001 — Windows as Support and Resistance

## Examples

## Example 1 — Window in a Downtrend

A Window appeared during a downtrend.

After the Window:

- A Doji appeared.
- A white candle followed.

Prices recovered and moved higher.

The Window was tested twice as a resistance area before it was finally broken.

---

## Example 2 — Window as Support After Breakout

A Window formed above the 0.15 dollar level after a period of congestion.

The Window represented a strong breakout.

A double support area was created:

1. The Window itself.
2. The previous resistance level that became support after being broken.

This support remained important for several months.

---

## Example 3 — Window During an Uptrend

During a rapid advance, a Window appeared.

The Window maintained its role as a support level during the market decline.

The uptrend ended only after selling pressure continued following the closing of the Window.

---

## Example 4 — Multiple Windows

Three Windows appeared:

- Window 1 became support after the market pulled back.
- Window 2 indicated the end of a rapid advance and became resistance.
- Window 3 became a ceiling for further advances.

---

## Example 5 — Three Windows Theory

Japanese technical analysis suggests:

- Three upward Windows in an uptrend can indicate that a top may be approaching.
- Three downward Windows in a downtrend can indicate that a bottom may be approaching.

This becomes more important when a reversal pattern or reversal candle appears after the third Window.

## Source

Steve Nison — Chapter 7: Continuation Patterns