-- TC001: Windows as Support and Resistance

CREATE TABLE trading_concepts (
    concept_id VARCHAR(20) PRIMARY KEY,
    concept_name VARCHAR(100),
    category VARCHAR(50),
    source VARCHAR(100),
    chapter VARCHAR(100),
    description TEXT,
    rules TEXT,
    trading_context TEXT,
    confirmation TEXT
);


INSERT INTO trading_concepts
(
    concept_id,
    concept_name,
    category,
    source,
    chapter,
    description,
    rules,
    trading_context,
    confirmation
)

VALUES
(
    'TC001',
    'Windows as Support and Resistance',
    'Trading Concept',
    'Steve Nison',
    'Chapter 7 - Continuation Patterns',

    'Japanese traders call gaps Windows. A Window is a gap between the extremes of the previous and current sessions.',

    'Windows can act as support and resistance areas. In an uptrend the Window can become support. In a downtrend the Window can become resistance. Closing the Window with continued pressure indicates that the previous trend may have ended.',

    'In an uptrend, organized pullbacks toward the Window can be considered a buying area. In a downtrend, the opposite strategy applies.',

    'Use the general market trend and observe whether the Window remains open or gets closed.'
);