# TC001 — Windows as Support and Resistance

## Source
Steve Nison — Japanese Candlestick Charting Techniques

## Chapter
Chapter 7 — Continuation Patterns

## Category
Trading Concept

## Description

Japanese traders call gaps "Windows".

Western traders use the expression "filling the gap", while Japanese traders use the expression "closing the window".

A Window is a gap between the extremes of the previous and current sessions.

In an uptrend, the Window appears between the upper shadow of the previous session and the lower shadow of the current session.

In a downtrend, the Window appears when there is no price activity between the lower shadow of the previous session and the upper shadow of the current session.

Windows are important because they can act as support and resistance areas and provide information about continuation of the current trend.

## Source Reference

Chapter 7 — Continuation Patterns

Steve Nison