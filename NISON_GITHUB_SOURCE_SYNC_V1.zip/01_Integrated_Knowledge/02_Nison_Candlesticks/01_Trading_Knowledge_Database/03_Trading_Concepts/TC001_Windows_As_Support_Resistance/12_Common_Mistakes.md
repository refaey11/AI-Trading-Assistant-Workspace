# TC001 — Windows as Support and Resistance

## Common Mistakes

### 1. Ignoring the General Trend

A Window should not be analyzed separately from the overall market trend.

Japanese candlestick analysis should always be used within the context of the general market direction.

---

### 2. Taking Decisions Before Confirmation

Do not make a trading decision based on the Window before observing whether the Window remains open or gets closed.

---

### 3. Treating Every Window as a Reversal Signal

Windows are continuation concepts.

A Window during an uptrend indicates continuation strength, and a Window during a downtrend indicates continuation weakness.

---

### 4. Ignoring Support and Resistance Behavior

The Window can become:

- Support during an uptrend.
- Resistance during a downtrend.

Ignoring this role can lead to incorrect interpretation.

---

### 5. Ignoring the Closing of the Window

If the Window is closed and pressure continues in the opposite direction, it may indicate that the previous trend has ended.

## Source

Steve Nison — Japanese Candlestick Charting Techniques  
Chapter 7 — Continuation Patterns