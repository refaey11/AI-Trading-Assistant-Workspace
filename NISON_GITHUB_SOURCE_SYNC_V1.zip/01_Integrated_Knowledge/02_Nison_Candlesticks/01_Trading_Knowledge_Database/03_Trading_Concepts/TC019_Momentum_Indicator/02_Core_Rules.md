# TC019 — Momentum Indicator
## Core Rules

## 1. Basic Calculation Concept

Momentum measures the difference between:

Current Closing Price

and

Closing Price from a specified period earlier.

Example:

10-day Momentum
=
Today's Close
-
Close Ten Days Earlier

## 2. Positive Momentum

If today's close is higher than the close from the specified period earlier:

Momentum → Positive

## 3. Negative Momentum

If today's close is lower than the close from the specified period earlier:

Momentum → Negative

## 4. Increasing Upward Momentum

During an increasingly strong upward trend, the differences between prices should increase at an increasing rate.

This represents increasing momentum in the upward trend.

## 5. Sideways Momentum During Rising Prices

If prices continue increasing while Momentum moves sideways:

→ The speed of the price movement is decreasing.

This may provide an early warning of a possible end to the previous upward trend.

## 6. Zero-Line Interpretation

The source describes:

Momentum above zero → Bullish indication.

Momentum below zero → Bearish indication.

## 7. Overbought Condition

A highly positive Momentum value may indicate an overbought market.

The market may then be vulnerable to an orderly correction.

## 8. Price and Momentum Peaks

Momentum may reach its peak before price reaches its peak.

Therefore:

High Momentum / Overbought Condition
→ Possible warning of a price top.

## 9. Source Principle

Momentum should be interpreted in relation to:

- Price movement.
- The direction of the trend.
- Changes in Momentum.
- The zero line.
- Overbought / oversold conditions.