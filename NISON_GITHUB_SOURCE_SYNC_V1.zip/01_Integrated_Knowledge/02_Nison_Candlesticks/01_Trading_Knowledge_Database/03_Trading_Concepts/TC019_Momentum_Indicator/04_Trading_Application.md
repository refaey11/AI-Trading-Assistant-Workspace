# TC019 — Momentum Indicator
## Trading Application

## 1. Identify the Momentum Period

Determine the period being used.

Example from the source:

10-day Momentum compares today's closing price with the closing price ten days earlier.

## 2. Determine Momentum Direction

If current close > previous-period close:

→ Positive Momentum

If current close < previous-period close:

→ Negative Momentum

## 3. Monitor Momentum During an Uptrend

When prices continue rising:

Monitor whether Momentum continues increasing.

If Momentum begins moving sideways while prices continue rising:

→ Warning that price movement is losing speed.

## 4. Zero-Line Signal

The source describes:

Momentum crosses above zero
→ Bullish indication.

Momentum crosses below zero
→ Bearish indication.

## 5. Overbought Condition

When Momentum reaches a highly positive level:

→ Market may be overbought.

This may indicate increased possibility of an orderly correction.

## 6. Combining Momentum With Candlesticks

The source demonstrates that Momentum can be combined with Japanese candlesticks.

A warning from Momentum becomes more significant when supported by a relevant candlestick signal.

The Gold example shows:

- A long-legged Doji warned long-position holders.
- Price reached a new high.
- Momentum was lower than at the previous price peak.
- Later, Momentum moved below zero.

The combination provided additional evidence for a developing downward trend.

## 7. Trading Interpretation

The source presents Momentum as a tool for:

- Measuring price speed.
- Identifying weakening momentum.
- Identifying possible overbought conditions.
- Providing bullish or bearish indications through the zero line.
- Complementing Japanese candlestick evidence.

## 8. Source Limitation

No external entry, stop-loss, take-profit, or position-sizing rules are added to this application file.