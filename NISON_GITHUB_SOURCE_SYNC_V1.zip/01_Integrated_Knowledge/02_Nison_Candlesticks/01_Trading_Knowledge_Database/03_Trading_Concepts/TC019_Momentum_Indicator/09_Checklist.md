# TC019 — Momentum Indicator
## Checklist

Use the following checklist when analyzing Momentum according to the source material.

### Momentum Calculation

- [ ] Identify the Momentum period.
- [ ] Compare the current closing price with the closing price from the specified period earlier.
- [ ] Determine whether Momentum is positive or negative.

### Momentum Direction

- [ ] Check whether Momentum is increasing.
- [ ] Check whether Momentum is moving sideways.
- [ ] If prices continue rising while Momentum moves sideways, recognize the warning that price movement is slowing.

### Zero Line

- [ ] Check whether Momentum is above zero.
- [ ] Check whether Momentum is below zero.
- [ ] Above zero → bullish indication according to the source.
- [ ] Below zero → bearish indication according to the source.

### Overbought / Oversold

- [ ] Check for a highly positive Momentum value.
- [ ] Consider the possibility of an overbought condition.
- [ ] Check for a highly negative Momentum value.
- [ ] Consider the possibility of an oversold condition.

### Candlestick Confirmation

- [ ] Check whether a candlestick warning occurs with the Momentum signal.
- [ ] Examples in the source include Long-legged Doji, Evening Star, Harami, and Hammer.

### Final Interpretation

- [ ] Do not interpret Momentum independently from price behavior.
- [ ] Look for weakening Momentum while prices continue moving in the same direction.
- [ ] Treat Momentum indications as technical evidence rather than a guaranteed reversal.