# TC019 — Momentum Indicator
## Examples

## Example 1 — Gold, June 1990, Daily

The long-legged Doji provided a warning to traders holding long positions.

Price reached a new high at the Doji.

However, the Momentum indicator was lower than it had been at the previous price peak at the end of November (A).

This indicated weakening momentum despite the new price high.

Later in February, Momentum moved below zero, providing additional evidence that a downward trend was about to begin.

### Structure

- Candlestick → Long-legged Doji
- Price → New High
- Momentum → Lower than at the previous price peak
- Later confirmation → Momentum moved below zero
- Interpretation → Additional evidence of a developing downward trend

---

## Example 2 — Heating Oil, July 1990, Daily

The Momentum oscillator was also used to identify overbought and oversold conditions.

A reading of +200 represented an overbought market.

In this example, +200 meant that the current close was $0.02 above the close ten days earlier.

At +200, the upward trend was considered unlikely to continue in the same manner.

The market would be expected either to move sideways or to undergo a correction.

---

## Example 3 — Heating Oil Overbought Condition

A reading of -400 represented an oversold condition.

This corresponded to the current close being $0.04 below the close ten days earlier.

The source explains that when Momentum reaches the +200 overbought level, the market is unlikely to continue its upward trend without either moving sideways or correcting.

The probability of a significant price top becomes greater when the overbought Momentum condition is accompanied by a confirming candlestick signal.

---

## Example 4 — February

In February, an overbought Momentum condition occurred together with:

- Evening Star
- Followed by a Harami

The combination provided additional warning around the overbought condition.

---

## Example 5 — April

In April, another overbought Momentum condition occurred together with an Evening Star.

This provided additional candlestick evidence alongside the Momentum condition.

---

## Example 6 — March and April

In March and April, Hammer formations A and B appeared while Momentum was at overbought levels.

At these points, the market was considered unlikely to decline again.

To relieve the oversold condition, the market would have to move sideways or move upward.