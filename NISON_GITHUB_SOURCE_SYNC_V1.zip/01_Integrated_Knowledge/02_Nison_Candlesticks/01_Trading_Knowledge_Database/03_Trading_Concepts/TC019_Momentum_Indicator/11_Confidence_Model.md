# TC019 — Momentum Indicator
## Confidence Model

## Source Limitation

The provided source material does not define a numerical confidence model for Momentum.

It does not assign percentages or numerical confidence scores to Momentum signals.

Therefore, no numerical confidence formula is added here.

## Source-Based Evidence Hierarchy

The source provides several forms of technical evidence that can be considered together.

### Momentum Evidence

- Positive Momentum.
- Negative Momentum.
- Momentum above zero.
- Momentum below zero.
- Momentum moving sideways while prices continue rising.
- Highly positive Momentum / overbought condition.

### Candlestick Evidence

The source examples show Momentum being considered alongside candlestick signals such as:

- Long-legged Doji.
- Evening Star.
- Harami.
- Hammer.

## Confluence

The source demonstrates that Momentum can provide additional evidence when it appears together with candlestick signals.

For example, in the Gold example:

- Price reached a new high.
- A long-legged Doji appeared.
- Momentum was lower than at the previous price peak.
- Momentum later moved below zero.

This combination provided additional evidence for a downward trend.

## Confidence Rule

Do not convert these observations into an arbitrary numerical confidence score.

If a confidence model is later created for the AI system, any added weighting or scoring rules must be explicitly identified as system-design rules and not as rules from the source.