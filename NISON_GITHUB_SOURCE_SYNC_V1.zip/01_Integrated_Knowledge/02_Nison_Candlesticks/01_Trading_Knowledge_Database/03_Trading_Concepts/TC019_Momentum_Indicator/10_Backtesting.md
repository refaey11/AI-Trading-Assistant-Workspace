# TC019 — Momentum Indicator
## Backtesting

## Source Availability

The provided source material explains the Momentum indicator, its interpretation, and historical examples.

However, the source material provided does not specify a formal backtesting methodology.

It does not provide:

- A defined entry algorithm.
- A defined exit algorithm.
- Stop-loss rules.
- Take-profit rules.
- Position-sizing rules.
- A statistical performance model.
- A required sample size.
- A win-rate requirement.
- A risk/reward requirement.

## Source-Based Backtesting Constraints

Any backtesting implementation should therefore distinguish between:

### Source-Derived Conditions

- Momentum calculated from the difference between the current close and a previous close.
- Positive Momentum.
- Negative Momentum.
- Momentum above zero.
- Momentum below zero.
- Prices rising while Momentum moves sideways.
- Highly positive Momentum as an overbought indication.
- Candlestick confirmation.

### Not Specified by the Source

The source does not define a complete mechanical trading system from these conditions.

Therefore, no numerical backtesting performance claims should be generated from the source alone.

## Historical Examples

The source provides historical examples involving:

- Gold — June 1990, Daily.
- Heating Oil — July 1990, Daily.

These examples illustrate Momentum interpretation but are not presented as a formal statistical backtest.

## Data Integrity Rule

When converting this concept into a backtesting system, clearly label any additional rules as system-design rules rather than source-derived rules.