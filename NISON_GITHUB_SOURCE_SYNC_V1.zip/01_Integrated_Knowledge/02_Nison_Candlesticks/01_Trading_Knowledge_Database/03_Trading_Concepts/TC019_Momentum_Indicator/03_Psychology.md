# TC019 — Momentum Indicator
## Psychology

## 1. Understanding Price Speed

Momentum is described as the speed of prices.

It does not simply ask whether prices are rising or falling.

It examines the difference between the current closing price and a previous closing price from a specified period.

## 2. Increasing Speed

During a strengthening upward trend, increasing differences between prices indicate increasing momentum.

The idea is that the speed of the price movement is increasing.

## 3. Slowing Speed

Prices can continue rising while Momentum stops rising and begins moving sideways.

In this situation, price direction has not necessarily changed yet, but the speed of the movement is decreasing.

This can provide an early warning before the previous upward trend ends.

## 4. Momentum Before Price

The source explains that Momentum can reach its peak before price reaches its peak.

Therefore, a trader should pay attention when:

- Price continues reaching higher levels.
- Momentum is no longer confirming the same strength.
- Momentum begins to weaken or move sideways.

## 5. Overbought Psychology

A highly positive Momentum reading may indicate that the market has become overbought.

The source associates this condition with the possibility of an orderly correction.

## 6. Warning Rather Than Certainty

The Momentum indications described in the source are warnings about changing market speed and possible trend development.

They should be interpreted together with the actual price movement and other technical evidence described in the chapter.