# TC019 — Momentum Indicator
## Common Mistakes

The following cautions are supported by the source material.

## 1. Ignoring Momentum Weakening

A common analytical mistake is to focus only on rising prices.

If prices continue increasing while Momentum moves sideways, the source identifies this as a warning that the speed of price movement is decreasing.

## 2. Ignoring Momentum Peaks

Momentum can reach its peak before prices reach their peak.

Therefore, a trader should not assume that continued price strength necessarily means Momentum is also strengthening.

## 3. Ignoring the Zero Line

The source describes:

- Momentum above zero → bullish indication.
- Momentum below zero → bearish indication.

The zero line should therefore be considered when interpreting Momentum.

## 4. Ignoring Overbought Conditions

A highly positive Momentum value can indicate an overbought market.

The source associates this condition with the possibility of an orderly correction.

## 5. Treating Overbought as an Automatic Reversal

The source does not state that an overbought Momentum reading guarantees an immediate reversal.

The possibility of a price top becomes more significant when the condition is supported by a confirming candlestick signal.

## 6. Ignoring Candlestick Evidence

The historical examples demonstrate the usefulness of combining Momentum with Japanese candlesticks.

Examples include:

- Long-legged Doji.
- Evening Star.
- Harami.
- Hammer.

## 7. Adding Unsupported Rules

The provided source does not specify:

- Fixed entry rules.
- Fixed exit rules.
- Stop-loss levels.
- Take-profit levels.
- Position sizing.
- Numerical confidence scores.

These should not be presented as source-derived Momentum rules.

## 8. Treating Momentum as a Guaranteed Signal

Momentum provides indications and warnings about price speed, trend strength, and possible overbought or oversold conditions.

It should not be represented as a guaranteed prediction of future price movement.