CREATE TABLE momentum_indicator (
    id INTEGER PRIMARY KEY,
    concept_code VARCHAR(20) NOT NULL,
    indicator_name VARCHAR(100) NOT NULL,
    definition TEXT NOT NULL,
    calculation_period_example INTEGER,
    positive_condition TEXT,
    negative_condition TEXT,
    above_zero_signal TEXT,
    below_zero_signal TEXT,
    sideways_behavior TEXT,
    overbought_example VARCHAR(50),
    oversold_example VARCHAR(50),
    source_reference TEXT
);

INSERT INTO momentum_indicator (
    id,
    concept_code,
    indicator_name,
    definition,
    calculation_period_example,
    positive_condition,
    negative_condition,
    above_zero_signal,
    below_zero_signal,
    sideways_behavior,
    overbought_example,
    oversold_example,
    source_reference
)
VALUES (
    1,
    'TC019',
    'Momentum',
    'Measures the difference between the current closing price and the closing price from a specified period earlier.',
    10,
    'Current close is higher than the close from the specified period earlier.',
    'Current close is lower than the close from the specified period earlier.',
    'Bullish indication.',
    'Bearish indication.',
    'If prices continue rising while Momentum moves sideways, the speed of price movement is decreasing.',
    '+200',
    '-400',
    'Chapter 14 — Candlesticks and Oscillators'
);