# TC019 — Momentum Indicator

## Definition

Momentum, also called the speed of prices, measures the difference between today's closing price and the closing price from a specified period earlier.

For example, a 10-day Momentum indicator compares today's close with the close ten days earlier.

## Interpretation

If today's closing price is higher than the closing price from the specified period earlier, Momentum is positive.

If today's closing price is lower, Momentum is negative.

## Momentum and Trend

As an upward trend becomes stronger, the differences between prices should increase at an increasing rate.

This represents an upward trend with increasing momentum.

In other words, the rate of change in the price differences is increasing.

## Loss of Momentum

If prices continue to rise while the Momentum indicator begins moving sideways, this indicates that the speed of the price movement is decreasing.

This can provide an early warning that the previous upward trend may be approaching its end.

## Zero Line

The source describes:

- Momentum moving above zero → bullish indication.
- Momentum moving below zero → bearish indication.

## Overbought / Oversold Use

Momentum can also be used as an indicator of overbought and oversold conditions.

A highly positive Momentum reading may indicate an overbought market and the possibility of an orderly correction.

The Momentum indicator can reach its peak before prices do.

Therefore, an overbought Momentum condition can help anticipate a price top.

## Source Scope

This file records the Momentum concepts presented in Chapter 14 and does not add external Momentum rules.