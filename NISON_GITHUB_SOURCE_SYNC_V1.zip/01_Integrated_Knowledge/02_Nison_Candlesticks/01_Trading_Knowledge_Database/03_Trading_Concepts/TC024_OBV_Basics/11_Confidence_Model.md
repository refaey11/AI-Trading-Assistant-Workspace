# TC024 — OBV
## Confidence Model

## Source Limitation

The supplied chapter does not provide a numerical confidence model for OBV.

It does not assign percentages, scores, or weights to OBV signals.

## Source-Based Evidence

The chapter provides these forms of evidence:

- Price rising with OBV rising.
- Price falling with OBV falling.
- Rising OBV during sideways prices.
- Falling OBV during sideways prices.

## Interpretation

These relationships can be recorded as supporting evidence.

No numerical confidence score should be assigned because the source does not provide one.

## Important

Any future numerical confidence system must be identified as a project-level model and must not be presented as a rule from the book.