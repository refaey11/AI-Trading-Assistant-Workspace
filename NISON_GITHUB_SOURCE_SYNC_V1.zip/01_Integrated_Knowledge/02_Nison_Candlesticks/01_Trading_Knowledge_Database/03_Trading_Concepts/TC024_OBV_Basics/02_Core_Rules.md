# TC024 — OBV
## Core Rules

## Rule 1 — Higher Close

If the current close is higher than the previous close:

OBV = Previous OBV + Current Volume

## Rule 2 — Lower Close

If the current close is lower than the previous close:

OBV = Previous OBV - Current Volume

## Rule 3 — Unchanged Price

If the price does not change:

The volume is ignored.

## Rule 4 — Trend Confirmation

OBV should move in the same direction as the dominant price trend.

## Rule 5 — Rising Prices + Rising OBV

This is a positive indication.

## Rule 6 — Falling Prices + Falling OBV

Increasing volume supports the continuation of the decline.

## Rule 7 — Sideways Prices + Rising OBV

This can indicate accumulation and may warn of an approaching price rise.

## Rule 8 — Sideways Prices + Falling OBV

This can warn of distribution and may indicate a possible decline, especially when prices are at a high level.

## Source Limitation

These are the OBV rules explicitly supported by the supplied chapter text.