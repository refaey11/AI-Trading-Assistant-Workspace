# TC024 — OBV
## Psychology

## Volume and Price

OBV is based on the relationship between price changes and trading volume.

When prices rise and OBV rises, the volume behavior provides a positive indication.

When prices fall and OBV falls, volume supports the continuation of the decline.

## Accumulation

When prices move sideways while OBV rises, the source describes this as an indication of accumulation.

The rising OBV can warn of an approaching rise in prices.

## Distribution

When prices move sideways while OBV falls, the source describes this as a warning of distribution.

This can warn of a possible decline, particularly when prices are at a high level.

## Important Limitation

The source does not provide a separate detailed psychological model of buyers and sellers.

This file therefore records only the psychological interpretation explicitly supported by the OBV discussion.