# TC024 — OBV
## Checklist

- [ ] Is the current close higher than the previous close?
- [ ] Is the current close lower than the previous close?
- [ ] Did the price remain unchanged?
- [ ] Was volume added to OBV?
- [ ] Was volume subtracted from OBV?
- [ ] Is OBV rising?
- [ ] Is OBV falling?
- [ ] Is the dominant price trend rising?
- [ ] Is the dominant price trend falling?
- [ ] Does OBV move in the same direction as the price trend?
- [ ] Is the market moving sideways?
- [ ] If sideways, is OBV rising?
- [ ] If sideways, is OBV falling?
- [ ] Is there evidence of accumulation?
- [ ] Is there evidence of distribution?