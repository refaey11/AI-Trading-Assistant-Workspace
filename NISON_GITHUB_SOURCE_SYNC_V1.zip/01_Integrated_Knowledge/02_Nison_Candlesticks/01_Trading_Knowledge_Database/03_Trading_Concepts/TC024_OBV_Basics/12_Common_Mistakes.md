# TC024 — OBV
## Common Mistakes

## Mistake 1 — Ignoring the Previous Close

OBV depends on whether the current close is higher or lower than the previous close.

## Mistake 2 — Adding Volume on a Lower Close

When the current close is lower than the previous close, the day's volume is subtracted from OBV.

## Mistake 3 — Adding Volume When Price Is Unchanged

When prices do not change, the source states that the volume is ignored.

## Mistake 4 — Ignoring the Price Trend

OBV should be considered in relation to the direction of the dominant price trend.

## Mistake 5 — Ignoring Sideways Markets

The source specifically discusses the use of OBV in sideways price ranges.

## Mistake 6 — Ignoring Rising OBV During a Sideways Market

Rising OBV during relatively stable prices can indicate accumulation and warn of an approaching price rise.

## Mistake 7 — Ignoring Falling OBV During a Sideways Market

Falling OBV can warn of distribution and a possible decline, especially when prices are at a high level.

## Source Limitation

The book does not provide a complete mechanical trading system for OBV, so additional rules should not be presented as source-derived rules.