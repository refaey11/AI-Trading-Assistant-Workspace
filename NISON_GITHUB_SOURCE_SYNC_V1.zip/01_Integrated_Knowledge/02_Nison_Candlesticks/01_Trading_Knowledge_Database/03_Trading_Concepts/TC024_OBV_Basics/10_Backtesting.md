# TC024 — OBV
## Backtesting

## Source Limitation

The supplied chapter explains how OBV is calculated and interpreted, but it does not provide a formal backtesting methodology.

The source does not specify:

- A fixed entry rule.
- A fixed exit rule.
- Stop-loss rules.
- Take-profit rules.
- Position sizing.
- Required sample size.
- Statistical performance requirements.

## Source-Based Testable Observations

A future test could record the source-defined relationships:

- Rising price + rising OBV.
- Falling price + falling OBV.
- Sideways price + rising OBV.
- Sideways price + falling OBV.

However, the chapter itself does not provide a complete statistical testing procedure.

Therefore, no backtesting results or performance claims should be attributed to the book.