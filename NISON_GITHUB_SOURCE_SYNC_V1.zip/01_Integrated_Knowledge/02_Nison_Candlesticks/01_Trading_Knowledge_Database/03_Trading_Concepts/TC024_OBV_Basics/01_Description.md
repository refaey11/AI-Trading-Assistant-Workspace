# TC024 — On-Balance Volume (OBV)

## Definition

On-Balance Volume (OBV) is a cumulative volume indicator.

It represents the net volume of trading activity according to whether the current session closes above or below the previous session's close.

## Basic Calculation

When the current session closes above the previous close:

- The day's trading volume is added to the cumulative OBV.

When the current session closes below the previous close:

- The day's trading volume is subtracted from the cumulative OBV.

When prices do not change:

- The volume is ignored.

## Main Purpose

OBV can be used to confirm the direction of the dominant price trend.

The indicator should move in the same direction as the prevailing price trend.

## Source Principle

If prices rise together with rising OBV, this is a positive indication.

If prices fall together with falling OBV, the increase in volume supports the continuation of the decline.

## Sideways Markets

OBV can also be used when prices are moving sideways.

A rising OBV while prices remain relatively stable can indicate accumulation and may warn of an approaching price rise.

A falling OBV while prices move sideways can warn of distribution and may indicate a possible decline, particularly when prices are at a high level.

## Source

Chapter 15 — Volume and Open Interest.