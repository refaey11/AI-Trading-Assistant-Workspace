# TC024 — OBV
## Examples From the Source

## Example 1 — Rising Price and Rising OBV

When prices rise together with rising OBV, the source describes this as a positive indication.

## Example 2 — Falling Price and Falling OBV

When prices fall while OBV falls, the increase in volume supports the continuation of the decline.

## Example 3 — Sideways Prices and Rising OBV

When prices remain relatively stable while OBV rises, this indicates accumulation.

The source states that this may warn of an approaching rise in prices.

## Example 4 — Sideways Prices and Falling OBV

When prices move sideways while OBV falls, this warns of distribution.

The source states that this can warn of a possible decline, particularly when prices are at a high level.

## Related Case Study

Exhibit 15.3 presents On-Balance Volume with candlesticks in the Silver market.

The detailed case belongs to TC025.