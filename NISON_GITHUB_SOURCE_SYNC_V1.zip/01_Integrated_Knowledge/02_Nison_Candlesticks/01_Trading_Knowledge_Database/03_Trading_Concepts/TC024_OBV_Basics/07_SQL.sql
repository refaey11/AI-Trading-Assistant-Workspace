CREATE TABLE obv_basics (
    id INTEGER PRIMARY KEY,
    concept_code VARCHAR(20),
    indicator_name VARCHAR(100),
    higher_close_rule TEXT,
    lower_close_rule TEXT,
    unchanged_price_rule TEXT,
    rising_price_rising_obv TEXT,
    falling_price_falling_obv TEXT,
    sideways_rising_obv TEXT,
    sideways_falling_obv TEXT,
    related_exhibit VARCHAR(20),
    source_reference TEXT
);

INSERT INTO obv_basics (
    id,
    concept_code,
    indicator_name,
    higher_close_rule,
    lower_close_rule,
    unchanged_price_rule,
    rising_price_rising_obv,
    falling_price_falling_obv,
    sideways_rising_obv,
    sideways_falling_obv,
    related_exhibit,
    source_reference
)
VALUES (
    1,
    'TC024',
    'On-Balance Volume',
    'Add current trading volume to cumulative OBV.',
    'Subtract current trading volume from cumulative OBV.',
    'Ignore the volume when prices do not change.',
    'Positive indication.',
    'Increasing volume supports continuation of the decline.',
    'Indicates accumulation and may warn of an approaching rise.',
    'Warns of distribution and may indicate a possible decline, especially at high price levels.',
    '15.3',
    'Chapter 15 — Volume and Open Interest'
);