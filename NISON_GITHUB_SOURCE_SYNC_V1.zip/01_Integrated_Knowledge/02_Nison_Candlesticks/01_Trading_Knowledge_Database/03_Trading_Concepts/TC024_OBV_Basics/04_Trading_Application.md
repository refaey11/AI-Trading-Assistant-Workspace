# TC024 — OBV
## Trading Application

## Trend Confirmation

Use OBV to compare its direction with the dominant direction of prices.

### Bullish Confirmation

Price rises + OBV rises

This provides a positive indication.

### Bearish Confirmation

Price falls + OBV falls

The increase in volume supports continuation of the decline.

## Sideways Market

When prices move sideways:

### Rising OBV

May indicate accumulation.

The source states that this may warn of an approaching rise in prices.

### Falling OBV

May warn of distribution.

The source states that this may indicate a possible decline, especially when prices are at a high level.

## Important

OBV is used as an analytical indicator of volume and price behavior.

The supplied chapter does not provide a complete mechanical entry, stop-loss, or take-profit system based on OBV.