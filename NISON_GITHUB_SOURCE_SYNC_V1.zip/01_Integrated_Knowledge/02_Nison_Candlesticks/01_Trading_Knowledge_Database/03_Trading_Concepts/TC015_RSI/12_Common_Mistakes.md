# TC015 - Common RSI Mistakes

## Mistake 1

Selling immediately when RSI > 70.

---

## Mistake 2

Buying immediately when RSI < 30.

---

## Mistake 3

Ignoring the dominant trend.

---

## Mistake 4

Trading divergence without Candlestick confirmation.

---

## Mistake 5

Treating every divergence as equally important.

---

## Mistake 6

Ignoring support and resistance.

---

## Mistake 7

Ignoring the selected RSI timeframe/period.

---

## Mistake 8

Entering before the reversal is confirmed.

---

## Mistake 9

Ignoring higher timeframe structure.

---

## Mistake 10

Treating RSI as a standalone trading system.

---

## Mistake 11

Assuming an overbought market must immediately fall.

---

## Mistake 12

Assuming an oversold market must immediately rise.

---

## Professional Rule

RSI

+

Trend

+

Divergence

+

Candlestick

+

Support/Resistance

+

Risk Management

is stronger than RSI alone.