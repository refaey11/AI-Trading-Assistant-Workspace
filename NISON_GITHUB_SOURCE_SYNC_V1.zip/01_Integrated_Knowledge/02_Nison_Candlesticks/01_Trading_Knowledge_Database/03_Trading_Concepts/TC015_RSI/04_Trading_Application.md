# TC015 - RSI Trading Application

## Setup 1 - Bullish Divergence

### Conditions

Dominant trend:

Downtrend or corrective decline.

Price:

Lower Low.

RSI:

Higher Low.

Additional confirmation:

Bullish Candlestick pattern.

### Potential Action

Look for:

- Long entry.
- Short covering.

### Invalidation

Price continues lower while RSI confirms the new low.

---

## Setup 2 - Bearish Divergence

### Conditions

Dominant trend:

Uptrend or corrective rally.

Price:

Higher High.

RSI:

Lower High.

Additional confirmation:

Bearish Candlestick pattern.

### Potential Action

Look for:

- Long position reduction.
- Potential short setup when trend context supports it.

---

## Setup 3 - Oversold RSI

RSI reaches:

20–30 zone.

Then check:

1. Market trend.
2. Support.
3. Candlestick confirmation.
4. Bullish divergence.

Do not enter simply because RSI is oversold.

---

## Setup 4 - Overbought RSI

RSI reaches:

70–80 zone.

Then check:

1. Market trend.
2. Resistance.
3. Candlestick confirmation.
4. Bearish divergence.

Do not short simply because RSI is overbought.

---

## Setup 5 - Bullish Confirmation

Trend:

Bullish

+

RSI bullish divergence

+

Bullish Candlestick

+

Support

=

High-quality bullish setup.

---

## Setup 6 - Bearish Confirmation

Trend:

Bearish

+

RSI bearish divergence

+

Bearish Candlestick

+

Resistance

=

High-quality bearish setup.

---

## Entry Rule

Prefer entry after the confirming Candlestick pattern closes.

---

## Stop Loss

For bullish setups:

Below the structural low or reversal candle.

For bearish setups:

Above the structural high or reversal candle.

---

## Target

Possible targets:

- Previous swing high/low.
- Support/resistance.
- Major price level.
- Trend target.

---

## Risk Management

Risk must be defined before entry.

Do not increase position size simply because RSI divergence appears.