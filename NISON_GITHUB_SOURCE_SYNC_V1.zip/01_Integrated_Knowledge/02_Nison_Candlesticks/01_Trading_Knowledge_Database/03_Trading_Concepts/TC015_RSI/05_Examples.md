# TC015 - RSI Examples

## Example 1 - Bullish Divergence

Price reaches a new low.

RSI reaches a higher low.

Interpretation:

Bullish divergence.

Next step:

Look for bullish Candlestick confirmation.

---

## Example 2 - Bearish Divergence

Price reaches a new high.

RSI reaches a lower high.

Interpretation:

Bearish divergence.

Next step:

Look for bearish Candlestick confirmation.

---

## Example 3 - RSI Overbought During Strong Uptrend

RSI rises above 70.

Price continues making higher highs.

Interpretation:

The market may be in a strong trend.

Action:

Do not automatically short.

Wait for evidence of weakness.

---

## Example 4 - RSI Oversold During Strong Downtrend

RSI falls below 30.

Price continues making lower lows.

Interpretation:

The market may remain under strong selling pressure.

Action:

Do not automatically buy.

---

## Example 5 - Divergence + Candlestick

Price:

Lower Low

RSI:

Higher Low

Candlestick:

Bullish Engulfing

Support:

Present

Interpretation:

Multiple independent confirmations support a potential bullish reversal.

---

## Example 6 - Bearish Divergence + Candlestick

Price:

Higher High

RSI:

Lower High

Candlestick:

Dark Cloud Cover

Resistance:

Present

Interpretation:

Multiple confirmations support a potential bearish reversal.