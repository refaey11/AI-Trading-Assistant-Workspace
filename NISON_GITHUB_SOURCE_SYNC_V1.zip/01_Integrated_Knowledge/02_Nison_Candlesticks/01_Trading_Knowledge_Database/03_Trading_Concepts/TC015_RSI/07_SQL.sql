CREATE TABLE rsi_analysis (

    id INTEGER PRIMARY KEY,

    concept_code TEXT NOT NULL,

    rsi_period INTEGER,

    rsi_value REAL,

    market_trend TEXT,

    market_condition TEXT,

    divergence_type TEXT,

    price_structure TEXT,

    rsi_structure TEXT,

    candlestick_pattern TEXT,

    support_resistance TEXT,

    entry_rule TEXT,

    stop_loss_rule TEXT,

    target_rule TEXT,

    confidence_level TEXT,

    source_reference TEXT,

    notes TEXT
);