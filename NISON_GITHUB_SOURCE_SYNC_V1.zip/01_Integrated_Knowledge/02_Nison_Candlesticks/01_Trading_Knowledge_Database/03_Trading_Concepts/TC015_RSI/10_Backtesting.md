# TC015 - RSI Backtesting

## Trade Data

Record:

- Trade Number
- Date
- Asset
- Timeframe
- RSI Period
- RSI Value
- Market Trend
- Overbought/Oversold
- Divergence
- Candlestick Pattern
- Support/Resistance
- Entry
- Stop Loss
- Target
- Exit
- Result
- R-Multiple
- Maximum Favorable Excursion
- Maximum Adverse Excursion
- Notes

## Test Groups

### Test 1

RSI only.

### Test 2

RSI + Trend.

### Test 3

RSI + Divergence.

### Test 4

RSI + Candlestick.

### Test 5

RSI + Trend + Candlestick.

### Test 6

RSI + Trend + Divergence + Candlestick + Support/Resistance.

## Performance Metrics

- Win Rate
- Profit Factor
- Expectancy
- Average R
- Maximum Drawdown
- False Signal Rate
- Bullish Divergence Success Rate
- Bearish Divergence Success Rate
- Overbought Reversal Success Rate
- Oversold Reversal Success Rate