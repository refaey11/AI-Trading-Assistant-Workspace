# TC015 - RSI Checklist

□ Dominant trend identified.

□ RSI period identified.

□ Current RSI value recorded.

□ Overbought condition checked.

□ Oversold condition checked.

□ Bullish divergence checked.

□ Bearish divergence checked.

□ Price structure compared with RSI structure.

□ Candlestick confirmation checked.

□ Support/resistance checked.

□ Higher timeframe checked.

□ Entry defined.

□ Stop Loss defined.

□ Target defined.

□ Risk/Reward calculated.

□ Trade documented.