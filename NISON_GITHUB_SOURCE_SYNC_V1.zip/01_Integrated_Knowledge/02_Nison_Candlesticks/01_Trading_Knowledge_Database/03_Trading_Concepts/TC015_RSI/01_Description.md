# TC015 - Relative Strength Index (RSI)

## Name

Relative Strength Index (RSI)

## Category

Technical Oscillator

Momentum Indicator

Overbought / Oversold

Divergence

## Source

Steve Nison

Beyond Candlesticks

Chapter 14

## Definition

The Relative Strength Index (RSI) is a momentum oscillator that compares the strength of recent upward price movements with recent downward price movements.

The RSI produces a value between 0 and 100.

## Common Periods

The most commonly referenced periods in the source are:

- 9 periods
- 14 periods

## Main Uses

1. Overbought / Oversold analysis.
2. Bullish divergence.
3. Bearish divergence.
4. Momentum confirmation.

## Calculation

RSI = 100 - (100 / (1 + RS))

Where:

RS = Average Gain / Average Loss

The calculation is based on closing prices.

For a 14-period RSI:

1. Calculate the price changes over the previous 14 periods.
2. Separate gains from losses.
3. Calculate average gains.
4. Calculate average losses.
5. Calculate RS.
6. Convert RS into the RSI value.

## Core Principle

RSI should be used as a confirmation tool alongside market trend, Candlestick patterns, and support/resistance rather than as a standalone trading signal.