# TC015 - RSI Confidence Model

## Scoring

Dominant Trend Alignment

+20

Valid RSI Signal

+15

Bullish/Bearish Divergence

+20

Extreme RSI Reading

+10

Candlestick Confirmation

+15

Support/Resistance Confirmation

+10

Risk/Reward

+10

## Maximum

100 Points

## Classification

90–100

Very High Confidence

70–89

High Confidence

50–69

Moderate Confidence

Below 50

Avoid / Wait

## Important

The confidence score is a decision-support framework.

It does not represent the probability that a trade will win.