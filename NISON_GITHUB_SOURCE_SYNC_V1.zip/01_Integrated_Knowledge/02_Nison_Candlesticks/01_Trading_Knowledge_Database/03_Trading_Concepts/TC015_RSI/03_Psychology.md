# TC015 - RSI Psychology

## What RSI Represents

RSI measures the relative strength of recent gains compared with recent losses.

It provides a numerical representation of price momentum.

---

## Bullish Divergence

Price makes a deeper low.

RSI makes a higher low.

This means the new price low is not accompanied by equivalent downside momentum.

Interpretation:

Selling pressure may be weakening.

---

## Bearish Divergence

Price makes a higher high.

RSI makes a lower high.

This means the new price high is not accompanied by equivalent upside momentum.

Interpretation:

Buying pressure may be weakening.

---

## Overbought Psychology

A high RSI reflects strong recent buying pressure.

However, strong buying pressure can persist.

Therefore:

Overbought does not equal immediate reversal.

The trader should wait for evidence that buyers are losing control.

---

## Oversold Psychology

A low RSI reflects strong recent selling pressure.

However, strong selling pressure can persist.

Therefore:

Oversold does not equal immediate reversal.

The trader should wait for evidence that sellers are losing control.

---

## Candlestick Psychology

RSI identifies internal momentum conditions.

Candlesticks reveal how buyers and sellers behave around specific price levels.

Combining both gives a more complete picture.

---

## Professional Principle

Do not ask:

"Is RSI overbought?"

Ask:

"Is the market overextended, and is there evidence that the dominant side is losing control?"