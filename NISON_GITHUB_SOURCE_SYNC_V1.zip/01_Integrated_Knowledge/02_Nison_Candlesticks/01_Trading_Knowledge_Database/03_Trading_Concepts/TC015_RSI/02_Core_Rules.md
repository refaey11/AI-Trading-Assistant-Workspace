# TC015 - RSI Core Rules

## Rule 1 - RSI Range

RSI values range from:

0 to 100.

---

## Rule 2 - Overbought

RSI above approximately:

70 or 80

indicates an overbought condition.

This means the market may be vulnerable to consolidation or correction.

It does NOT automatically mean price must fall.

---

## Rule 3 - Oversold

RSI below approximately:

30 or 20

indicates an oversold condition.

This means selling pressure may be becoming exhausted.

It does NOT automatically mean price must rise.

---

## Rule 4 - Bearish Divergence

Price:

Higher High

RSI:

Lower High

Result:

Bearish Divergence.

This indicates weakening upward momentum.

---

## Rule 5 - Bullish Divergence

Price:

Lower Low

RSI:

Higher Low

Result:

Bullish Divergence.

This indicates weakening selling pressure.

---

## Rule 6 - Divergence Near Extremes

Divergence becomes more meaningful when RSI is simultaneously in an overbought or oversold area.

---

## Rule 7 - Trend Context

Bullish RSI signals should generally be used to:

- Enter long positions in an uptrend.
- Cover short positions in a downtrend.

Bearish RSI signals should generally be used to:

- Reduce long positions.
- Consider short positions when the dominant trend is bearish.

---

## Rule 8 - New Trends

Do not automatically interpret an overbought RSI as a reversal when a major new uptrend is beginning.

The RSI can remain overbought while prices continue rising.

The same principle applies to oversold readings during strong downtrends.

---

## Rule 9 - Candlestick Confirmation

RSI signals become stronger when supported by Candlestick patterns.

Examples:

Bullish:

- Hammer
- Bullish Engulfing
- Piercing Pattern
- Morning Star

Bearish:

- Shooting Star
- Hanging Man
- Bearish Engulfing
- Dark Cloud Cover

---

## Rule 10 - Multiple Confirmation

The strongest setups occur when:

Trend

+

RSI

+

Divergence

+

Candlestick

+

Support / Resistance

agree.