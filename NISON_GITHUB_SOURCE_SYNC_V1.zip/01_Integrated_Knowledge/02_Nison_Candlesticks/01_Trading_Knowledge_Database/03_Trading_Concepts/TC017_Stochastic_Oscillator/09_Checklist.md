# TC017 — Stochastic Oscillator Checklist

## Indicator

- [ ] Stochastic Oscillator identified.
- [ ] Reading is between 0 and 100.
- [ ] Calculation period identified.
- [ ] %K identified.
- [ ] %D identified.

## Price Relationship

- [ ] Current price compared with the recent trading range.
- [ ] Important price high identified if present.
- [ ] Important price low identified if present.

## Divergence

### Bullish

- [ ] Price formed a lower low.
- [ ] Stochastic failed to form a corresponding lower low.
- [ ] Bullish divergence identified.

### Bearish

- [ ] Price formed a higher high.
- [ ] Stochastic failed to form a corresponding higher high.
- [ ] Bearish divergence identified.

## %K / %D

- [ ] %K crossed above %D?
- [ ] %K crossed below %D?
- [ ] Crossover interpreted with other technical evidence.

## Overbought / Oversold

- [ ] Stochastic reading evaluated within its 0–100 range.
- [ ] Oversold condition checked.
- [ ] The 25% reference used where applicable.

## Candlestick Confirmation

- [ ] Relevant candlestick pattern identified.
- [ ] Candlestick signal compared with Stochastic evidence.
- [ ] Divergence checked for confirmation.

## Final Assessment

- [ ] Price evidence documented.
- [ ] Stochastic evidence documented.
- [ ] Candlestick evidence documented.
- [ ] No unsupported conclusion added.