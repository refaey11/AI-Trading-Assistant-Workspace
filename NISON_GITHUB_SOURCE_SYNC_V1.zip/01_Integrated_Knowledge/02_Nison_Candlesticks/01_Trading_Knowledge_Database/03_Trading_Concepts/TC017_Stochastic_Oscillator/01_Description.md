# Stochastic Oscillator

## Description

The Stochastic Oscillator is a technical analysis tool used by futures market analysts.

As an oscillator, it provides:

- Overbought readings
- Oversold readings
- Divergence signals
- A mechanism for comparing short-term price movement with longer-term price movement

The Stochastic Oscillator compares the latest closing price with the price range over a specified period.

The indicator ranges from 0 to 100.

A high Stochastic reading means that the closing price is near the upper end of the trading range during the specified period.

A low Stochastic reading means that the closing price is near the lower end of the trading range.

The underlying idea is that when the market moves upward, closing prices tend to occur near the upper end of the range.

When the market moves downward, prices tend to cluster near the lower end of the range.

## Common Periods

Common periods used with the Stochastic Oscillator include:

- 9
- 14
- 21

The selected period may be measured in:

- Days
- Weeks
- Intraday hours

## Main Components

The Stochastic Oscillator consists of two lines:

### %K

%K is the raw or fast Stochastic line.

It is the more sensitive line.

### %D

%D is obtained by smoothing the slower %K line again.

The relationship between %K and %D can be used as an additional technical signal.

## Main Uses

The Stochastic Oscillator is primarily discussed in the book in relation to:

1. Overbought and oversold conditions
2. Divergence
3. Crossovers between %K and %D
4. Comparison of short-term movement with longer-term movement

## Important Context

The book emphasizes using Stochastic signals together with other technical evidence, particularly Japanese candlestick signals.

Examples in the chapter demonstrate how:

- Bullish divergence can support a bullish candlestick signal.
- Bearish divergence can support a bearish candlestick signal.
- %K/%D crossovers can provide additional confirmation.