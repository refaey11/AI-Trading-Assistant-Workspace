# Stochastic Oscillator — Core Rules

## 1. Indicator Range

The Stochastic Oscillator ranges from 0 to 100.

A high reading indicates that the closing price is near the upper end of the trading range during the selected period.

A low reading indicates that the closing price is near the lower end of the trading range during the selected period.

---

## 2. Core Principle

When the market moves upward, closing prices tend to move toward the upper end of the trading range.

When the market moves downward, closing prices tend to cluster near the lower end of the trading range.

The Stochastic Oscillator uses this relationship to evaluate the position of the latest closing price within the recent trading range.

---

## 3. %K Line

The Stochastic Oscillator consists of two lines.

The first is the %K line, also called the raw or fast Stochastic line.

%K is the more sensitive line.

### Formula

%K = ((Close - Low of N) / (High of N - Low of N)) × 100

Where:

- Close = Current closing price
- Low of N = Lowest price during the selected period
- High of N = Highest price during the selected period

The multiplication by 100 converts the value into a percentage.

If the current closing price equals the highest price during the selected period, the fast %K value is 100%.

---

## 4. Calculation Period

The Stochastic calculation period can be measured in:

- Days
- Weeks
- Intraday hours

The most common periods mentioned in the book are:

- 9
- 14
- 21

---

## 5. Smoothing %K

The fast %K line can be highly volatile.

To smooth it, a moving average of the most recent three %K values is calculated.

This produces the slower %K line.

The book notes that most analysts use the slower version rather than the highly volatile fast %K line.

---

## 6. %D Line

The slower %K line is smoothed again.

A moving average of the most recent three values of the slow %K produces the %D line.

Therefore:

Fast %K
→ 3-period moving average
→ Slow %K
→ 3-period moving average
→ %D

The %D line can therefore be viewed as a moving average of a moving average.

---

## 7. %K and %D Relationship

The difference and crossover between %K and %D can be interpreted similarly to the relationship between two moving averages:

- %K → Faster line
- %D → Slower line

A crossover between the two lines can therefore provide an additional technical signal.

---

## 8. Overbought and Oversold

The Stochastic Oscillator can be used to identify overbought and oversold conditions.

The book discusses these conditions together with divergence when forming a technical view.

An oversold reading is generally associated with the lower part of the 0–100 range.

In the examples, a reading below 25% is used as an oversold condition.

---

## 9. Divergence

Divergence is one of the main uses of the Stochastic Oscillator.

### Bullish Divergence

Bullish divergence occurs when:

- Price makes a lower low.
- The Stochastic Oscillator does not make a corresponding lower low.

In the examples, a higher Stochastic reading at the second price low provides bullish divergence.

### Bearish Divergence

Bearish divergence occurs when:

- Price makes a higher high.
- The Stochastic Oscillator does not make a corresponding higher high.

In the examples, a lower Stochastic reading at the second price high provides bearish divergence.

---

## 10. %K / %D Crossovers

Some analysts use crossovers between %K and %D as an additional trading rule.

### Bullish Crossover

A bullish crossover occurs when:

%K crosses above %D.

### Bearish Crossover

A bearish crossover occurs when:

%K crosses below %D.

The book compares these crossovers to signals generated when a faster moving average crosses a slower moving average.

---

## 11. Combining Signals

The book's examples demonstrate that Stochastic signals can be combined with Japanese candlestick signals.

Examples include combinations of:

- Candlestick reversal patterns
- Bullish divergence
- Bearish divergence
- Bullish %K/%D crossover
- Bearish %K/%D crossover
- Overbought/oversold readings

The purpose is to obtain additional confirmation rather than relying on one technical indication alone.