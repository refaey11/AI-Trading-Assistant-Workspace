# Confidence Model — Stochastic Oscillator

## Purpose

The Stochastic Oscillator can strengthen a candlestick signal when multiple technical indications support the same market interpretation.

The book emphasizes that the strength of the indication increases when several signals occur together.

---

## 1. Positive Evidence

A bullish interpretation becomes stronger when the following evidence occurs together:

- A bullish candlestick signal.
- Positive divergence in the Stochastic Oscillator.
- A positive K% / D% crossover.
- The crossover occurs in the oversold area.
- Price makes a lower low while the Stochastic Oscillator fails to make a lower low.

### Example from the book

In the Copper example:

- Hammer-like candlestick formations appeared.
- The second low was lower than the first low.
- The Stochastic reading at the second low was higher.
- This created positive divergence.
- K% crossed above D%.
- The positive crossover occurred below 25%, in the oversold area.

The book describes this combination of technical evidence as strong enough to indicate the end of the declining trend.

---

## 2. Negative Evidence

A bearish interpretation becomes stronger when the following evidence occurs together:

- A bearish candlestick signal.
- Negative divergence in the Stochastic Oscillator.
- A negative K% / D% crossover.
- Price reaches a new high while the Stochastic Oscillator fails to reach a new high.
- The Stochastic signal occurs in an overbought area.

### Example from the book

In the S&P example:

- A Dark Cloud Cover pattern appeared.
- Price reached a new high.
- The Stochastic Oscillator did not reach a new high.
- This created negative divergence.
- A negative crossover later occurred when K% moved below D%.

The following decline received additional confirmation from the Stochastic crossover.

---

## 3. Relative Strength of Evidence

The book's examples show that technical evidence becomes more meaningful when signals from different tools agree.

The strongest combinations described are:

### Bullish

Bullish Candlestick
+
Positive Stochastic Divergence
+
Positive K% / D% Crossover
+
Oversold Reading

### Bearish

Bearish Candlestick
+
Negative Stochastic Divergence
+
Negative K% / D% Crossover
+
Overbought Reading

---

## 4. Interpretation

The Stochastic Oscillator should be considered as supporting technical evidence rather than as an isolated guarantee.

The book specifically demonstrates that:

- Candlesticks can provide an initial warning.
- Stochastic divergence can strengthen that warning.
- K% / D% crossovers can provide additional confirmation.
- Multiple agreeing signals create a stronger technical case.

---

## 5. Important Threshold

The book identifies an oversold reading as:

- D% = 25% or less.

A positive K% / D% crossover becomes more important when it occurs in this oversold area.

---

## 6. Confidence Principle

Confidence in a Stochastic-based interpretation increases when:

1. Price reaches an important extreme.
2. The Stochastic Oscillator fails to confirm the price extreme.
3. A corresponding candlestick signal appears.
4. K% and D% provide confirming crossover evidence.
5. The signal occurs in an appropriate overbought or oversold area.

This represents the confluence of technical evidence described in the book.