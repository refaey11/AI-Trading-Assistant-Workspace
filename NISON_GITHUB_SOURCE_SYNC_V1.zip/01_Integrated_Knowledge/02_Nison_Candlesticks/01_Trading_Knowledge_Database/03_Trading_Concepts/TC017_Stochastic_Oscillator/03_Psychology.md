# Stochastic Oscillator — Psychology

## Market Behavior Behind the Indicator

The Stochastic Oscillator is based on the observation that closing prices tend to behave differently depending on the direction of the market.

When the market moves upward, closing prices tend to move toward the upper end of the recent trading range.

When the market moves downward, prices tend to cluster near the lower end of the trading range.

This behavior forms the basic idea behind the Stochastic Oscillator.

---

## Loss of Momentum

A divergence between price and the Stochastic Oscillator can indicate that the internal strength of the current market move is weakening.

### Bearish Situation

Price reaches a new high while the Stochastic Oscillator fails to reach a corresponding new high.

This indicates that the upward movement is not being confirmed by the oscillator.

### Bullish Situation

Price reaches a new low while the Stochastic Oscillator fails to reach a corresponding new low.

This indicates that selling pressure may be weakening.

---

## Importance of Confirmation

The examples in the book show that Stochastic signals become more meaningful when they agree with Japanese candlestick signals.

For example:

- A bullish candlestick pattern combined with bullish divergence.
- A bearish candlestick pattern combined with bearish divergence.
- A bullish %K/%D crossover combined with an oversold reading.
- A bearish %K/%D crossover combined with bearish evidence.

The book therefore demonstrates the importance of examining more than one technical indication.

---

## Technical Evidence

The book's examples emphasize reviewing other technical evidence before deciding how important a Stochastic signal is.

Candlestick patterns may provide an initial warning, while the Stochastic Oscillator can provide additional confirmation.

Likewise, an imperfect candlestick pattern can become more useful when supported by divergence or a %K/%D crossover.

---

## Key Principle

The Stochastic Oscillator should be interpreted as part of the broader technical evidence rather than examined independently from price behavior and candlestick signals.