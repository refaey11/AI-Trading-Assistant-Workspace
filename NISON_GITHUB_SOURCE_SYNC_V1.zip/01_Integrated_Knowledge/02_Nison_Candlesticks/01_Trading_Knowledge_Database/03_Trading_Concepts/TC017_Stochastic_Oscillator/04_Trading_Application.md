# Stochastic Oscillator — Trading Application

## 1. Overbought and Oversold

The Stochastic Oscillator can be used to monitor overbought and oversold conditions.

The book's examples use readings below 25% as an oversold condition.

Overbought and oversold readings are considered together with other technical evidence when forming a market view.

---

## 2. Bullish Divergence

A bullish application occurs when price reaches a lower low while the Stochastic Oscillator produces a higher reading.

This divergence indicates that the decline is not being confirmed by the oscillator.

The book demonstrates a bullish divergence together with candlestick evidence as an indication that the downward pressure was weakening.

---

## 3. Bearish Divergence

A bearish application occurs when price reaches a higher high while the Stochastic Oscillator fails to reach a corresponding new high.

This divergence indicates weakening upward momentum.

The book demonstrates bearish divergence occurring together with bearish candlestick evidence.

---

## 4. Bullish %K/%D Crossover

Some analysts use a bullish crossover as an additional signal.

This occurs when:

%K crosses above %D.

The book demonstrates that the importance of this crossover increases when it occurs together with an oversold reading.

---

## 5. Bearish %K/%D Crossover

A bearish crossover occurs when:

%K crosses below %D.

The book presents this crossover as additional confirmation of a bearish market move.

---

## 6. Candlestick Confirmation

The Stochastic Oscillator can be used together with Japanese candlesticks.

The book's examples show combinations involving:

- Hammers
- Doji
- Dark Cloud Cover
- Morning Star
- Bullish or bearish divergence
- %K/%D crossovers

These combinations provide additional technical evidence.

---

## 7. Signal Confirmation

The examples demonstrate that one technical indication can be supported by another.

A candlestick signal may appear first, while the Stochastic Oscillator subsequently provides confirmation through:

- Divergence
- A %K/%D crossover
- An overbought or oversold reading

The interpretation should therefore consider the complete technical evidence shown by the market.