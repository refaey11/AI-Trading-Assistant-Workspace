# Stochastic Oscillator — Examples

## Example 1 — Dow Jones Industrial Average

### Exhibit 14.4

The Dow Jones Industrial Average example demonstrates bearish divergence using the Stochastic Oscillator and Japanese candlesticks.

A Doji appeared on January 3 after a long white candlestick.

The Doji reached a new price high above the highs seen in December.

However, the Stochastic Oscillator did not rise with the new price high.

This created bearish divergence.

The bearish divergence confirmed the warning provided by the Doji.

---

## Example 2 — Copper Weekly

### Exhibit 14.5

The Copper weekly example demonstrates bullish divergence and a bullish %K/%D crossover.

The market had previously formed a solid bottom after a Hammer.

A series of additional Hammers appeared in early 1990.

Hammer B reached a lower price low than Hammer A.

However, the Stochastic reading at B was higher than the reading at A.

This created bullish divergence.

There was also a bullish crossover when the %K line moved above the %D line.

The importance of the crossover increased because it occurred in the oversold region below 25%.

The combination of:

- Hammer-like candlestick signals
- Bullish divergence
- Bullish %K/%D crossover
- Oversold condition

provided strong technical evidence that the downtrend was ending.

---

## Example 3 — S&P June 1990

### Exhibit 14.6

Two candlesticks on April 2 and April 16 formed a Dark Cloud Cover pattern.

The black candlestick on April 16 pushed prices above the March highs.

This created a new price high.

However, the Stochastic Oscillator did not make a corresponding new high.

This created bearish divergence.

The Dark Cloud Cover and bearish divergence both warned of difficulty in continuing the market advance.

The following decline received additional confirmation when the faster %K line crossed below the slower %D line.

---

## Example 4 — British Pound June 1990

### Exhibit 14.7

During the week of March 19, an imperfect Morning Star appeared.

The third white candlestick did not penetrate deeply enough into the first black candlestick to form a perfect Morning Star.

The market subsequently reached a new price low.

However, the Stochastic Oscillator did not make a new low.

This produced bullish divergence.

The bullish divergence was later confirmed when the %K line crossed above the %D line.

The example demonstrates how other technical evidence can help evaluate an imperfect candlestick pattern.