# TC017 — Stochastic Oscillator Backtesting

## Purpose

Use historical chart data to examine how the Stochastic Oscillator signals described in the source material behaved when combined with price action and Japanese candlestick signals.

## Signals to Record

Record the following when they occur:

### Bullish Divergence

- Price makes a lower low.
- Stochastic makes a higher reading.

### Bearish Divergence

- Price makes a higher high.
- Stochastic makes a lower reading.

### Bullish Crossover

- %K crosses above %D.

### Bearish Crossover

- %K crosses below %D.

### Oversold Condition

- Stochastic reading is below the 25% level used in the examples.

## Additional Evidence

Record whether a relevant Japanese candlestick pattern appears at or near the Stochastic signal.

Examples from the source material include:

- Hammer
- Doji
- Dark Cloud Cover
- Morning Star

## Backtest Record

For every historical occurrence, record:

- Market
- Date
- Timeframe
- Price extreme
- Stochastic reading
- Divergence type, if present
- %K/%D crossover, if present
- Overbought/oversold condition
- Candlestick pattern, if present
- Subsequent market movement

## Interpretation

The purpose is to determine how the Stochastic evidence behaved when combined with other technical evidence, as demonstrated by the examples in the source material.

Do not introduce additional indicators or trading rules that are not contained in the source material.