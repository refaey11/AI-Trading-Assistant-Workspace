-- TC017 — Stochastic Oscillator

CREATE TABLE stochastic_oscillator (
    id INTEGER PRIMARY KEY,
    concept_code VARCHAR(20) NOT NULL,
    indicator_name VARCHAR(100) NOT NULL,
    indicator_min DECIMAL(5,2),
    indicator_max DECIMAL(5,2),
    common_periods VARCHAR(50),
    fast_k_description TEXT,
    slow_k_description TEXT,
    d_description TEXT,
    formula TEXT,
    oversold_reference DECIMAL(5,2),
    bullish_divergence TEXT,
    bearish_divergence TEXT,
    bullish_crossover TEXT,
    bearish_crossover TEXT,
    source_reference TEXT
);

INSERT INTO stochastic_oscillator (
    id,
    concept_code,
    indicator_name,
    indicator_min,
    indicator_max,
    common_periods,
    fast_k_description,
    slow_k_description,
    d_description,
    formula,
    oversold_reference,
    bullish_divergence,
    bearish_divergence,
    bullish_crossover,
    bearish_crossover,
    source_reference
)
VALUES (
    1,
    'TC017',
    'Stochastic Oscillator',
    0,
    100,
    '9, 14, 21',
    'Raw or fast Stochastic line; the more sensitive line.',
    'Moving average of the most recent three %K values.',
    'Moving average of the most recent three slow %K values.',
    '((Close - Low of N) / (High of N - Low of N)) * 100',
    25,
    'Price makes a lower low while the Stochastic reading is higher.',
    'Price makes a higher high while the Stochastic reading is lower.',
    '%K crosses above %D.',
    '%K crosses below %D.',
    'Chapter 14 — Stochastic Oscillator'
);