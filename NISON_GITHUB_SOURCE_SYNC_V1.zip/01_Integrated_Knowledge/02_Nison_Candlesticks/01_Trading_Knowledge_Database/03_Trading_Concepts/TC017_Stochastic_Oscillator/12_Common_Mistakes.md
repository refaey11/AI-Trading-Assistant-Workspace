# Common Mistakes — Stochastic Oscillator

## 1. Using the Stochastic Oscillator Alone

The book demonstrates that oscillator signals are more useful when combined with other technical evidence.

The Stochastic Oscillator should not automatically be treated as a guaranteed reversal signal.

Candlestick evidence can provide additional confirmation.

---

## 2. Ignoring Divergence

A common mistake is to focus only on the price movement and ignore whether the Stochastic Oscillator confirms the new extreme.

### Negative Divergence

Price reaches a new high while the Stochastic Oscillator fails to reach a new high.

This indicates weakening market strength.

### Positive Divergence

Price reaches a new low while the Stochastic Oscillator fails to reach a new low.

This indicates that selling pressure may be weakening.

---

## 3. Ignoring the K% / D% Crossover

Some analysts use the relationship between K% and D% as an additional signal.

- K% crossing above D% → bullish indication.
- K% crossing below D% → bearish indication.

Ignoring this confirmation can result in overlooking an important part of the Stochastic analysis described in the book.

---

## 4. Ignoring the Overbought / Oversold Area

A crossover becomes more important when it occurs in an appropriate extreme area.

The book specifically notes that a positive crossover is more significant when it occurs below 25%.

Therefore, the location of the Stochastic reading should be considered together with the crossover.

---

## 5. Treating an Imperfect Candlestick Pattern as Conclusive

The British Pound example contains an imperfect Morning Star.

The book explains that before deciding how important an imperfect candlestick pattern is, other technical evidence should be reviewed.

In this example:

- Price reached a new low.
- The Stochastic Oscillator did not make a new low.
- Positive divergence appeared.
- K% later crossed above D%.

The additional evidence supported the bullish interpretation.

---

## 6. Ignoring Conflicting Evidence

A candlestick pattern may provide a warning, but other technical tools should be reviewed before treating the signal as decisive.

The book specifically explains that imperfect or potentially misleading candlestick evidence can be evaluated using additional technical analysis tools.

---

## 7. Entering Before Confirmation

The book's examples demonstrate that confirmation may come after the initial candlestick warning.

For example:

- A candlestick may provide an early bullish or bearish indication.
- Stochastic divergence may provide additional evidence.
- A K% / D% crossover may provide further confirmation.

Therefore, the timing of each confirmation should be considered rather than treating every initial signal as a complete trading signal.

---

## 8. Ignoring Confluence

The strongest examples in the book involve several technical signals agreeing with one another.

A trader should pay attention when the following occur together:

- Candlestick signal.
- Price extreme.
- Stochastic divergence.
- K% / D% crossover.
- Overbought or oversold reading.

The book uses this combination of evidence to demonstrate why the Stochastic Oscillator can be an effective complement to Japanese candlestick analysis.