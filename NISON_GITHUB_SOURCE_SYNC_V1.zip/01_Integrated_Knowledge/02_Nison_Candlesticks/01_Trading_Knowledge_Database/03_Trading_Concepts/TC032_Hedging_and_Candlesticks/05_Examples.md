# 05 — Examples

## TC032 — Hedging and Candlesticks

### Source
Chapter 19 — Hedging and Candlesticks
Pages 338–343

---

## Example 19.1 — Soybeans

### 1988

Prices rose sharply during 1988, approximately doubling from $6 to $11.

Near the top of the advance, a Bearish Engulfing Pattern appeared.

The chapter explains that the Bearish Engulfing Pattern was a turning-point signal from the candlestick perspective, although it was not a Western turning point according to the traditional Western analysis.

### Hedging Application

The Bearish Engulfing Pattern could have been used as a signal to:

- Begin a Short Hedge.
- Increase the hedge ratio if the position was not fully hedged.

---

### 1989

Another Bearish Engulfing Pattern warned of a turning point.

Short Hedgers could have placed hedge orders at this point.

Several weeks later, a Window appeared as a candlestick signal confirming the decline.

### Hedging Application

The Window indicated that Short Hedgers should increase the hedge ratio unless the hedge ratio had already reached 100%.

---

### Piercing Pattern

A Piercing Pattern appeared in October.

It was used as a signal to gradually retreat from the hedge.

For those seeking to hedge against a rising market, the Piercing Pattern was a signal to begin the hedge.

---

# Example 19.2 — Figure 19.2

## Positive Candlestick Signals

The chapter describes a group of positive candlestick signals appearing during the last weeks of September and the first weeks of October 1988.

The signals included:

- Bullish Engulfing Pattern.
- Tweezers Bottom.
- White Belt Hold.

The white candle:

- Closed at its high.
- Engulfed the previous five candles.

### Hedging Application

For Long Hedgers, this was the point to:

- Begin the hedge.
- Add new percentages to an existing hedge.

---

## Early 1989

Long Hedgers could reduce the hedge after the appearance of the pattern described as a turning-point pattern.

The pattern consisted of:

- A long white candle.
- Followed by a Doji.

The chapter explains that a Doji following a long white candle often indicates a top.

### Hedging Application

Long Hedgers could reduce the hedge after this signal appeared.

---

# Example 19.3 — Crude Oil

## Hammer

A Hammer appeared on July 5.

It provided the first evidence of a possible turning-point bottom.

The Hammer formed a gap below the previous bar.

The chapter states that the Hammer should not be considered a positive pattern unless it was confirmed by another positive pattern during the following sessions.

---

## Bullish Engulfing Pattern

A Bullish Engulfing Pattern subsequently appeared.

The white candle on July 9 engulfed two black candles.

The pattern confirmed the positive interpretation of the Hammer.

### Hedging Application

At this point, consumers of crude oil acting as Long Hedgers should begin considering:

- Placing hedge orders.
- Increasing the existing hedge.

---

## Momentum

The lows at A, B, and C were not confirmed by decreasing momentum values.

The chapter explains that this indicated that the speed of selling was beginning to decrease.

The market still had downward momentum, but the rate of the decline was decreasing.

---

## Falling Wedge

A Falling Wedge from Western technical analysis was broken to the upside.

At the same time, the oscillator moved toward positive values.

### Hedging Application

When the Falling Wedge was broken to the upside, Long Hedgers could increase their hedge orders.

---

## Falling Wedge Price Objective

The price objective of the Falling Wedge was the point where the wedge began.

The chapter gives two possible interpretations of where the wedge began:

- The June high near $19.
- The May 18 high near $20.

The chapter notes that the interpretation depends on the analyst's point of view.

---

## Chapter Conclusion From the Examples

The chapter states that candlestick analysis can provide an early warning of a change in market direction.

It also states that combining candlestick analysis with Western technical analysis can be effective.

The more technical signals that support one another, the greater the probability of correctly identifying a change in trend.