# 12 — Common Mistakes

## TC032 — Hedging and Candlesticks

### Source
Chapter 19 — Hedging and Candlesticks

### Pages
338–343

---

## Points of Attention From Chapter 19

### 1. Hedging Should Not Be Viewed as a Profit Strategy

The chapter states that hedging cannot be viewed as a strategy for making profits.

---

### 2. The Hammer Requires Confirmation

In the Crude Oil example, the Hammer provided the first evidence of a possible turning-point bottom.

The chapter states that it should not be considered a positive pattern unless it is confirmed by another positive pattern during the following sessions.

A Bullish Engulfing Pattern subsequently provided confirmation.

---

### 3. The Hedge Does Not Have to Be Built at One Price

The chapter explains that the cash position does not necessarily have to be completely hedged at one price.

The hedger may build the hedge gradually.

---

### 4. A 100% Hedge Can Be Adjusted

The chapter explains that candlesticks can also be used when the cash position is already 100% hedged.

In the corn example, a strong positive turning-point signal could lead the hedger to gradually retreat from the existing hedge.

---

### 5. Candlestick Analysis Can Be Combined With Western Analysis

The Crude Oil example combines candlestick evidence with:

- Momentum.
- Falling Wedge.
- Oscillator.

The chapter explains that combining candlestick analysis with Western technical analysis can be effective.

---

## Source Limitation

This file contains only points directly supported by the supplied Chapter 19 material.

No additional common mistakes have been added.