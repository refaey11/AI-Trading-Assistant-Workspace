# 04 — Trading Application

## TC032 — Hedging and Candlesticks

### Source
Chapter 19 — Hedging and Candlesticks
Pages 338–343

---

## 1. Identify the Hedger

### Short Hedger

Risk:

Falling prices in the cash position.

The chapter mentions:

- Copper producer.
- Farmer.
- Corn producer.

Possible instruments:

- Short Futures.
- Put Options.

### Long Hedger

Risk:

Rising prices in the cash position.

The chapter gives the example of a cotton-shirt manufacturer who needs to purchase cotton.

Possible instruments:

- Long Futures.
- Call Options.

---

## 2. Determine the Hedge Ratio

The cash position does not necessarily have to be completely hedged at one price.

The hedger may build the hedge gradually.

The hedger must consider what percentage of the exposure should be hedged.

Candlesticks can help provide ideas about when the hedge ratio should be adjusted.

---

## 3. Short Hedge Application

A Bearish Engulfing Pattern can be used as a signal to:

- Start a Short Hedge.
- Increase the hedge ratio if the position is not fully hedged.

### Soybeans Example

In 1988, a Bearish Engulfing Pattern appeared near the top of a major advance.

The chapter explains that this pattern provided a turning-point signal from the candlestick perspective.

The pattern could have been used as a signal to begin a Short Hedge or increase the hedge ratio if the position was not fully hedged.

---

## 4. Additional Bearish Signal

In 1989, another Bearish Engulfing Pattern warned of a turning point.

Short Hedgers could have placed hedge orders at this point.

Several weeks later, a Window appeared as a candlestick signal confirming the decline.

The Short Hedgers could then increase the hedge ratio unless the position was already 100% hedged.

---

## 5. Reducing a Hedge

A Piercing Pattern appeared in October.

The chapter describes it as a signal to gradually retreat from the hedge.

For those seeking to hedge against a rising market, the Piercing Pattern was a signal to begin the hedge.

---

## 6. Long Hedge Application

Positive candlestick signals appeared during the last weeks of September and the first weeks of October 1988.

The signals included:

- Bullish Engulfing Pattern.
- Tweezers Bottom.
- White Belt Hold.

The white candle closed at its high and engulfed the previous five candles.

### Hedging Application

For Long Hedgers, this was the point to:

- Begin the hedge.
- Add new percentages to the existing hedge.

---

## 7. Reducing a Long Hedge

In early 1989, a long white candle was followed by a Doji.

The chapter explains that a Doji following a long white candle is often an indication of a top.

Long Hedgers could reduce the hedge after this turning-point indication appeared.

---

## 8. Crude Oil Application

The Crude Oil example demonstrates the use of candlesticks together with Western technical analysis.

### Step 1 — Hammer

A Hammer appeared on July 5.

It provided the first evidence of a possible turning-point bottom.

The Hammer formed a gap below the previous bar.

The chapter states that it should not be considered a positive pattern unless it was confirmed by another positive pattern during the following sessions.

---

### Step 2 — Bullish Engulfing Pattern

A Bullish Engulfing Pattern subsequently appeared.

The white candle on July 9 engulfed two black candles.

This provided the second evidence and confirmed the positive interpretation of the Hammer.

At this point, consumers of crude oil acting as Long Hedgers should begin thinking about:

- Placing hedge orders.
- Increasing the existing hedge.

---

### Step 3 — Momentum

The lows at A, B, and C were not confirmed by decreasing momentum values.

This indicated that the speed of selling was beginning to decrease.

The market still had downward momentum, but the rate of the decline was decreasing.

---

### Step 4 — Falling Wedge and Oscillator

The Falling Wedge was broken in the upward direction.

At the same time, the oscillator moved toward positive values.

When the Falling Wedge was broken, Long Hedgers could increase their hedge orders.

---

## 9. Combining Candlestick and Western Analysis

The chapter demonstrates the use of candlestick analysis together with Western technical analysis.

The Crude Oil example includes:

- Hammer.
- Bullish Engulfing Pattern.
- Momentum.
- Falling Wedge.
- Oscillator.

The chapter states that combining candlestick analysis with Western technical analysis can be effective.

The chapter also states that the more technical signals that support one another, the greater the probability of correctly identifying a change in trend.