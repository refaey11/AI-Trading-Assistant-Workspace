# 02 — Core Rules

## TC032 — Hedging and Candlesticks

### Source
Chapter 19 — Hedging and Candlesticks
Pages 338–343

---

## 1. Hedging and Cash-Position Risk

A hedger protects a cash position by taking an opposite position in the futures or options market.

---

## 2. Short Hedger

A Short Hedger is exposed to risk resulting from falling prices in the cash position.

The chapter mentions:

- Copper producer.
- Farmer.
- Corn producer.

The Short Hedger can use:

- Short Futures.
- Put Options.

If prices decline, the decrease in the value of the cash position can be partially offset by profits from futures and options positions.

---

## 3. Long Hedger

A Long Hedger is exposed to risk resulting from rising prices in the cash position.

The chapter gives the example of a cotton-shirt manufacturer who needs to purchase cotton.

The Long Hedger can use:

- Long Futures.
- Call Options.

If prices rise, the higher cash purchase price can be partially offset by profits from futures and options positions.

---

## 4. Gradual Hedging

The cash position does not necessarily have to be completely hedged at one price.

The hedger may build the hedge gradually.

The hedger therefore needs to determine what percentage of the exposure should be hedged.

---

## 5. Adjusting the Hedge

Candlesticks can help provide ideas about when the hedge ratio should be adjusted.

A candlestick signal may be used in deciding when to:

- Begin a hedge.
- Increase the hedge.
- Gradually reduce the hedge.

---

## 6. 100% Hedged Position

Candlesticks can also be used when the cash position is already 100% hedged.

If a strong reversal signal appears against the direction of the existing hedge, the hedger may gradually retreat from the hedge.

---

## 7. Candlestick Reversal Signals

The chapter uses reversal signals as indications of possible turning points.

Examples include:

- Bearish Engulfing Pattern.
- Piercing Pattern.
- Bullish Engulfing Pattern.
- Doji.
- Hammer.

---

## 8. Confirmation

The chapter demonstrates that an initial candlestick signal may require confirmation.

In the crude-oil example, the Hammer was the first evidence of a possible bottom and should not be considered a positive pattern until confirmed by another positive pattern.

The Bullish Engulfing Pattern subsequently confirmed the Hammer.

---

## 9. Combining Technical Evidence

The chapter demonstrates the use of candlestick analysis together with Western technical analysis.

The crude-oil example combines:

- Candlestick signals.
- Momentum.
- Falling Wedge.
- Oscillator.

The chapter states that the more technical signals support one another, the greater the probability of correctly identifying a change in trend.

---

## 10. Hedging Is Not a Profit Strategy

The chapter explicitly states that hedging should not be viewed as a strategy for making profits.