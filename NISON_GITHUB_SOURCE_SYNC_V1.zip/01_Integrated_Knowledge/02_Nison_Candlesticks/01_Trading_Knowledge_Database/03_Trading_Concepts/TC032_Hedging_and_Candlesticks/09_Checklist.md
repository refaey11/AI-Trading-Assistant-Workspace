# 09 — Checklist

## TC032 — Hedging and Candlesticks

### Source
Chapter 19 — Hedging and Candlesticks

### Pages
338–343

---

## Hedging Position

- [ ] Identify whether the position is a Short Hedger.
- [ ] Identify whether the position is a Long Hedger.
- [ ] Identify the risk affecting the cash position.
- [ ] Identify the current hedge ratio.

---

## Short Hedger

- [ ] Falling prices are the relevant cash-position risk.
- [ ] Short Futures may be used.
- [ ] Put Options may be used.
- [ ] Consider a Short Hedge when bearish turning-point evidence appears.
- [ ] Consider increasing the hedge ratio when bearish evidence supports the decision.
- [ ] Consider gradually reducing the hedge when a positive reversal signal appears.

---

## Long Hedger

- [ ] Rising prices are the relevant cash-position risk.
- [ ] Long Futures may be used.
- [ ] Call Options may be used.
- [ ] Consider beginning the hedge when bullish evidence appears.
- [ ] Consider adding to an existing hedge when bullish evidence appears.
- [ ] Consider reducing the hedge after a turning-point indication such as the long white candle followed by a Doji described in the chapter.

---

## Hedge Ratio

- [ ] Determine whether the position is partially hedged.
- [ ] Determine whether the position is 100% hedged.
- [ ] Consider whether the hedge ratio should be adjusted.
- [ ] Consider gradual adjustment when appropriate.

---

## Candlestick Evidence

Check for the signals discussed in Chapter 19:

- [ ] Bearish Engulfing Pattern.
- [ ] Window.
- [ ] Piercing Pattern.
- [ ] Bullish Engulfing Pattern.
- [ ] Tweezers Bottom.
- [ ] White Belt Hold.
- [ ] Doji.
- [ ] Hammer.

---

## Confirmation

- [ ] Determine whether an initial candlestick signal requires confirmation.
- [ ] In the Crude Oil example, do not treat the Hammer as a positive pattern before confirmation.
- [ ] Check for the subsequent Bullish Engulfing Pattern.

---

## Additional Technical Evidence

When applicable to the examples in Chapter 19:

- [ ] Momentum.
- [ ] Falling Wedge.
- [ ] Oscillator.

---

## Final Principle

- [ ] Consider the candlestick evidence together with supporting technical evidence.
- [ ] Remember that the chapter states that hedging should not be viewed as a strategy for making profits.