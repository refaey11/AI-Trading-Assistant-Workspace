# 10 — Backtesting

## TC032 — Hedging and Candlesticks

### Source
Chapter 19 — Hedging and Candlesticks

### Pages
338–343

---

## Backtesting Information

Chapter 19 does not provide a formal statistical backtesting study.

The supplied pages do not provide:

- Win Rate.
- Profit Factor.
- Sharpe Ratio.
- Maximum Drawdown.
- Number of winning or losing trades.
- Statistical performance results.

Therefore, no backtesting statistics are attributed to Chapter 19.

---

## Historical Examples

The chapter provides historical examples showing how candlestick signals could have been used in hedging decisions.

The examples include:

- Soybeans.
- The market shown in Figure 19.2.
- Crude Oil.

---

## Soybeans

The chapter describes:

- Bearish Engulfing Pattern near a major advance.
- Another Bearish Engulfing Pattern in 1989.
- Window appearing several weeks later as confirmation of the decline.
- Piercing Pattern appearing in October.

These signals are discussed in relation to:

- Starting a Short Hedge.
- Increasing the hedge ratio.
- Gradually retreating from the hedge.
- Beginning a hedge for a rising market.

---

## Figure 19.2 Example

The chapter describes:

- Bullish Engulfing Pattern.
- Tweezers Bottom.
- White Belt Hold.
- A long white candle followed by a Doji.

These signals are discussed in relation to:

- Beginning a Long Hedge.
- Adding to an existing Long Hedge.
- Reducing the hedge.

---

## Crude Oil

The chapter describes the following sequence:

- Hammer on July 5.
- Bullish Engulfing Pattern as confirmation.
- Momentum evidence.
- Falling Wedge breakout.
- Oscillator moving toward positive values.

These signals are discussed in relation to:

- Beginning to consider hedge orders.
- Increasing the hedge for Long Hedgers.

---

## Chapter Conclusion Relevant to Testing

The chapter states that candlestick analysis can provide an early warning of a change in market direction.

It also states that combining candlestick analysis with Western technical analysis can be effective.

The chapter further states that the more technical signals support one another, the greater the probability of correctly identifying a change in trend.

---

## Source Limitation

Chapter 19 provides examples of historical hedging decisions, but it does not provide a formal statistical backtesting methodology or statistical results.

No additional backtesting rules or statistics are added to this file.