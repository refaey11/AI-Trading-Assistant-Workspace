# 01 — Description

## TC032 — Hedging and Candlesticks

### Chapter 19
### Hedging and Candlesticks

### Source Pages
338–343

---

## Description

This chapter discusses the use of candlestick analysis in hedging decisions.

The chapter explains that hedgers can use candlestick patterns as a valuable tool in the decision-making process, particularly for determining:

- When to initiate a hedge.
- When to leave a hedge.
- When to adjust an existing hedge.
- When to increase the hedge ratio.
- When to gradually reduce the hedge.

The chapter focuses on the idea that candlestick patterns can provide signals of possible changes in market direction and can therefore assist the hedger in timing hedging decisions.

---

## Short Hedger

A Short Hedger is exposed to risk resulting from falling prices affecting the cash position.

The chapter gives examples such as:

- A copper producer.
- A farmer.
- A corn producer.

The chapter explains that a Short Hedger can use:

- Short Futures.
- Put Options.

If prices decline, the decrease in the value of the cash position may be partially offset by profits from futures and options positions.

---

## Long Hedger

A Long Hedger is exposed to risk resulting from rising prices affecting the cash position.

The chapter gives the example of a cotton-shirt manufacturer who needs to purchase cotton for production.

The chapter explains that a Long Hedger can use:

- Long Futures.
- Call Options.

If cotton prices rise, the higher cash purchase price may be partially offset by profits from futures and options positions.

---

## Hedge Ratio

The chapter explains that a cash position does not necessarily have to be completely hedged at one price.

A hedger may prefer to build the hedge gradually.

Therefore, the hedger must consider what percentage of the exposure should be hedged.

The chapter explains that candlesticks can help provide ideas about when the hedge ratio should be adjusted.

Candlesticks can also be used when the cash position is already 100% hedged.

---

## Candlesticks and Hedging Decisions

The chapter presents candlestick patterns as a tool that can provide early indications of possible turning points.

These signals can assist the hedger in deciding whether to:

- Begin a hedge.
- Increase an existing hedge.
- Gradually reduce an existing hedge.

The chapter also demonstrates the use of candlestick signals together with Western technical analysis.

---

## Main Examples

The chapter presents examples involving:

- Soybeans.
- The market shown in Figure 19.2.
- Crude Oil.

The examples demonstrate how candlestick signals were used in relation to hedging decisions.

---

## Main Candlestick Signals Mentioned

The chapter discusses the following candlestick patterns and signals:

- Bearish Engulfing Pattern.
- Window.
- Piercing Pattern.
- Bullish Engulfing Pattern.
- Tweezers Bottom.
- White Belt Hold.
- Doji.
- Hammer.

The crude-oil example also includes Western technical analysis involving:

- Momentum.
- Falling Wedge.
- Oscillator.

---

## Chapter Conclusion

The chapter concludes from its examples that candlestick analysis can provide an early warning of a change in market direction.

It also explains that combining candlestick analysis with Western technical analysis can be effective.

The chapter states that the greater the number of technical signals supporting one another, the greater the probability of correctly identifying a change in trend.