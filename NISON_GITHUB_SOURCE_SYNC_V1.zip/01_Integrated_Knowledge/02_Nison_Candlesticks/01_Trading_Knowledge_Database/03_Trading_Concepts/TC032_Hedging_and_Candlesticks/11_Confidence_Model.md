# 11 — Confidence Model

## TC032 — Hedging and Candlesticks

### Source
Chapter 19 — Hedging and Candlesticks

### Pages
338–343

---

## Confidence Model

Chapter 19 does not provide a numerical confidence model.

The chapter does not assign numerical confidence values to candlestick signals.

---

## Supporting Signals

The chapter explains that the more technical signals that support one another, the greater the probability of correctly identifying a change in trend.

The Crude Oil example contains several supporting signals:

- Hammer.
- Bullish Engulfing Pattern.
- Momentum evidence.
- Falling Wedge breakout.
- Oscillator movement.

---

## Source Limitation

No numerical confidence score or confidence percentage is provided in the supplied Chapter 19 material.