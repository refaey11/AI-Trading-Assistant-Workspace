# 03 — Psychology

## TC032 — Hedging and Candlesticks

### Source
Chapter 19 — Hedging and Candlesticks
Pages 338–343

---

## 1. Active Hedging Decisions

The chapter explains that hedgers now make decisions about:

- When to hedge.
- How much of their exposure to hedge.
- When to adjust the hedge.

The chapter presents candlesticks as a tool that can assist this decision-making process.

---

## 2. Risk Awareness

The hedger must consider the risk affecting the cash position.

A Short Hedger is concerned with falling prices.

A Long Hedger is concerned with rising prices.

---

## 3. Gradual Adjustment

The chapter explains that a hedge does not necessarily have to remain at one fixed level.

The hedger may gradually build the hedge.

The hedger may also gradually retreat from an existing hedge when a reversal signal appears.

---

## 4. Recognizing Possible Turning Points

Candlestick reversal patterns can provide indications of possible turning points.

The chapter presents:

- Bearish Engulfing Pattern as evidence near a possible top.
- Bullish Engulfing Pattern as evidence near a possible bottom.
- Hammer as early evidence of a possible bottom.
- Doji following a long white candle as often being a top indication.

---

## 5. Waiting for Confirmation

The crude-oil example demonstrates the importance of confirmation.

The Hammer appeared first as evidence of a possible bottom.

The chapter states that it should not be considered a positive pattern until another positive pattern confirms it.

The later Bullish Engulfing Pattern provided that confirmation.

---

## 6. Multiple Supporting Signals

The chapter demonstrates that several technical signals can support the same interpretation.

In the crude-oil example, the evidence included:

- Hammer.
- Bullish Engulfing Pattern.
- Momentum behavior.
- Falling Wedge breakout.
- Oscillator movement.

The chapter concludes that greater agreement between technical signals increases the probability of correctly identifying a change in trend.

---

## 7. Hedging Objective

The chapter states that hedging should not be considered a strategy for making profits.