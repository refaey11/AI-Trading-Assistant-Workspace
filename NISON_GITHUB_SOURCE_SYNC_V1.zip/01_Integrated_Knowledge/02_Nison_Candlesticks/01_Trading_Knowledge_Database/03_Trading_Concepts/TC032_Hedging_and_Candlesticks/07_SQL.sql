-- =========================================================
-- TC032 — Hedging and Candlesticks
-- Chapter 19 — Hedging and Candlesticks
-- Source Pages: 338–343
-- =========================================================


-- =========================================================
-- CONCEPT
-- =========================================================

CREATE TABLE tc032_hedging_candlesticks (
    id INTEGER PRIMARY KEY,
    concept_code VARCHAR(20) NOT NULL,
    concept_name VARCHAR(150) NOT NULL,
    chapter INTEGER NOT NULL,
    source_pages VARCHAR(50) NOT NULL
);

INSERT INTO tc032_hedging_candlesticks
(
    id,
    concept_code,
    concept_name,
    chapter,
    source_pages
)
VALUES
(
    1,
    'TC032',
    'Hedging and Candlesticks',
    19,
    '338-343'
);


-- =========================================================
-- HEDGERS
-- =========================================================

CREATE TABLE tc032_hedgers (
    id INTEGER PRIMARY KEY,
    concept_code VARCHAR(20) NOT NULL,
    hedger_type VARCHAR(50) NOT NULL,
    risk TEXT NOT NULL,
    examples TEXT,
    instruments TEXT
);

INSERT INTO tc032_hedgers
(
    id,
    concept_code,
    hedger_type,
    risk,
    examples,
    instruments
)
VALUES
(
    1,
    'TC032',
    'Short Hedger',
    'Risk resulting from falling prices affecting the cash position',
    'Copper producer; Farmer; Corn producer',
    'Short Futures; Put Options'
),
(
    2,
    'TC032',
    'Long Hedger',
    'Risk resulting from rising prices affecting the cash position',
    'Cotton-shirt manufacturer',
    'Long Futures; Call Options'
);


-- =========================================================
-- HEDGE MANAGEMENT
-- =========================================================

CREATE TABLE tc032_hedge_management (
    id INTEGER PRIMARY KEY,
    concept_code VARCHAR(20) NOT NULL,
    rule_name VARCHAR(100) NOT NULL,
    description TEXT NOT NULL
);

INSERT INTO tc032_hedge_management
(
    id,
    concept_code,
    rule_name,
    description
)
VALUES
(
    1,
    'TC032',
    'Gradual Hedging',
    'The cash position does not necessarily have to be completely hedged at one price. The hedger may build the hedge gradually.'
),
(
    2,
    'Hedge Ratio',
    'TC032',
    'The hedger considers what percentage of the exposure should be hedged.'
),
(
    3,
    'Candlestick Adjustment',
    'TC032',
    'Candlesticks can help provide ideas about when the hedge ratio should be adjusted.'
),
(
    4,
    '100 Percent Hedge',
    'TC032',
    'Candlesticks can also be used when the cash position is already 100 percent hedged.'
),
(
    5,
    'Hedging Is Not A Profit Strategy',
    'TC032',
    'The chapter states that hedging cannot be viewed as a strategy for making profits.'
);


-- =========================================================
-- CANDLESTICK SIGNALS
-- =========================================================

CREATE TABLE tc032_candlestick_signals (
    id INTEGER PRIMARY KEY,
    concept_code VARCHAR(20) NOT NULL,
    signal_name VARCHAR(100) NOT NULL,
    direction VARCHAR(50),
    role TEXT NOT NULL
);

INSERT INTO tc032_candlestick_signals
(
    id,
    concept_code,
    signal_name,
    direction,
    role
)
VALUES
(
    1,
    'TC032',
    'Bearish Engulfing Pattern',
    'Bearish',
    'Turning-point signal used in relation to starting or increasing a Short Hedge.'
),
(
    2,
    'TC032',
    'Window',
    'Bearish',
    'Candlestick signal confirming the decline.'
),
(
    3,
    'TC032',
    'Piercing Pattern',
    'Positive',
    'Signal used to gradually retreat from a hedge and, for those hedging a rising market, to begin the hedge.'
),
(
    4,
    'TC032',
    'Bullish Engulfing Pattern',
    'Bullish',
    'Confirmed the positive interpretation of the Hammer and was used in relation to beginning or increasing a Long Hedge.'
),
(
    5,
    'TC032',
    'Tweezers Bottom',
    'Positive',
    'Positive candlestick signal appearing with other positive signals.'
),
(
    6,
    'TC032',
    'White Belt Hold',
    'Positive',
    'Positive candlestick signal. The white candle closed at its high and engulfed the previous five candles.'
),
(
    7,
    'TC032',
    'Doji',
    'Turning Point',
    'A Doji following a long white candle was described as often being a top indication.'
),
(
    8,
    'TC032',
    'Hammer',
    'Positive',
    'First evidence of a possible turning-point bottom. The chapter states that it should be confirmed by another positive pattern.'
);


-- =========================================================
-- WESTERN TECHNICAL ANALYSIS
-- =========================================================

CREATE TABLE tc032_western_analysis (
    id INTEGER PRIMARY KEY,
    concept_code VARCHAR(20) NOT NULL,
    tool_name VARCHAR(100) NOT NULL,
    role TEXT NOT NULL
);

INSERT INTO tc032_western_analysis
(
    id,
    concept_code,
    tool_name,
    role
)
VALUES
(
    1,
    'TC032',
    'Momentum',
    'The lows at A, B, and C were not confirmed by decreasing momentum values.'
),
(
    2,
    'TC032',
    'Falling Wedge',
    'The Falling Wedge was broken in the upward direction.'
),
(
    3,
    'TC032',
    'Oscillator',
    'The oscillator moved toward positive values at the same time as the upward Falling Wedge breakout.'
);


-- =========================================================
-- HISTORICAL EXAMPLES
-- =========================================================

CREATE TABLE tc032_examples (
    id INTEGER PRIMARY KEY,
    concept_code VARCHAR(20) NOT NULL,
    example_code VARCHAR(20) NOT NULL,
    market VARCHAR(100),
    period VARCHAR(50),
    description TEXT
);

INSERT INTO tc032_examples
(
    id,
    concept_code,
    example_code,
    market,
    period,
    description
)
VALUES
(
    1,
    'TC032',
    '19.1',
    'Soybeans',
    '1988–1989',
    'Bearish Engulfing Pattern, Window, and Piercing Pattern are presented in relation to hedging decisions.'
),
(
    2,
    'TC032',
    '19.2',
    NULL,
    '1988–1989',
    'Bullish Engulfing Pattern, Tweezers Bottom, White Belt Hold, and a long white candle followed by a Doji are presented in relation to hedging decisions.'
),
(
    3,
    'TC032',
    '19.3',
    'Crude Oil',
    NULL,
    'Hammer, Bullish Engulfing Pattern, Momentum, Falling Wedge, and Oscillator are presented in relation to hedging decisions.'
);


-- =========================================================
-- CHAPTER CONCLUSION
-- =========================================================

CREATE TABLE tc032_conclusion (
    id INTEGER PRIMARY KEY,
    concept_code VARCHAR(20) NOT NULL,
    statement TEXT NOT NULL
);

INSERT INTO tc032_conclusion
(
    id,
    concept_code,
    statement
)
VALUES
(
    1,
    'TC032',
    'Candlestick analysis can provide an early warning of a change in market direction.'
),
(
    2,
    'TC032',
    'Combining candlestick analysis with Western technical analysis can be effective.'
),
(
    3,
    'TC032',
    'The more technical signals that support one another, the greater the probability of correctly identifying a change in trend.'
);