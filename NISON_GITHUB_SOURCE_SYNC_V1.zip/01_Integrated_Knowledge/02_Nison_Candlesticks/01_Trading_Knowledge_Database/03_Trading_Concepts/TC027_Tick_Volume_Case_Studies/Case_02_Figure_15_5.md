# Case Study 02 — Figure 15.5

## Figure

Exhibit 15.5 — Crude Oil, August 1990

## Market

Crude Oil — August 1990

## Chart Type

Intraday chart

## Main Tools

- Japanese Candlesticks
- Tick Volume

## Case Focus

This case demonstrates the use of tick volume with Japanese candlestick analysis in an intraday market.

## Price Movement

The price movement is evaluated together with changes in tick volume.

## Candlestick Evidence

Candlestick patterns provide the price-action evidence in the example.

The tick-volume information is used as additional evidence when interpreting the candlestick signals.

## Tick Volume

Tick volume provides information about the level of trading activity during the intraday periods shown in the chart.

Changes in tick volume are considered in relation to the price movement.

## Interpretation

The example demonstrates that tick volume can be used as complementary information when analyzing intraday candlestick behavior.

## Trading Lesson

The important relationship is:

Price Movement
+
Candlestick Evidence
+
Tick Volume

Tick volume should not be interpreted independently from the price and candlestick information.

## Source

Chapter 15 — Volume and Open Interest

Exhibit 15.5 — Crude Oil, August 1990