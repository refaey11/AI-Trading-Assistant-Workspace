# TC027 — Tick Volume Case Studies

## Purpose

This folder contains the tick-volume case studies presented in Chapter 15.

## Cases

### Case 01 — Figure 15.4

Market:
Cocoa — July 1990

Focus:
Tick Volume + Japanese Candlesticks

### Case 02 — Figure 15.5

Market:
Crude Oil — August 1990

Focus:
Tick Volume + Japanese Candlesticks

## Main Lesson

The cases demonstrate the use of tick volume as supporting information when analyzing intraday price movement and Japanese candlestick signals.

## Source

Steve Nison — Japanese Candlestick Charting Techniques

Chapter 15 — Volume and Open Interest