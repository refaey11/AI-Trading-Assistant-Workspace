# Chapter 18 — Examples

## Source

Japanese Candlestick Charting Techniques — Steve Nison

## Chapter

Chapter 18 — Candlesticks with Options

---

## Example 1 — Silver

### Market

Silver — September 1990

### Timeframe

Daily

### Initial Reversal Warnings

Two top-reversal warnings appeared in mid-May:

1. A Doji after a long white real body.
2. Three Black Crows.

### Market Reaction

A selloff followed these top-reversal formations.

Historic volatility expanded during the selloff.

### Reversal and Volatility Contraction

The selloff ended with a Harami Cross in early June.

After the Harami Cross:

- The price trend changed from lower to lateral.
- Volatility contracted as the market moved into a lateral environment.

### Chapter Interpretation

The Harami Cross could be viewed as a signal that the prior steep trend was ending and that a decline in volatility was possible.

---

## Example 2 — Sugar

### Market

Sugar — July 1990

### Analysis

A sharp rally developed in January.

During this rally:

- Implied volatility increased.
- Implied volatility followed an upward trend.

During much of February:

- Sugar traded within a relatively quiet range.
- The market was bounded in a narrow price range.
- Volatility declined.

### Candlestick Signal

A Hammer appeared on February 26.

The Hammer:

- Broke below a previous support area with its lower shadow.
- Made a new low that did not hold.

A later white candlestick helped maintain the lows.

The Hammer and the later low formed a Tweezer Bottom.

### Chapter Interpretation

The combination of bottom-reversal signals and low volatility suggested that price rallies could be accompanied by expanding volatility.

The example demonstrates how candlestick signals can assist in forecasting short-term movements in implied volatility.

---

## Example 3 — Cocoa

### Market

Cocoa — September 1990

### Market Context

Cocoa was in a major bull market that began in November 1989 at approximately $900.

The example combines:

- Elliott Wave analysis
- Fibonacci analysis
- Candlestick analysis
- Options

### Elliott Wave Structure

The exhibit showed the last three waves of an Elliott Wave count.

The top of Wave 3 was accompanied by a Shooting Star.

The bottom of Wave 4 was accompanied by a Bullish Piercing Line.

### Fibonacci Target

A Fibonacci relationship produced a Wave 5 target near $1,520.

The chapter therefore suggested looking for candlestick confirmation of a possible top near this target.

### Bearish Confirmation

In late May:

- Cocoa reached a high near $1,541.
- A Bearish Engulfing Pattern appeared.

The high was close to the Elliott Wave target near $1,520.

The combination provided evidence of a possible market top.

### Option Position

The example involved buying the $1,400 puts.

The major trend was still upward.

The author stated that, if he had been long, he would have been more comfortable liquidating long positions.

The limited-risk characteristic of the option made the bearish position possible despite the risk involved in attempting to pick a top.

### Risk Scenario

If the analysis of the top had been wrong and Cocoa had moved sharply higher, increased volatility could help mitigate adverse price action.

### Outcome

The Bearish Engulfing Pattern together with the Elliott fifth-wave analysis became an important peak.

---

## Main Lessons from the Examples

### Silver

Candlestick reversal signals can coincide with changes in historic volatility.

### Sugar

Candlestick bottom-reversal signals can assist in forecasting short-term movements in implied volatility.

### Cocoa

Candlestick confirmation can be combined with Elliott Wave and Fibonacci analysis to support an options position when attempting to identify a market top.

---

## Source Limitation

These examples describe specific historical markets and should not be treated as guaranteed trading rules.

The chapter presents them as examples of combining candlesticks, volatility, technical analysis, and options.