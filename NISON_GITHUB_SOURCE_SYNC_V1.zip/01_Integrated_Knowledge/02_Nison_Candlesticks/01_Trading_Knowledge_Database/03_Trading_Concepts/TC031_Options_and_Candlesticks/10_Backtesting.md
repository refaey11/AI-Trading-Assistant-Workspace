# Chapter 18 — Backtesting

## Purpose

Backtesting can be used to review historical examples of the relationship between:

- Candlestick Patterns
- Underlying Price
- Historical Volatility
- Implied Volatility
- Options

The purpose is to examine how the concepts presented in Chapter 18 appeared in historical market examples.

---

## 1. Historical Market Review

For each historical example, record:

- Market
- Date
- Timeframe
- Underlying Price
- Candlestick Pattern
- Market Direction
- Historical Volatility
- Implied Volatility
- Option Type
- Exercise / Strike Price
- Time to Expiration

Only record information that is available.

---

## 2. Candlestick Signal

Record:

- Pattern name
- Location of the pattern
- Price movement before the pattern
- Price movement after the pattern

Examples discussed in Chapter 18 include:

- Doji
- Three Black Crows
- Harami Cross
- Hammer
- Tweezer Bottom
- Shooting Star
- Bullish Piercing Line
- Bearish Engulfing Pattern

---

## 3. Volatility Review

Record whether the example involves:

### Historical Volatility

Actual historical price fluctuations.

### Implied Volatility

Market expectations concerning future price volatility as reflected in option prices.

Record whether volatility:

- Increased
- Decreased
- Remained relatively high
- Remained relatively low

---

## 4. Option Review

When option information is available, record:

- Call or Put
- Exercise / Strike Price
- Time to Expiration
- Underlying Instrument
- Market Direction
- Volatility

Do not create missing values.

---

## 5. Historical Examples

### Silver

Review the sequence involving:

- Doji
- Three Black Crows
- Selloff
- Expansion of historical volatility
- Harami Cross
- Change from a steep decline to a lateral market
- Volatility contraction

### Sugar

Review the sequence involving:

- Sharp rally
- Increase in implied volatility
- Quiet trading range
- Declining volatility
- Hammer
- Tweezer Bottom
- Subsequent price and volatility behavior

### Cocoa

Review the sequence involving:

- Elliott Wave analysis
- Fibonacci target
- Shooting Star
- Bullish Piercing Line
- Bearish Engulfing Pattern
- $1,400 put example
- Subsequent market behavior

---

## 6. Evaluation

Compare the historical candlestick signal with:

**Candlestick + Underlying Market + Volatility + Option Structure**

Record what happened after the signal.

Do not assume that a historical example guarantees the same outcome in future markets.

---

## 7. Backtesting Limitations

Chapter 18 provides historical examples but does not provide a complete statistical backtesting methodology.

Therefore, this file should not assign:

- Win rate
- Profit factor
- Expected return
- Probability of success
- Maximum drawdown

unless these values are calculated separately from historical data.

---

## Source Rule

Backtesting should remain limited to concepts and historical examples supported by Chapter 18.

Do not treat the historical examples as guaranteed trading rules.