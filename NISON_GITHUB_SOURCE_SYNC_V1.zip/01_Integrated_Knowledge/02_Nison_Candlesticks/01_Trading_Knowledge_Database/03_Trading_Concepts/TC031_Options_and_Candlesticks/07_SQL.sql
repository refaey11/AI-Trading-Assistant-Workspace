-- Chapter 18 — Options and Candlesticks
-- Source: Steve Nison
-- Japanese Candlestick Charting Techniques

CREATE TABLE IF NOT EXISTS options_candlestick_concepts (
    id INTEGER PRIMARY KEY,
    chapter INTEGER NOT NULL,
    concept_name VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    source VARCHAR(200) NOT NULL
);

INSERT INTO options_candlestick_concepts
(id, chapter, concept_name, description, source)
VALUES

(1, 18, 'Limiting Risk',
 'Buying options can limit the risk to the premium paid.',
 'Japanese Candlestick Charting Techniques — Chapter 18'),

(2, 18, 'Sideways Markets',
 'Options can provide opportunities in sideways-moving markets.',
 'Japanese Candlestick Charting Techniques — Chapter 18'),

(3, 18, 'Strategic Flexibility',
 'Options provide flexibility in constructing strategies according to market expectations.',
 'Japanese Candlestick Charting Techniques — Chapter 18'),

(4, 18, 'Leverage',
 'Options can provide leverage relative to the capital committed.',
 'Japanese Candlestick Charting Techniques — Chapter 18'),

(5, 18, 'Exercise Price',
 'Exercise price is one of the five factors affecting the theoretical value of an option.',
 'Japanese Candlestick Charting Techniques — Chapter 18'),

(6, 18, 'Time to Expiration',
 'Time to expiration is one of the five factors affecting the theoretical value of an option.',
 'Japanese Candlestick Charting Techniques — Chapter 18'),

(7, 18, 'Underlying Instrument Price',
 'The price of the underlying instrument is one of the five factors affecting the theoretical value of an option.',
 'Japanese Candlestick Charting Techniques — Chapter 18'),

(8, 18, 'Volatility',
 'Volatility is one of the five factors affecting the theoretical value of an option.',
 'Japanese Candlestick Charting Techniques — Chapter 18'),

(9, 18, 'Short-Term Interest Rate',
 'Short-term interest rate is one of the five factors affecting the theoretical value of an option.',
 'Japanese Candlestick Charting Techniques — Chapter 18'),

(10, 18, 'Historical Volatility',
 'Historical volatility is based on actual historical price changes.',
 'Japanese Candlestick Charting Techniques — Chapter 18'),

(11, 18, 'Implied Volatility',
 'Implied volatility represents market expectations concerning future price volatility and is derived from option prices.',
 'Japanese Candlestick Charting Techniques — Chapter 18'),

(12, 18, 'Candlestick Signals',
 'Candlestick patterns can provide information about possible changes in market direction and assist with option timing.',
 'Japanese Candlestick Charting Techniques — Chapter 18');


CREATE TABLE IF NOT EXISTS chapter18_candlestick_examples (
    id INTEGER PRIMARY KEY,
    market VARCHAR(100) NOT NULL,
    pattern VARCHAR(100) NOT NULL,
    context TEXT NOT NULL,
    source VARCHAR(200) NOT NULL
);

INSERT INTO chapter18_candlestick_examples
(id, market, pattern, context, source)
VALUES

(1, 'Silver — September 1990', 'Doji',
 'Appeared after a long white real body before the subsequent selloff.',
 'Japanese Candlestick Charting Techniques — Chapter 18'),

(2, 'Silver — September 1990', 'Three Black Crows',
 'Appeared during the top-reversal sequence before the selloff.',
 'Japanese Candlestick Charting Techniques — Chapter 18'),

(3, 'Silver — September 1990', 'Harami Cross',
 'Appeared near the end of the selloff as the price trend changed from lower to lateral.',
 'Japanese Candlestick Charting Techniques — Chapter 18'),

(4, 'Sugar — July 1990', 'Hammer',
 'Appeared on February 26 after the market had moved within a relatively quiet range.',
 'Japanese Candlestick Charting Techniques — Chapter 18'),

(5, 'Sugar — July 1990', 'Tweezer Bottom',
 'The Hammer and the later low formed a Tweezer Bottom.',
 'Japanese Candlestick Charting Techniques — Chapter 18'),

(6, 'Cocoa — September 1990', 'Shooting Star',
 'Appeared at the top of Wave 3.',
 'Japanese Candlestick Charting Techniques — Chapter 18'),

(7, 'Cocoa — September 1990', 'Bullish Piercing Line',
 'Appeared at the bottom of Wave 4.',
 'Japanese Candlestick Charting Techniques — Chapter 18'),

(8, 'Cocoa — September 1990', 'Bearish Engulfing Pattern',
 'Appeared near the high around the Elliott Wave and Fibonacci target.',
 'Japanese Candlestick Charting Techniques — Chapter 18');