# Chapter 18 — Confidence Model

## Purpose

This model organizes the evidence discussed in Chapter 18 when combining candlestick analysis, volatility, the underlying market, and options.

It does not assign a numerical probability or guaranteed success rate.

---

## Evidence Categories

### 1. Candlestick Evidence

Identify the candlestick pattern and its location.

Relevant examples discussed in the chapter include:

- Doji
- Three Black Crows
- Harami Cross
- Hammer
- Tweezer Bottom
- Shooting Star
- Bullish Piercing Line
- Bearish Engulfing Pattern

---

### 2. Market Context

Consider:

- Direction of the underlying market
- Strength of the preceding trend
- Price movement before the candlestick signal
- Whether the market changes from trending to lateral conditions

---

### 3. Volatility Evidence

Identify whether the analysis concerns:

- Historical Volatility
- Implied Volatility

Observe whether volatility is:

- Expanding
- Contracting
- Relatively high
- Relatively low

Only record these conditions when supported by the available market data.

---

### 4. Option Evidence

When an option position is being considered, identify:

- Call or Put
- Exercise / Strike Price
- Time to Expiration
- Underlying Instrument
- Volatility

---

## Evidence Combination

The strongest analysis in the chapter comes from considering multiple pieces of information together.

Examples include:

### Silver

Candlestick reversal signals were considered together with changes in historical volatility.

### Sugar

Bottom-reversal candlestick signals were considered together with relatively low implied volatility and subsequent volatility behavior.

### Cocoa

Candlestick signals were considered together with:

- Elliott Wave analysis
- Fibonacci analysis
- The underlying market
- An option position

---

## Confidence Classification

### Strong Evidence

Use this classification only when several relevant factors support the same interpretation.

Examples:

- Candlestick reversal signal
- Important market context
- Supporting volatility behavior
- Relevant option characteristics

---

### Moderate Evidence

Use this classification when some supporting evidence is available but important information is missing.

---

### Weak Evidence

Use this classification when the interpretation depends mainly on a single signal or when important information is unavailable.

---

## No Numerical Probability

Chapter 18 does not provide a numerical probability model for candlestick and options setups.

Therefore, this database should not assign:

- Probability of success
- Win rate
- Expected return
- Statistical confidence percentage

unless these values are calculated separately from an independent dataset.

---

## Core Principle

Confidence should increase when multiple independent pieces of evidence support the same market interpretation.

A single candlestick pattern should not be treated as a guaranteed prediction.

---

## Source Limitation

This confidence model is an organizational framework for the evidence presented in Chapter 18.

The book does not provide the numerical confidence classifications used above as a formal statistical system.