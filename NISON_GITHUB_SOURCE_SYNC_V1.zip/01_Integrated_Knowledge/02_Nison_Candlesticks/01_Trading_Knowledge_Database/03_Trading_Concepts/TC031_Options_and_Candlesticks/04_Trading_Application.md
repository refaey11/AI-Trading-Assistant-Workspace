# Chapter 18 — Trading Application

## 1. Using Candlesticks to Analyze Volatility

When a strong trending market has pushed volatility to unusually high levels, the appearance of a candlestick reversal indicator may provide an opportunity to:

- Sell volatility
- Offset a long volatility trade

The chapter explains that candlestick formations suggesting a possible truce between bulls and bears can be especially useful.

Examples include:

- Harami
- Counterattack Lines
- Other reversal patterns discussed in Chapter 6

---

## 2. Reversal Signals and Volatility

A candlestick reversal signal may indicate that the prior price trend could change.

If the market changes from a strong trend into a lateral trading range, volatility may decline, assuming other volatility factors remain unchanged.

Therefore, a reversal candlestick can be used as part of an analysis of a possible short-term volatility change.

---

## 3. Candlesticks and Historic Volatility

The chapter states that, based on the author's experience and other considerations, candlestick signals appear to work better with historic volatility than with implied volatility.

However, candlesticks can sometimes assist in forecasting short-term movements in implied volatility.

---

## 4. Silver Example

In the Silver example:

- A Doji appeared after a long white real body.
- Three Black Crows followed.
- The market then sold off.
- Historic volatility expanded during the selloff.
- A Harami Cross appeared near the end of the selloff.
- The price trend then changed from lower to lateral.
- Volatility contracted as the market became lateral.

The Harami Cross could therefore be viewed as a signal that the prior steep trend might be ending and that volatility could decline.

---

## 5. Sugar Example

In the Sugar example:

- The market experienced a sharp rally.
- Implied volatility increased during the rally.
- The market later moved within a relatively quiet range.
- Volatility contracted.
- A Hammer appeared on February 26.
- The Hammer's lower shadow broke below a previous support area.
- The new low did not hold.
- A later white candlestick helped maintain the lows.
- The Hammer and the later low formed a Tweezer Bottom.

The combination of these bottom-reversal signals indicated that a strong base had potentially developed.

Because volatility was relatively low while the reversal signals appeared, a strong price rally could be accompanied by expanding volatility.

---

## 6. Bottom and Top Picking

The chapter discusses using options and candlesticks for the risky practice of attempting to pick market tops and bottoms.

The chapter acknowledges that this is a risky proposition.

The limited-risk feature of options can make it possible to take a position that would be considered too risky with an outright futures position.

---

## 7. Cocoa Example

The Cocoa example combines:

- Elliott Wave analysis
- Fibonacci analysis
- Candlestick analysis
- Options

The market was in a major bull market.

A Shooting Star appeared at the top of Wave 3.

A Bullish Piercing Line appeared at the bottom of Wave 4.

A Fibonacci relationship produced a Wave 5 target near $1,520.

When Cocoa later reached a high near $1,541, a Bearish Engulfing Pattern appeared.

The combination of the Elliott Wave target and the Bearish Engulfing Pattern provided evidence of a possible top.

The example used a $1,400 put option.

The major trend was still upward, so the author stated that he would have preferred liquidating long positions if he had been long.

The limited-risk feature of the option allowed the trade to be considered despite the risk of attempting to pick a top.

---

## 8. Important Risk Consideration

The chapter emphasizes that candlesticks can help identify possible changes in price direction and volatility, but volatility changes associated with candlestick signals are most likely to be shorter-term.

An increase in volatility after a candlestick signal does not necessarily mean that volatility will remain high until the option expires.

---

## Core Application

The chapter's application can be summarized as:

Candlestick Reversal Signal
+
Volatility Analysis
+
Market Context
+
Option Structure

The combination can help evaluate possible option trades involving volatility, market direction, and risk.