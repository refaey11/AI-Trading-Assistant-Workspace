# Chapter 18 — Checklist

## Options Basics

- [ ] Identify the underlying instrument.
- [ ] Identify the exercise / strike price.
- [ ] Identify the time to expiration.
- [ ] Identify the price of the underlying instrument.
- [ ] Identify the relevant volatility.
- [ ] Identify the short-term interest rate when available.

## Volatility

- [ ] Determine whether the analysis concerns historical volatility.
- [ ] Determine whether the analysis concerns implied volatility.
- [ ] Observe whether volatility is increasing or decreasing.
- [ ] Consider volatility together with the underlying market.

## Candlestick Analysis

- [ ] Identify the candlestick pattern.
- [ ] Identify where the pattern appeared.
- [ ] Examine the preceding price movement.
- [ ] Determine whether the pattern indicates a possible reversal.
- [ ] Consider the pattern together with volatility.

## Candlestick Patterns Discussed in Chapter 18

- [ ] Doji
- [ ] Three Black Crows
- [ ] Harami Cross
- [ ] Hammer
- [ ] Tweezer Bottom
- [ ] Shooting Star
- [ ] Bullish Piercing Line
- [ ] Bearish Engulfing Pattern

## Options and Candlesticks

- [ ] Connect the candlestick signal with the underlying market.
- [ ] Consider the relationship between the candlestick and volatility.
- [ ] Consider whether the signal may assist with option timing.
- [ ] Identify the relevant option type when available.
- [ ] Identify the strike / exercise price when available.
- [ ] Consider the time to expiration.

## Risk

- [ ] Identify the risk associated with the option position.
- [ ] Remember that buying options can limit risk to the premium paid.
- [ ] Do not treat an option position as risk-free.
- [ ] Do not treat a candlestick signal as a guaranteed prediction.

## Final Review

- [ ] Underlying market identified.
- [ ] Candlestick signal identified.
- [ ] Volatility identified.
- [ ] Option characteristics identified.
- [ ] Market context considered.
- [ ] Risk considered.
- [ ] Missing information clearly identified.