# Core Rules

## 1. Main Factors Affecting Option Value

The theoretical value of an option depends mainly on five factors:

1. **Exercise Price (Strike Price)**
2. **Time to Expiration**
3. **Price of the Underlying Instrument**
4. **Volatility**
5. **Short-term Interest Rate**

These factors must be considered when evaluating the price of an option.

---

## 2. Volatility Is Important

Volatility has an important effect on option prices.

An increase in volatility can have a significant effect on the value of options. Therefore, volatility should always be considered when evaluating an options position.

The chapter distinguishes between:

- **Historical Volatility**
- **Implied Volatility**

Historical volatility is based on actual historical price changes.

Implied volatility represents the market's expectations about future volatility and is derived from option prices.

---

## 3. Historical Candlestick Patterns

Historical candlestick patterns can provide information about possible future price behavior.

When a reversal candlestick pattern appears after a significant price movement, it may provide an indication that the previous trend could change.

However, a candlestick pattern should be considered in the context of the overall market movement and price structure.

---

## 4. Candlesticks and Options

Candlestick patterns can be combined with options to help identify potential trading opportunities.

A reversal pattern may provide a timing signal for:

- Buying options
- Selling options
- Closing an existing position

The chapter specifically discusses using candlestick reversal patterns together with options.

---

## 5. Important Price Levels

Candlestick reversal patterns become more useful when they appear at important price levels.

The chapter gives examples where patterns such as:

- **Shooting Star**
- **Harami**
- **Piercing Pattern**
- **Bearish Engulfing Pattern**
- **Black Crows**
- **Hammer**
- **Tweezers Bottom**

appear during important market movements.

These patterns are used as signals to evaluate possible changes in market direction.

---

## 6. Do Not Use Candlesticks Alone

Candlestick patterns should not be treated as an isolated trading system.

They can be used together with other information, including:

- Price movement
- Market trend
- Historical volatility
- Implied volatility
- Option characteristics

The purpose is to improve the timing and structure of an options trade.

---

## 7. Option Strategy Must Match the Market Expectation

Options provide flexibility because different strategies can be used depending on the trader's expectations.

The trader should consider:

- Expected market direction
- Expected volatility
- Time remaining until expiration
- Strike price
- Risk involved

The chapter illustrates how options can be used to manage risk and structure trades around expected market movements.

---

## 8. Key Principle

**Candlestick analysis can help identify potential changes in market direction, while options provide different ways to structure the trade according to the expected movement and volatility.**