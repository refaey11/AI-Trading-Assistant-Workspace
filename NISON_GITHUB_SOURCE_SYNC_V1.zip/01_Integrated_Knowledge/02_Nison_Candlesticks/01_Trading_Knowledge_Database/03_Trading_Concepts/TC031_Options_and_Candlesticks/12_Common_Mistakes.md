# Chapter 18 — Common Mistakes

## 1. Treating a Candlestick Signal as a Guarantee

A candlestick pattern should not be treated as a guaranteed prediction of future price movement.

The chapter uses candlestick patterns as signals that can provide information about possible changes in market direction.

---

## 2. Ignoring Volatility

Volatility is one of the five factors affecting the theoretical value of an option.

Ignoring volatility can therefore lead to an incomplete evaluation of an option position.

---

## 3. Confusing Historical and Implied Volatility

Historical volatility and implied volatility are different concepts.

### Historical Volatility

Based on actual historical price changes.

### Implied Volatility

Represents the market's expectations concerning future volatility and is derived from option prices.

They should not be treated as the same measure.

---

## 4. Ignoring the Underlying Market

Options are connected to the underlying instrument.

Candlestick analysis should therefore be considered in relation to the price behavior of the underlying market.

---

## 5. Ignoring Time to Expiration

Time to expiration is one of the five factors affecting the theoretical value of an option.

It should therefore be considered when evaluating an option.

---

## 6. Ignoring the Exercise Price

Exercise price is one of the five factors affecting the theoretical value of an option.

The exercise or strike price should therefore be considered when analyzing an option position.

---

## 7. Assuming Volatility Will Remain Unchanged

The examples in the chapter demonstrate that volatility can expand or contract as market conditions change.

A change from a strong trend to a lateral market can be accompanied by a decline in volatility.

Therefore, the current volatility environment should not automatically be assumed to continue unchanged.

---

## 8. Ignoring Market Context

A candlestick pattern should be considered in the context of the preceding market movement.

The chapter's examples show candlestick signals occurring after strong advances, selloffs, or during changes in market conditions.

---

## 9. Treating Historical Examples as Guaranteed Results

The Silver, Sugar, and Cocoa examples are historical examples.

They demonstrate how candlesticks, volatility, and options can be combined.

They should not be treated as guarantees of future trading results.

---

## 10. Ignoring Risk

The chapter discusses the limited-risk characteristic of buying options.

However, limited risk does not mean that the trade is risk-free.

The amount paid for the option represents the risk when buying the option.

---

## 11. Using an Option Without Understanding Its Characteristics

Before evaluating an option position, consider the factors discussed in the chapter:

- Exercise Price
- Time to Expiration
- Underlying Instrument Price
- Volatility
- Short-Term Interest Rate

---

## 12. Relying on a Single Piece of Evidence

The examples in Chapter 18 combine several forms of analysis.

These can include:

- Candlestick patterns
- Underlying market behavior
- Historical volatility
- Implied volatility
- Elliott Wave analysis
- Fibonacci analysis
- Option structure

A combined analysis provides more context than considering a single signal independently.

---

## Source Limitation

This file organizes potential mistakes that can be identified from the concepts and examples presented in Chapter 18.

It does not claim that every item above is presented by the author as a separately named "common mistake."