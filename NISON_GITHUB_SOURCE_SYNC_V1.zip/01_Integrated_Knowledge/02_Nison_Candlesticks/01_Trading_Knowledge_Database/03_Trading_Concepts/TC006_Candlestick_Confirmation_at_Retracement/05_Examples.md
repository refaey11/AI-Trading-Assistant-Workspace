# TC006 - Examples

---

## Example 1

### Situation

Strong Uptrend

↓

Price retraces to 38.2%

↓

Hammer appears

↓

Trend resumes.

Lesson

Strong trends often require only shallow corrections.

---

## Example 2

### Situation

Price retraces to 50%

↓

Morning Star appears

↓

Bullish continuation.

Lesson

50% becomes much stronger when confirmed by a bullish reversal.

---

## Example 3

### Situation

Price retraces to 61.8%

↓

Bullish Engulfing

↓

New impulse begins.

Lesson

Deep corrections often provide excellent trend continuation entries.

---

## Example 4

### Situation

Bearish Trend

↓

Price retraces upward

↓

Shooting Star forms

↓

Downtrend resumes.

Lesson

Retracement resistance combined with bearish confirmation creates high-probability shorts.

---

## Example 5

### Situation

Retracement

+

Trendline

+

Hammer

↓

Strong Buy Setup.

---

## Example 6

### Situation

Retracement

+

Horizontal Resistance

+

Evening Star

↓

Strong Sell Setup.