# TC006 - Common Mistakes

## Mistake 1

Buying simply because price reached 50%.

Wait for confirmation.

---

## Mistake 2

Selling immediately at 61.8%.

Confirmation is required.

---

## Mistake 3

Ignoring the primary trend.

---

## Mistake 4

Drawing Fibonacci on an unfinished swing.

---

## Mistake 5

Ignoring candle close.

Many false signals disappear before the candle closes.

---

## Mistake 6

Ignoring confluence.

One signal is rarely enough.

---

## Mistake 7

Placing Stop Loss exactly on the retracement level.

Stops belong beyond the confirmation candle.

---

## Mistake 8

Treating retracement levels as exact prices instead of reaction zones.

---

## Mistake 9

Ignoring higher timeframe structure.

---

## Mistake 10

Trading every retracement.

Only trade retracements confirmed by price action.