# TC006 - Market Psychology

Retracement levels attract attention.

But they do not tell us who is winning.

Candlestick patterns reveal the winner.

Example:

Price reaches 50%.

Hammer appears.

This means:

Sellers pushed lower.

Buyers completely rejected those prices.

Demand absorbed supply.

Control shifts back to buyers.

The same logic applies to bearish reversals near resistance.

Candlesticks transform retracement levels from passive price zones into active decision zones.