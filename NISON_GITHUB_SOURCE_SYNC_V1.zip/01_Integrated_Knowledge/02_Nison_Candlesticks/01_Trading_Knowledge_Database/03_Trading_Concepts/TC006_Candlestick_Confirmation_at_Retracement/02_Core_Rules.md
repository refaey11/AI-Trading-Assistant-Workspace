# TC006 - Core Rules

## Rule 1

Retracement identifies the location.

Candlesticks identify the decision.

---

## Rule 2

Wait until the confirmation candle closes.

---

## Rule 3

Bullish confirmation is valid only near support.

---

## Rule 4

Bearish confirmation is valid only near resistance.

---

## Rule 5

Multiple bullish candles increase buying probability.

---

## Rule 6

Multiple bearish candles increase selling probability.

---

## Rule 7

Ignore weak candlestick patterns in the middle of nowhere.

Location is critical.

---

## Rule 8

Retracement plus candlestick confirmation is stronger than either tool alone.

---

## Rule 9

Trend must agree with the intended trade.

---

## Rule 10

The stronger the candlestick reversal, the stronger the confirmation.