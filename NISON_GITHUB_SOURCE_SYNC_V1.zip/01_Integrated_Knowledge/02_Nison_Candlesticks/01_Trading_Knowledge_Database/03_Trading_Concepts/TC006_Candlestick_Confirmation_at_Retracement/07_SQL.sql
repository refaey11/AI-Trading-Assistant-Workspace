CREATE TABLE retracement_confirmations (

id INTEGER PRIMARY KEY,

concept_id TEXT,

trend TEXT,

retracement_level REAL,

candlestick TEXT,

signal TEXT,

notes TEXT

);

INSERT INTO retracement_confirmations VALUES
(1,'TC006','Bullish',38.2,'Hammer','BUY','Strong Trend');

INSERT INTO retracement_confirmations VALUES
(2,'TC006','Bullish',50,'Morning Star','BUY','Dow Theory Level');

INSERT INTO retracement_confirmations VALUES
(3,'TC006','Bullish',61.8,'Bullish Engulfing','BUY','Golden Ratio');

INSERT INTO retracement_confirmations VALUES
(4,'TC006','Bearish',38.2,'Shooting Star','SELL','Trend Continuation');

INSERT INTO retracement_confirmations VALUES
(5,'TC006','Bearish',50,'Evening Star','SELL','Retracement Resistance');

INSERT INTO retracement_confirmations VALUES
(6,'TC006','Bearish',61.8,'Bearish Engulfing','SELL','Golden Ratio');