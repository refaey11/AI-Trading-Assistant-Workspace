# TC006 - Trading Checklist

Before entering a trade:

☐ Primary trend identified.

☐ Impulse wave completed.

☐ Retracement level identified.

☐ Candlestick confirmation exists.

☐ Candle has CLOSED.

☐ Support or Resistance agrees.

☐ Trendline agrees.

☐ Volume supports the move.

☐ Stop Loss defined.

☐ Risk / Reward ≥ 1:2.

☐ Higher timeframe agrees.

☐ Trade follows the dominant trend.