# TC006 - Candlestick Confirmation at Retracement Levels

## Name

Candlestick Confirmation at Retracement Levels

---

## Category

Technical Analysis

Candlestick Analysis

Retracement Analysis

Trend Continuation

---

## Source

Steve Nison

Chapter 12

Candlesticks & Retracement Levels

---

## Definition

Retracement levels identify potential reversal zones.

Japanese candlestick patterns determine whether the market actually reverses from those zones.

A retracement level without candlestick confirmation is only a potential support or resistance area.

A retracement level confirmed by a strong candlestick pattern becomes a high-probability trading opportunity.

---

## Objective

Use candlestick patterns to confirm whether buyers or sellers have regained control after a retracement.

---

## Core Idea

Trend

↓

Retracement

↓

Candlestick Confirmation

↓

Trade Decision

---

## Bullish Confirmation

• Hammer

• Bullish Engulfing

• Morning Star

• Piercing Pattern

---

## Bearish Confirmation

• Shooting Star

• Bearish Engulfing

• Evening Star

• Dark Cloud Cover

---

## Professional Principle

Never buy because price reached 50%.

Buy because buyers proved they regained control.

Never sell because price reached 61.8%.

Sell because sellers proved they regained control.