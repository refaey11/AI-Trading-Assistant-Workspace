# TC006 - Trading Application

## Step 1

Identify the primary trend.

Never trade against the dominant trend unless the entire market structure changes.

---

## Step 2

Identify the completed impulse move.

Draw the retracement.

Focus on:

• 38.2%

• 50%

• 61.8%

---

## Step 3

Wait for price to reach one of these retracement zones.

Do nothing before price reaches the area.

---

## Step 4

Wait for candlestick confirmation.

Bullish Examples

• Hammer

• Morning Star

• Bullish Engulfing

• Piercing Pattern

Bearish Examples

• Shooting Star

• Evening Star

• Bearish Engulfing

• Dark Cloud Cover

---

## Step 5

Enter only after the confirmation candle closes.

Never anticipate confirmation.

---

## Step 6

Place Stop Loss

Bullish Trade

↓

Below confirmation candle.

Bearish Trade

↓

Above confirmation candle.

---

## Step 7

Targets

Previous Swing High

Trend Continuation

Next Resistance

or

Measured Move

---

## Professional Workflow

Trend

↓

Impulse

↓

Retracement

↓

Candlestick Confirmation

↓

Entry

↓

Risk Management

↓

Exit