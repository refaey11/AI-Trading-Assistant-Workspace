# TC006 - Confluence Model

## Level 1 ★☆☆☆☆

Retracement only.

Low probability.

---

## Level 2 ★★☆☆☆

Retracement

+

Trend

---

## Level 3 ★★★☆☆

Retracement

+

Candlestick Confirmation

---

## Level 4 ★★★★☆

Retracement

+

Candlestick

+

Trendline

OR

Horizontal Support / Resistance

---

## Level 5 ★★★★★

Professional Setup

Retracement

+

Candlestick

+

Trendline

+

Support / Resistance

+

Volume

+

Higher Timeframe Agreement

Highest probability.

---

## Professional Rule

The retracement identifies the location.

The candlestick confirms the decision.

Confluence determines the probability.