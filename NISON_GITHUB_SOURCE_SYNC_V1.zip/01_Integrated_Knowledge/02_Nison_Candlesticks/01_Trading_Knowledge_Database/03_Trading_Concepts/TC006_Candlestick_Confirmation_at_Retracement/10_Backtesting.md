# TC006 - Backtesting

Record

Market

Date

Timeframe

Trend

Impulse Size

Retracement Level

Candlestick Pattern

Confluence

Entry

Stop Loss

Target

Exit

Result

Maximum Favorable Excursion (MFE)

Maximum Adverse Excursion (MAE)

Notes

Questions

1. Was the retracement respected?

2. Did the candlestick improve accuracy?

3. Which retracement level worked best?

4. Was confluence sufficient?

5. Was entry late or early?

6. Was risk management respected?