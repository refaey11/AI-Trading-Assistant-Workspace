# Chapter 17 — Concepts

## Core Concepts

### Market Profile
A framework for organizing and analyzing market activity.

### TPO
Time-Price Opportunity representing a price opportunity during a specific time period.

### Initial Balance
The initial trading range established during the first hour.

### Range Extension
An extension of the Initial Balance.

### Value Area
An area representing accepted market value.

### Buying Extreme
The upper extreme of the Market Profile.

### Selling Extreme
The lower extreme of the Market Profile.

### Acceptance
Market behavior in which a price area receives sufficient time and trading activity.

### Rejection
Market behavior in which price moves away from an area without establishing sustained activity there.

### Candlestick Integration
The use of Japanese candlestick formations together with Market Profile information.

## Candlestick Examples

- Doji
- Hanging Man
- Shooting Star

## Main Relationship

**Market Profile → Market Structure**

**Candlesticks → Price Behavior**

**Combined → Additional Market Context**

## Source

Steve Nison — Japanese Candlestick Charting Techniques, Chapter 17.