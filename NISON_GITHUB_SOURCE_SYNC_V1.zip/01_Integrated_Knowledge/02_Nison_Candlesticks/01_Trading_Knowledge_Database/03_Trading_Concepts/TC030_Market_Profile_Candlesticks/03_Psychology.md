# Chapter 17 — Psychology

## Source
Japanese Candlestick Charting Techniques — Steve Nison

## Chapter
Chapter 17 — Market Profile and Candlesticks

---

## Market Behavior

Market Profile provides a way to observe how buyers and sellers behave at different price levels.

The interaction between buyers and sellers helps create the structure of the Market Profile.

---

## Price Acceptance

When the market spends time trading around a price and there is sufficient trading activity, this provides evidence that the market is accepting that price.

Acceptance therefore involves:

- Time
- Trading activity
- Price

---

## Price Rejection

When the market moves to a price level but does not spend much time trading there, the price may be considered rejected.

A rapid movement away from a price area can provide evidence of rejection.

---

## Buyers and Sellers

The chapter explains Market Profile behavior through the interaction between buyers and sellers.

At higher prices, sellers may become more willing to sell while the number of buyers decreases.

At lower prices, lower prices can attract buyers.

The resulting interaction contributes to the development of the Market Profile.

---

## Value Discovery

The market continuously searches for prices where buyers and sellers are willing to trade.

As trading activity develops, the market establishes areas of accepted value.

The Value Area therefore provides information about where the market has found relative acceptance.

---

## Initiative and Responsive Activity

Market Profile can also help distinguish between different types of market activity.

### Initiative Activity

Activity that moves the market away from an established area of value.

### Responsive Activity

Activity that occurs as traders respond to prices outside or around an established value area.

---

## Candlestick Psychology

Japanese candlesticks can provide additional information about the behavior of buyers and sellers.

A candlestick formation occurring at an important Market Profile area can therefore be considered together with the Market Profile structure.

For example, a reversal-type candlestick near an important price extreme can provide additional information about the market's reaction to that price.

---

## Important Principle

The psychological interpretation in this chapter comes primarily from observing:

**Price + Time + Trading Activity + Buyer/Seller Interaction**

Market Profile provides the market-structure context, while Japanese candlesticks provide additional information about price behavior.

---

## Source Limitation

Chapter 17 does not present a separate psychological trading system.

The psychology described here is derived from the chapter's discussion of market behavior, acceptance, rejection, buyers, sellers, and Market Profile structure.