# Chapter 17 — Backtesting

## Purpose

This file provides a structure for reviewing historical examples using the concepts presented in Chapter 17.

The chapter itself provides practical Market Profile and candlestick examples, but it does not establish a complete statistical backtesting system.

## Historical Review

For each historical example, record:

### Market Profile

- Market
- Date
- Timeframe
- TPO structure
- Initial Balance
- Range Extension
- Value Area
- Buying Extreme
- Selling Extreme

### Market Activity

- Trading volume
- Time spent at price levels
- Price acceptance
- Price rejection
- Buyer activity
- Seller activity

### Candlestick

- Candlestick pattern
- Location
- Relationship with the Market Profile

### Outcome

Record what happened after the identified Market Profile and candlestick conditions.

## Evaluation

Compare:

Market Profile Structure
+
Market Activity
+
Candlestick Behavior

with the subsequent price movement.

## Source Limitation

Chapter 17 does not provide:

- A fixed entry rule
- A fixed stop-loss rule
- A fixed take-profit rule
- A fixed win rate
- A statistical probability model

Therefore, these values should not be attributed to the chapter.