# Chapter 17 — Trading Application

## Source

Japanese Candlestick Charting Techniques — Steve Nison

## Chapter

Chapter 17 — Market Profile and Candlesticks

---

## Combining Market Profile and Candlesticks

Chapter 17 demonstrates how Market Profile information can be combined with Japanese candlestick analysis.

The Market Profile provides information about the market's structure, while candlesticks provide information about price behavior.

---

## Step 1 — Examine the Market Profile

First identify the important parts of the Market Profile:

- Initial Balance
- Range Extension
- Value Area
- Buying Extreme
- Selling Extreme

---

## Step 2 — Observe the Value Area

Compare the current market activity with the established Value Area.

Observe whether the market is accepting prices within the area or rejecting prices around it.

---

## Step 3 — Observe Trading Activity

Examine the amount of time and trading activity around different price levels.

This helps determine whether the market is accepting or rejecting those prices.

---

## Step 4 — Examine Candlestick Signals

Look for relevant Japanese candlestick formations around important Market Profile areas.

The chapter provides examples involving candlestick formations such as:

- Doji
- Hanging Man
- Shooting Star

---

## Step 5 — Combine the Evidence

The candlestick should be interpreted together with the Market Profile.

Consider:

- Where the candlestick appeared
- The Market Profile structure
- The Value Area
- The market's trading activity
- The subsequent price behavior

---

## Example Application

The chapter presents examples in which a candlestick formation appears near an important Market Profile area.

A candlestick signal can provide additional information about the market's reaction to a price level.

The Market Profile provides the broader market context for the candlestick signal.

---

## Important Principle

A candlestick signal should not be considered independently from the surrounding market structure.

Market Profile and Japanese candlesticks can be combined to provide additional information about market behavior.

---

## Source Limitation

Chapter 17 provides examples and concepts for combining Market Profile with Japanese candlesticks.

It does not establish a complete mechanical trading system with fixed:

- Entry rules
- Stop-loss rules
- Take-profit rules
- Win-rate targets

These rules should therefore not be attributed to the chapter.