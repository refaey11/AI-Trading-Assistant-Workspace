# Chapter 17 — Market Profile and Candlesticks

## Source
Japanese Candlestick Charting Techniques — Steve Nison

## Chapter
Chapter 17 — Market Profile and Candlesticks

## Main Topic
Market Profile and its relationship with Japanese candlesticks.

## Description

Market Profile is presented as a tool that provides information about market structure, price, time, and trading volume.

The chapter explains that Market Profile can help traders understand the market's main structure and analyze price activity in a more organized way.

Market Profile organizes trading activity according to price and time. It can show where the market has spent the most time and where trading activity has extended beyond the normal range.

The chapter also discusses how candlestick patterns can be used together with Market Profile.

Candlestick signals may provide additional information about the market's condition when they appear around important Market Profile areas.

## Key Areas Covered

- Market Profile
- Time-Price Opportunity (TPO)
- Initial Balance
- Range Extension
- Value Area
- Buying Extreme
- Selling Extreme
- Market Profile with Candlesticks
- Candlestick signals around Market Profile areas
- Volume and trading activity
- Price acceptance and rejection
- Market Profile examples

## Important Concepts

### Market Profile
A method of organizing market activity according to price and time.

### Time-Price Opportunity (TPO)
A TPO represents the price range covered by the market during a specific half-hour period.

### Initial Balance
The range established during the first hour of trading.

The first hour is divided into two half-hour periods, with letters assigned to each period.

### Range Extension
A movement beyond the Initial Balance that extends the market's range.

### Value Area
The area in which a large portion of trading activity takes place.

### Buying Extreme
The upper extreme of the Market Profile.

### Selling Extreme
The lower extreme of the Market Profile.

## Chapter Objective

The chapter's objective is to show how Market Profile can provide a framework for understanding market structure and how candlestick signals can be used alongside this information.

The chapter emphasizes observing the interaction between price, time, volume, Market Profile structure, and candlestick signals.