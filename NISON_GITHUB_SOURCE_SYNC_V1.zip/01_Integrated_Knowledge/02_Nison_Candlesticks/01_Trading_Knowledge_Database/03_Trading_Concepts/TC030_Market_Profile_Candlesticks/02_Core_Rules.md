# Chapter 17 — Core Rules

## Source
Japanese Candlestick Charting Techniques — Steve Nison

## Chapter
Chapter 17 — Market Profile and Candlesticks

---

## 1. Market Profile Structure

Market Profile organizes market activity according to:

- Price
- Time
- Trading activity

Its purpose is to provide a framework for understanding the market's structure.

---

## 2. Time-Price Opportunity (TPO)

A Time-Price Opportunity (TPO) represents the price range covered by the market during a half-hour period.

Different letters are assigned to the different half-hour periods of the trading day.

The letters allow the trader to see how the market moved through different price levels over time.

---

## 3. Initial Balance

The Initial Balance is the range established during the first hour of trading.

The first hour is divided into two half-hour periods.

The Initial Balance provides the initial range from which later market activity can expand.

---

## 4. Range Extension

Range Extension occurs when the market moves beyond the Initial Balance.

A range extension can occur above or below the Initial Balance.

The Market Profile therefore allows the trader to observe whether the market is extending its range after the initial balance.

---

## 5. Value Area

The Value Area represents the area where a large portion of trading activity takes place.

The chapter describes the Value Area as an important part of the Market Profile because it helps identify where the market has accepted prices.

---

## 6. Buying Extreme

The Buying Extreme is located at the upper extreme of the Market Profile.

It represents the upper end of the profile.

---

## 7. Selling Extreme

The Selling Extreme is located at the lower extreme of the Market Profile.

It represents the lower end of the profile.

---

## 8. Price Acceptance and Rejection

The chapter discusses how the market can accept or reject prices.

When prices move toward a new price level, the amount of trading activity and the time spent at that level provide information about how the market is responding to the price.

---

## 9. Candlesticks + Market Profile

Market Profile can be used together with Japanese candlesticks.

Candlestick signals can provide additional information when they appear around important Market Profile areas.

The chapter gives examples where candlestick patterns appear together with Market Profile information.

---

## 10. Shooting Star Example

The chapter presents a Market Profile example in which a Shooting Star appears.

The Shooting Star is associated with the upper area of the market's movement.

The example shows how a candlestick signal can provide additional information when considered together with Market Profile.

---

## 11. Hanging Man Example

The chapter also presents an example involving a Hanging Man.

The Hanging Man appears in the candlestick chart together with Market Profile information.

The example demonstrates the use of candlestick signals alongside the Market Profile structure.

---

## 12. Volume and Market Activity

Trading volume is discussed as an important part of understanding market activity.

Changes in trading volume can provide information about the strength or weakness of activity at different price levels.

---

## 13. Important Principle

Market Profile should not be viewed only as a price chart.

It combines information about:

Price + Time + Trading Activity

Candlestick analysis can then be used alongside this information to provide additional market signals.

---

## 14. Chapter Rule

Use Market Profile to understand:

1. Where trading activity occurred.
2. How much time the market spent at different prices.
3. The Initial Balance.
4. Any Range Extension.
5. The Value Area.
6. The Buying Extreme.
7. The Selling Extreme.

Then examine candlestick signals in relation to these Market Profile areas.

---

## Source Limitation

The rules above are extracted and organized from the material shown in Chapter 17.

No additional Market Profile rules are added beyond what is supported by the provided chapter material.