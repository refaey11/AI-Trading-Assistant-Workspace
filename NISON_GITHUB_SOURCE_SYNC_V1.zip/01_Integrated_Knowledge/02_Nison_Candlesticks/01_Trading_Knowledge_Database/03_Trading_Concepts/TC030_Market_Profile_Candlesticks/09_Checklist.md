# Chapter 17 — Checklist

## Market Profile Structure

- [ ] Identify the Market Profile.
- [ ] Identify the TPO periods.
- [ ] Identify the Initial Balance.
- [ ] Identify any Range Extension.
- [ ] Identify the Value Area.
- [ ] Identify the Buying Extreme.
- [ ] Identify the Selling Extreme.

## Market Behavior

- [ ] Observe where price is trading.
- [ ] Observe the amount of time spent at price levels.
- [ ] Observe trading activity and volume.
- [ ] Determine whether prices are being accepted.
- [ ] Determine whether prices are being rejected.
- [ ] Observe buyer and seller activity.

## Candlestick Analysis

- [ ] Identify relevant Japanese candlestick formations.
- [ ] Check the location of the candlestick within the Market Profile.
- [ ] Check the relationship between the candlestick and the Value Area.
- [ ] Check subsequent price behavior.

## Combined Analysis

- [ ] Market Profile structure is identified.
- [ ] Important value areas are identified.
- [ ] Candlestick evidence is identified.
- [ ] Trading activity is considered.
- [ ] Market behavior is considered.
- [ ] The interpretation is based on the combined evidence.