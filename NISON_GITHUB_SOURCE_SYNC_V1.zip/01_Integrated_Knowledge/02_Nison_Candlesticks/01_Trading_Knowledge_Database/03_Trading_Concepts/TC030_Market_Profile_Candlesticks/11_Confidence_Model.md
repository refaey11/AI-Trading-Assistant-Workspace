# Chapter 17 — Condensed Model

## Market Profile

Market Profile organizes market activity according to:

**Price + Time + Trading Activity**

## TPO

**Time-Price Opportunity**

A TPO represents the price range traded during a specific half-hour period.

## Initial Balance

The initial trading range established during the first hour of trading.

## Range Extension

Movement beyond the Initial Balance.

## Value Area

The area where the market has established accepted value.

## Extremes

- Buying Extreme → upper extreme
- Selling Extreme → lower extreme

## Market Behavior

### Acceptance
The market spends time and trading activity around a price area.

### Rejection
The market does not spend significant time at a price area and moves away.

## Candlestick Integration

Market Profile can be combined with Japanese candlestick analysis.

The chapter provides examples involving:

- Doji
- Hanging Man
- Shooting Star

## Core Framework

**Market Profile + Price + Time + Trading Activity + Candlesticks**

The Market Profile provides market-structure information, while candlesticks provide additional information about price behavior.