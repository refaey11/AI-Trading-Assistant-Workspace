# Chapter 17 — Examples

## Source

Japanese Candlestick Charting Techniques — Steve Nison

## Chapter

Chapter 17 — Market Profile and Candlesticks

---

## Example 1 — Market Profile and Value

The chapter presents Market Profile examples showing how price, time, and trading activity can be organized to identify areas of value.

The examples demonstrate how the market develops a profile during the trading session.

---

## Example 2 — Initial Balance and Range Extension

The chapter illustrates the Initial Balance and shows how the market can extend beyond the initial range.

The extension can occur toward the upper or lower side of the Initial Balance.

---

## Example 3 — Doji and Market Profile

The chapter presents an example in which a Doji appears in conjunction with Market Profile information.

The Market Profile provides additional context for evaluating the Doji and the market's behavior around the relevant price area.

---

## Example 4 — Hanging Man and Market Profile

Another example includes a Hanging Man formation.

The candlestick is considered together with the Market Profile rather than independently.

---

## Example 5 — Shooting Star and Market Profile

The chapter also presents an example involving a Shooting Star.

The Shooting Star appears in the context of the market's previous price movement and Market Profile structure.

The example demonstrates how the candlestick can provide additional information about the market's behavior at higher price levels.

---

## Main Lesson

The examples demonstrate the relationship between:

- Market Profile
- Price
- Time
- Trading activity
- Value
- Japanese candlesticks

The Market Profile provides market-structure information, while the candlestick provides additional information about price behavior.