-- Chapter 17 — Market Profile and Candlesticks
-- Source: Steve Nison
-- Japanese Candlestick Charting Techniques

CREATE TABLE IF NOT EXISTS market_profile_concepts (
    id INTEGER PRIMARY KEY,
    concept_name VARCHAR(100) NOT NULL,
    description TEXT NOT NULL,
    source_chapter INTEGER NOT NULL
);

INSERT INTO market_profile_concepts
(id, concept_name, description, source_chapter)
VALUES
(1, 'Market Profile',
 'A framework for organizing market activity according to price, time, and trading activity.',
 17),

(2, 'TPO',
 'Time-Price Opportunity representing a price opportunity during a specific time period.',
 17),

(3, 'Initial Balance',
 'The initial trading range established during the early part of the session.',
 17),

(4, 'Range Extension',
 'Movement beyond the Initial Balance.',
 17),

(5, 'Value Area',
 'An area used to identify accepted market value.',
 17),

(6, 'Buying Extreme',
 'The upper extreme of the Market Profile.',
 17),

(7, 'Selling Extreme',
 'The lower extreme of the Market Profile.',
 17),

(8, 'Acceptance',
 'Market behavior indicating that a price area is being accepted.',
 17),

(9, 'Rejection',
 'Market behavior indicating that a price area is being rejected.',
 17);


CREATE TABLE IF NOT EXISTS market_profile_candlesticks (
    id INTEGER PRIMARY KEY,
    pattern_name VARCHAR(100) NOT NULL,
    context TEXT NOT NULL,
    source_chapter INTEGER NOT NULL
);

INSERT INTO market_profile_candlesticks
(id, pattern_name, context, source_chapter)
VALUES
(1, 'Doji',
 'Candlestick example considered together with Market Profile.',
 17),

(2, 'Hanging Man',
 'Candlestick example considered together with Market Profile.',
 17),

(3, 'Shooting Star',
 'Candlestick example considered together with Market Profile.',
 17);