# Case 02 — Figure 13.2

## Market Context

Potential Bearish Reversal

---

## Indicator

65-Day Simple Moving Average

---

## Setup

Price attempted to recover above the Moving Average.

A Dark Cloud Cover formed immediately after the failed breakout.

---

## Interpretation

The Moving Average became Dynamic Resistance.

The Dark Cloud Cover confirmed seller dominance.

---

## Trading Opportunity

Entry

After bearish confirmation.

Stop Loss

Above resistance.

Target

Continuation of the downtrend.

---

## Lesson

Failed Moving Average recoveries combined with bearish candlestick patterns provide strong continuation signals.