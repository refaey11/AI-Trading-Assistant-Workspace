# Case 01 — Figure 13.1

## Market Context

Bullish Trend

---

## Indicator

65-Day Simple Moving Average

---

## Setup

Price retraced toward the 65-Day Moving Average.

Several bullish candlestick patterns appeared directly at the Moving Average.

Patterns observed:

- Bullish Engulfing
- Hammer
- Bullish Harami
- Hammer-like Candle

---

## Interpretation

The Moving Average acted as Dynamic Support.

Each bullish candlestick confirmed that buyers continued defending the trend.

---

## Trading Opportunity

Entry

After confirmation candle closes.

Stop Loss

Below the confirmation candle.

Target

Trend continuation.

---

## Lesson

A Moving Average identifies the area.

Candlesticks confirm the timing.

The combination provides significantly higher probability than either tool alone.