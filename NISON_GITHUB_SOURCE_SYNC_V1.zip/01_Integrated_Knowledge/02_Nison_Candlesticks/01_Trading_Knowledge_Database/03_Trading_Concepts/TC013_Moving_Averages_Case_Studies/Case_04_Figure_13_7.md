# Case 04 — Figure 13.7

## Source

Steve Nison

Beyond Candlesticks

Chapter 13

Figure 13.7

---

## Market Context

Trend Transition

---

## Indicators

- MACD
- Signal Line
- Histogram
- Candlestick Patterns

---

## Setup

### Point A

- Inverted Hammer formed.
- A Golden Cross occurred shortly afterward.
- The Histogram crossed above zero.

This combination suggested that bullish momentum was increasing.

---

### Point B

- A Death Cross appeared.
- Momentum shifted to the downside.

---

### Point C

Price attempted to rally.

However:

- The short-term Moving Average failed to cross above the long-term Moving Average.
- Histogram remained below zero.
- Dark Cloud Cover formed.

---

## Interpretation

Although price rallied temporarily, momentum never confirmed the move.

The bearish candlestick pattern combined with the weak MACD structure confirmed that sellers remained in control.

---

## Trading Opportunity

### Entry

After the Dark Cloud Cover closed.

### Stop Loss

Above the Dark Cloud Cover.

### Target

Continuation of the bearish trend.

---

## Risk Management

The MACD prevented entering long positions during a weak rally.

Candlestick confirmation improved timing.

---

## Key Lessons

✔ MACD confirms momentum.

✔ Candlesticks confirm execution timing.

✔ Histogram remaining below zero warns that rallies may fail.

✔ Never trade against MACD momentum without strong evidence.