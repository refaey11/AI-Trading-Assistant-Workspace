# Case 05 — Figure 13.8

## Source

Steve Nison

Beyond Candlesticks

Chapter 13

Figure 13.8

---

## Market Context

Major Bottom Formation

---

## Indicators

- MACD
- Signal Line
- Histogram
- Morning Star
- Dark Cloud Cover
- Hanging Man

---

## Setup

The market initially formed a Morning Star.

However,

the rally failed because a Dark Cloud Cover appeared shortly afterward.

Price continued declining.

Later,

a second Morning Star formed.

This time,

MACD produced a bullish crossover.

The Histogram moved above zero.

Momentum now confirmed the reversal.

---

## Trend Development

The market began a sustainable uptrend.

Later,

a Hanging Man appeared,

causing only a temporary pullback before the uptrend resumed.

---

## Trading Opportunity

### Entry

After the second Morning Star and bullish MACD crossover.

### Stop Loss

Below the Morning Star low.

### Target

Follow the developing trend.

---

## Risk Management

Ignore the first Morning Star because momentum did not confirm it.

Trade only after both:

- Bullish Candlestick Confirmation
- Bullish MACD Confirmation

appear together.

---

## Key Lessons

✔ Multiple confirmations dramatically increase probability.

✔ A Morning Star without momentum confirmation can fail.

✔ MACD helps distinguish genuine reversals from temporary rebounds.

✔ Candlesticks provide timing, while MACD validates momentum.