# TC013 - Moving Averages Case Studies

## Source

Steve Nison

Beyond Candlesticks

Chapter 13

---

## Purpose

This section contains real chart examples demonstrating how Moving Averages, MACD, and Japanese Candlestick patterns work together to improve trading decisions.

Each case study documents:

- Market Context
- Technical Setup
- Candlestick Confirmation
- Moving Average / MACD Signal
- Trading Opportunity
- Risk Management
- Key Lessons

---

## Case Studies

Case 01 → Figure 13.1

Case 02 → Figure 13.2

Case 03 → Figure 13.3

Case 04 → Figure 13.7

Case 05 → Figure 13.8