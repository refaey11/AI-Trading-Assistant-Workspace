# Case 03 — Figure 13.3

## Market Context

Bullish Trend

---

## Indicator

65-Day Simple Moving Average

---

## Setup

Price tested the Moving Average twice.

First test:

Hammer

Second test:

Tweezer Bottom

---

## Interpretation

Multiple successful tests strengthened Dynamic Support.

Buyer commitment increased.

---

## Trading Opportunity

Entry

After confirmation.

Stop Loss

Below support.

Target

Trend continuation.

---

## Lesson

Repeated successful tests of Dynamic Support increase confidence in trend continuation.