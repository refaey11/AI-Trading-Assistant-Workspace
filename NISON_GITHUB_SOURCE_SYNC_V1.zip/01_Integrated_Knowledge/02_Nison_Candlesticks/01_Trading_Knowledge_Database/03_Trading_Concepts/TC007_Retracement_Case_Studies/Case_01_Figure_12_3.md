# Case Study 01

## Figure

Figure 12.3

---

## Market

Gold

---

## Chapter

Chapter 12

Candlesticks & Retracement Levels

---

## Primary Trend

Bearish Trend

---

## Market Context

The market completed a strong bearish decline from Point A to Point B.

After reaching Point B, buyers attempted a corrective rally.

The objective was to determine where this rally would likely end before the primary downtrend resumed.

---

## Swing Used

Swing High:

Point A

Swing Low:

Point B

---

## Retracement Used

50% Retracement

Resistance projected near:

464 USD

---

## Candlestick Confirmation

### Point C

Pattern:

Bearish Engulfing

Location:

Near the 50% retracement resistance.

Result:

The corrective rally ended.

The primary downtrend resumed.

---

### Point E

Pattern:

Almost Bearish Engulfing

Location:

Near another 50% retracement resistance.

Result:

Price failed to continue higher.

Another bearish leg started.

---

### Point G

Patterns:

Harami

+

Hanging Man

Later

Another Hanging Man

Location:

Near the major 50% retracement of the entire decline.

Result:

The market failed to break resistance.

The bearish trend resumed.

---

## Confluence Factors

✓ 50% Retracement

✓ Bearish Candlestick

✓ Existing Downtrend

✓ Previous Resistance

---

## Trading Decision

Wait for bearish candlestick confirmation.

Enter Short after confirmation candle closes.

---

## Stop Loss

Above the confirmation candle high.

---

## Target

Continuation of the primary bearish trend.

---

## Market Psychology

Every rally encouraged buyers to believe the downtrend had ended.

However,

Institutional sellers repeatedly defended the 50% retracement level.

Each bearish candlestick confirmed that sellers had regained control.

---

## Key Lesson

Retracement levels identify potential resistance.

Candlestick patterns confirm whether sellers are actually defending that resistance.

The highest probability setup occurs only when both agree.

---

## AI Tags

Gold

Bearish Trend

50% Retracement

Bearish Engulfing

Harami

Hanging Man

Resistance

Trend Continuation

Chapter12

Figure12.3