# TC007 - Retracement Case Studies

## Concept

This folder contains all real market case studies from:

Steve Nison
Chapter 12
Candlesticks & Retracement Levels

---

## Purpose

These files convert chart examples into structured trading knowledge.

Each case contains:

- Market
- Trend
- Retracement
- Candlestick Pattern
- Confluence
- Trading Decision
- Stop Loss
- Target
- Market Psychology
- Key Lesson

---

## Included Cases

### Case 01

Figure 12.3

Gold Market

50% Retracement

Bearish Engulfing

Harami

Hanging Man

---

### Case 02

Figure 12.4

Crude Oil

50% Retracement

Piercing Pattern

Dark Cloud Cover

---

### Case 03

Figure 12.5

Soybeans

61.8% Fibonacci

Bullish Harami

Change of Polarity

---

### Case 04

Figure 12.6

Multi-Timeframe Confirmation

Daily Hammer

Hourly Hammer

Hanging Man

---

## Relationship

TC005

↓

Retracement Theory

↓

TC006

↓

Candlestick Confirmation

↓

TC007

↓

Real Market Applications