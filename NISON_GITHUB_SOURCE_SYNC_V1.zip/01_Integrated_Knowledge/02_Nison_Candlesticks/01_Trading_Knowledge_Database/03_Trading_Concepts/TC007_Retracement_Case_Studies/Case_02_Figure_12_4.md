# Case Study 02

## Figure

Figure 12.4

---

## Market

Crude Oil

---

## Chapter

Chapter 12

Candlesticks & Retracement Levels

---

## Primary Trend

Bullish Trend

---

## Market Context

The market advanced strongly from Point A to Point B, creating a clear bullish impulse.

After the rally, price entered a normal corrective decline.

The objective was to determine whether the correction would end at the 50% retracement level before the primary uptrend resumed.

---

## Swing Used

Swing Low:

Point A

Swing High:

Point B

---

## Retracement Used

50% Retracement

Projected Support:

20.36 USD

---

## Candlestick Confirmation

### Point C

Pattern:

Piercing Pattern

Location:

Near the 50% retracement support.

Result:

Buyers successfully defended the support.

The market resumed its bullish trend.

---

### Point D

Pattern:

Dark Cloud Cover

Location:

Near the 50% retracement of the decline from B to C.

Result:

The recovery lost momentum.

Sellers regained short-term control.

---

## Confluence Factors

✓ 50% Retracement

✓ Piercing Pattern

✓ Existing Bullish Trend

✓ Support Level

---

## Trading Decision

### Long Trade

Wait for the Piercing Pattern to close.

Enter Long only after confirmation.

---

### Defensive Action

At Point D:

The Dark Cloud Cover warned that bullish momentum was weakening.

Existing long positions should be protected.

Aggressive traders could prepare for a bearish trade only after full confirmation.

---

## Stop Loss

Long Position:

Below the Piercing Pattern low.

Short Position:

Above the Dark Cloud Cover high.

---

## Target

Long Trade:

Retest of Point B.

Short Trade:

Retest of Point C.

---

## Market Psychology

The correction attracted sellers.

However,

Buyers defended the 50% retracement level aggressively.

The Piercing Pattern confirmed that demand had overcome supply.

Later,

As price approached resistance,

The Dark Cloud Cover showed that sellers had returned.

Control shifted back to the bears in the short term.

---

## Key Lesson

A retracement level alone is only a potential support.

A bullish candlestick transforms that level into a tradable opportunity.

Likewise,

A bearish candlestick near resistance warns that the recovery may be ending.

---

## AI Tags

Crude Oil

Bullish Trend

50% Retracement

Piercing Pattern

Dark Cloud Cover

Support

Resistance

Trend Continuation

Chapter12

Figure12.4